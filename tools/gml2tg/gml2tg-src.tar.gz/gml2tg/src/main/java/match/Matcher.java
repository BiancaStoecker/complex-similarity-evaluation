package match;

import graph.Graph;

import java.util.List;

import match.pattern.SearchPattern;
import match.pattern.SearchPlan;

/**
 * Base class for subgraph isomorphism algorithms.
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public abstract class Matcher<NL, EL> {

    /**
     * Used to enable debugging output.
     */
    public static final boolean DEBUG = false;

    protected SearchPattern<NL, EL> searchPattern;
    protected SearchPlan<NL, EL> searchPlan;
    protected Graph<NL, EL> host;
    protected MatchDelegate matchDelegate;

    /**
     * Initializes the Matcher. Uses the SearchPlan of the specified pattern
     * graph.
     * 
     * @param searchPattern
     * @param hostGraph
     */
    public Matcher(SearchPattern<NL, EL> searchPattern, Graph<NL, EL> hostGraph) {
        assert searchPattern != null;
        assert hostGraph != null;

        this.searchPattern = searchPattern;
        this.searchPlan = searchPattern.getSearchPlan();
        this.host = hostGraph;
    }

    /**
     * Initializes the Matcher. Creates a SearchPlan for the specified pattern
     * graph.
     * 
     * @param patternGraph
     * @param hostGraph
     */
    public Matcher(Graph<NL, EL> patternGraph, Graph<NL, EL> hostGraph) {
        this(new SearchPattern<>(patternGraph, false), hostGraph);
    }

    /**
     * Sets a matching delegate which will be called for every matching found.
     * The default behavior is to abort the matching process and let the
     * function match() return true.
     * 
     * @param md
     *            a {@link MatchDelegate} to handle matchings
     */
    public void setMatchDelegate(MatchDelegate md) {
        matchDelegate = md;
    }

    protected boolean handleMatch(PartialMapping<NL, EL> pm) {
        if (matchDelegate != null)
            return matchDelegate.handleMatch(pm);
        else
            return true;
    }

    /**
     * Returns the current matching or null if match was not called or match
     * returned false.
     * 
     * @return current matching
     */
    public abstract List<NodePair<NL, EL>> getMatch();

    /**
     * Invokes the matching process. By default the process will abort as soon
     * as the first match is found. This behaviour may be changed by using a
     * MatchDelegate.
     * 
     * @return true iff a mapping was found and was not delegated. When true
     *         getMatch() will return a correct mapping.
     * @see #getMatch()
     * @see #setMatchDelegate(MatchDelegate)
     */
    public abstract boolean match();

}
