package match;

import graph.Node;

// TODO remove, use more generic datastructures.Pair
/**
 * A pair of nodes in a matching.
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public class NodePair<NL, EL> {
    /**
     * The pattern node.
     */
    public Node<NL, EL> patternNode;
    /**
     * The host node.
     */
    public Node<NL, EL> hostNode;

    /**
     * Creates a new pair.
     * 
     * @param patternNode
     *            the node in the pattern graph
     * @param hostNode
     *            the node in the host graph
     */
    public NodePair(Node<NL, EL> patternNode, Node<NL, EL> hostNode) {
        this.patternNode = patternNode;
        this.hostNode = hostNode;
    }
}
