package index.features.extractor;

import graph.DefaultGraph;
import graph.Edge;
import graph.Graph;
import graph.Node;
import index.features.storage.FeatureStorage;

import java.util.List;
import java.util.Stack;

public class RingExtractor extends FeatureExtractor<String> {

    private int maxSize;

    /**
     * Constructor
     * 
     * Note: Each ring will be extracted and stored several times!
     * 
     * @param graph
     *            the {@link Graph} to extract the feaures from
     * @param featureStorage
     *            the {@link FeatureStorage}
     * @param maxSize
     *            the max ring size
     */
    public RingExtractor(Graph graph, FeatureStorage<? super String, ?> featureStorage, int maxSize) {
        super(graph, featureStorage);

        this.maxSize = maxSize;
    }

    @Override
    public void extractFeatures() {
        boolean[] visited = new boolean[graph.getNodeCount()];
        Stack<Node> path = new Stack<Node>();
        for (Node n : graph.nodes()) {
            search(n, visited, path, n, 1);
        }
    }

    private void search(Node startNode, boolean[] visited, Stack<Node> path,
            Node<? extends Object, ? extends Object> u, int depth) {
        path.push(u);
        visited[u.getIndex()] = true;

        for (Edge e : u.getEdges()) {
            Node v = e.getOppositeNode(u);
            // Avoids enumerating duplicates by adding only nodes with index
            // higher
            // than the start vertex. Each circle will be generated once
            // starting
            // from the node with the lowest index.
            // Furthermore each circle can be build in two direction. Only one
            // of them
            // will be processed.
            if (!visited[v.getIndex()] && depth < maxSize && v.getIndex() > startNode.getIndex()) {
                search(startNode, visited, path, v, depth + 1);
            } else if (v == startNode && path.size() > 2 && u.getIndex() > path.get(1).getIndex()) {
                processCircle(path);
            }
        }

        path.pop();
        visited[u.getIndex()] = false;
    }

    private void processCircle(Stack<Node> circle) {
        DefaultGraph g = new DefaultGraph(circle.size());
        for (Node n : circle) {
            g.addNode(n.getLabel());
        }
        for (int i = 0; i < circle.size(); i++) {
            int iU = i;
            int iV = i + 1;
            if (iV == circle.size())
                iV = 0;

            Edge sEdge = graph.getEdge(circle.get(iU), circle.get(iV));

            g.addEdge(g.getNode(iU), g.getNode(iV), sEdge.getLabel());
        }

        String label = "$" + getLabel(g) + "$";
        featureStorage.processFeature(label);
        // add a second bit
        StringBuilder sb = new StringBuilder(label);
        featureStorage.processFeature(sb.reverse().toString());
    }

    /**
     * @param ring
     *            a graph that must be a ring
     */
    private String getLabel(Graph<? extends Object, ? extends Object> ring) {
        String distinctLabel = "";

        for (Node<? extends Object, ? extends Object> u : ring.nodes()) {
            for (Edge e : u.getEdges()) {
                StringBuilder sb = new StringBuilder();
                traverseRing(u, u, e, sb);
                String label = sb.toString();
                if (label.compareTo(distinctLabel) > 0) {
                    distinctLabel = label;
                }
            }
        }

        return distinctLabel;
    }

    /**
     * @param u
     * @param e
     *            = (u,*)
     * @param sb
     */
    private void traverseRing(Node startNode, Node u, Edge e, StringBuilder sb) {
        sb.append(getLabel(u));
        sb.append(getLabel(e));

        Node v = e.getOppositeNode(u);
        if (v == startNode)
            return; // ring closed

        List<Edge> edges = v.getEdges();
        Edge f = edges.get(0);
        if (f == e)
            f = edges.get(1);

        traverseRing(startNode, v, f, sb);
    }

    /*
     * public static void main(String[] args) throws IOException,
     * InvalidSmilesException, CDKException { //String smiles =
     * "C1C2CC3CC1CC(C2)(C3)C56(CC4CC(CC(C4)C5)C6)"; // Adamantanes //String
     * smiles =
     * "CC(CNCCNCC(C)N1C(=O)C2=CC=CC3=CC(=CC(=C32)C1=O)[N+](=O)[O-])N4C(=O)C5=CC=CC6=CC(=CC(=C65)C4=O)[N+](=O)[O-]"
     * ; // Naphthalimides String smiles =
     * "[H]c2c1[nH]c9c5c1c3c(c2Cl)CC(=C)C4CC(C34(O))C(OC5C%10CCC8(O)(C(CCC6OC(C(=C)C)C(O)C7OC678)C9%10))(C)C"
     * ;
     * 
     * SmilesParser smilesParser = new
     * SmilesParser(DefaultChemObjectBuilder.getInstance()); IAtomContainer ac =
     * smilesParser.parseSmiles(smiles);
     * AtomContainerManipulator.percieveAtomTypesAndConfigureAtoms(ac);
     * CDKHueckelAromaticityDetector.detectAromaticity(ac); IsotopeFactory iso =
     * IsotopeFactory.getInstance(ac.getAtom(0).getBuilder()); for (IAtom atom :
     * ac.atoms()) { iso.configure(atom); } Molecule mol = (Molecule)ac;
     * 
     * int iterations = 1000; int size = 15; //9
     * 
     * CountHashTable<String> cht = new CountHashTable<String>(); RingExtractor
     * re = new RingExtractor(new MoleculeGraph(mol), cht, size);
     * 
     * long startTime = System.nanoTime(); for (int i=0; i<iterations; i ++) {
     * re.extractFeatures2(); } long duration = System.nanoTime() - startTime;
     * System.out.println(cht); System.out.println("Duration [ms]:"+duration /
     * 1000000.0);
     * 
     * 
     * cht = new CountHashTable<String>(); re = new RingExtractor(new
     * MoleculeGraph(mol), cht, size);
     * 
     * startTime = System.nanoTime(); for (int i=0; i<iterations; i ++) {
     * re.extractFeatures(); } duration = System.nanoTime() - startTime;
     * System.out.println(cht); System.out.println("Duration [ms]:"+duration /
     * 1000000.0); }
     */

}
