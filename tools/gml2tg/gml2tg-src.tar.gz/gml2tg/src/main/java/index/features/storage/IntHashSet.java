package index.features.storage;

import index.util.Hashing;

import java.util.HashSet;

/**
 * Maps each feature to a number in {0, ..., Integer.MAX_VALUE} and stores 
 * the numbers in a set.
 * 
 * Note: The given features must have a reasonable implementation of
 * {@link Object#hashCode()}.
 * 
 * @author Nils Kriege
 * 
 */
public class IntHashSet implements FeatureStorage<Object, HashSet<Integer>> {
	
	private HashSet<Integer> features;
	
	public IntHashSet() {
		features = new HashSet<Integer>();
	}
	
	/**
     * Note: The given object must have a reasonable implementation of
     * {@link Object#hashCode()}.
     * 
     * @see FeatureStorage#processFeature(Object)
	 */
    @Override
	public void processFeature(Object o) {
		int value = Hashing.hash(o.hashCode(),Integer.MAX_VALUE);
		features.add(value);
	}
	
    @Override
	public int getFeatureCount() {
		return features.size();
	}
	
    @Override
	public HashSet<Integer> getResult() {
		return features;
	}

}
