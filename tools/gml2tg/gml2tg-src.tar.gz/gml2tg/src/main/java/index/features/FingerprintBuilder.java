package index.features;

import java.util.HashMap;
import java.util.HashSet;

import graph.Graph;

import index.features.extractor.PathExtractor;
import index.features.extractor.RingExtractor;
import index.features.extractor.SubtreeExtractor;
import index.features.storage.CountHashTable;
import index.features.storage.FeatureStorage;
import index.features.storage.HashKeyFingerprint;
import index.features.storage.IntHashSet;


/**
 * Allows common hash key fingerprint creation based on
 * different features classes: path, subtree, rings
 */
public class FingerprintBuilder {
	
	private boolean findPaths		= false;
	private boolean findSubtrees	= true;
	private boolean findRings		= true;
	private int pathSize			= 8;
	private int subtreeSize			= 5;
	private int ringSize			= 8;
	
	private int fingerprintSize;
	
	/**
     * Constructor
     * 
     * @param fingerprintSize
     *            the fingerprint size (should be a power of 2)
	 */
	public FingerprintBuilder(int fingerprintSize) {
		this.fingerprintSize = fingerprintSize;
	}
	
	/**
     * Constructor
     * 
     * @param fingerprintSize
     *            the fingerprint size (should be a power of 2)
     * @param findPaths
     *            enables the path fingerprint features
     * @param findSubtrees
     *            enables the subtree fingerprint features
     * @param findRings
     *            enables the ring fingerprint features
     * @param pathSize
     *            the maximum path size
     * @param subtreeSize
     *            the maximum subtree size
     * @param ringSize
     *            the maximum ring size
	 */
	public FingerprintBuilder(int fingerprintSize, boolean findPaths, boolean findSubtrees,
			boolean findRings, int pathSize, int subtreeSize, int ringSize)
	{
		this.fingerprintSize = fingerprintSize;
		this.findPaths		= findPaths;
		this.findSubtrees 	= findSubtrees;
		this.findRings		= findRings;
		this.pathSize		= pathSize;
		this.subtreeSize	= subtreeSize;
		this.ringSize		= ringSize;
	}
	
	public FingerprintBuilder(int fingerprintSize, int pathSize, int subtreeSize, int ringSize)
	{
		this.fingerprintSize = fingerprintSize;
		this.findPaths		= pathSize >= 0;
		this.findSubtrees 	= subtreeSize >= 0;
		this.findRings		= ringSize >= 3;
		this.pathSize		= pathSize;
		this.subtreeSize	= subtreeSize;
		this.ringSize		= ringSize;
	}
	
	private void extractFeatures(FeatureStorage<? super String, ?> fs, Graph graph) {
		if (findPaths) {
			PathExtractor pe = new PathExtractor(graph, fs, pathSize, PathExtractor.SIMPLE_PATHS);
			pe.extractFeatures();
		}
		if (findSubtrees) {
			SubtreeExtractor se = new SubtreeExtractor(graph, fs, subtreeSize);
			se.extractFeatures();
		}
		if (findRings) {
			RingExtractor re = new RingExtractor(graph, fs, ringSize);
			re.extractFeatures();
		}
	}
	
    /**
     * Calculates the fingerprint.
     * 
     * @param graph
     *            the graph to generate the fingerprint from
     * @return the fingerprint
     */
	public BitFingerprint getFingerprint(Graph graph) {
		HashKeyFingerprint fp = new HashKeyFingerprint(fingerprintSize);
		extractFeatures(fp, graph);
		//----------
//		CountHashTable<String> cht = new CountHashTable<String>();
//		extractFeatures(cht, graph);
//		for (String key : cht.getResult().keySet())
//			System.out.println(key);
		//----------
		return fp.getResult();
	}
	
    /**
     * Return the size of the fingerprint
     * 
     * @return the size of the fingerprint
     */
	public int getFingerprintSize() {
		return fingerprintSize;
	}
	
    /**
     * Calculates the fingerprint as {@link HashSet}
     * 
     * @param graph
     *            the graph to generate the fingerprint from
     * @return the fingerprint
     */
	public HashSet<Integer> getIntHashSet(Graph graph) {
		IntHashSet ihs = new IntHashSet();
		extractFeatures(ihs, graph);
		return ihs.getResult();
	}
	
    /**
     * Calculates the fingerprint feature count as {@link HashMap}.
     * 
     * Feature -> count of occurences
     * 
     * @param graph
     *            the graph to generate the fingerprint feature count from
     * @return the fingerprint feature count
     */
	public HashMap<String,Integer> getCountHashTable(Graph graph) {
		CountHashTable<String> cht = new CountHashTable<String>();
		extractFeatures(cht, graph);
		return cht.getResult();
	}
	
    @Override
	public String toString() {
		return (findPaths ? "Paths "+pathSize+" " : "") +
			(findSubtrees ? "Subtrees "+subtreeSize+" " : "") +
			(findRings ? "Rings "+ringSize+" " : "");
	}

	public void setFindPaths(boolean findPaths) {
		this.findPaths = findPaths;
	}

	public boolean isFindPaths() {
		return findPaths;
	}

	public void setFindSubtrees(boolean findSubtrees) {
		this.findSubtrees = findSubtrees;
	}

	public boolean isFindSubtrees() {
		return findSubtrees;
	}

	public void setFindRings(boolean findRings) {
		this.findRings = findRings;
	}

	public boolean isFindRings() {
		return findRings;
	}

	public void setPathSize(int pathSize) {
		this.pathSize = pathSize;
	}

	public int getPathSize() {
		return pathSize;
	}

	public void setSubtreeSize(int subtreeSize) {
		this.subtreeSize = subtreeSize;
	}

	public int getSubtreeSize() {
		return subtreeSize;
	}

	public void setRingSize(int ringSize) {
		this.ringSize = ringSize;
	}

	public int getRingSize() {
		return ringSize;
	}

	public void setFingerprintSize(int fingerprintSize) {
		this.fingerprintSize = fingerprintSize;
	}
		
}
