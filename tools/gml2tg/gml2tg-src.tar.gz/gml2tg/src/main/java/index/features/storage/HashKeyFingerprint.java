package index.features.storage;

import index.features.BitFingerprint;
import index.util.Hashing;


/**
 * Maps features to positions in a fingerprint by a hash function. For each
 * feature the corresponding bit is set to 1.
 * 
 * Note: The given features must have a reasonable implementation of
 * {@link Object#hashCode()}.
 * 
 * @author Nils Kriege
 * 
 */
public class HashKeyFingerprint implements FeatureStorage<Object, BitFingerprint> {
	
	public static final int defaultSize = 1024;
	
	private int size;
	private BitFingerprint fingerprint;
	private int featureCount=0;
	
    /**
     * Constructor
     */
	public HashKeyFingerprint() {
		this(defaultSize);
	}
	
    /**
     * Constructor
     * 
     * @param size
     *            the initial size
     */
	public HashKeyFingerprint(int size) {
		this.size = size;
		this.fingerprint = new BitFingerprint(size);
	}
	
	/**
     * Note: The given object must have a reasonable implementation of
     * {@link Object#hashCode()}.
     * 
     * @see FeatureStorage
	 */
    @Override
	public void processFeature(Object feature) {
		int position = Hashing.hash(feature, size);

		fingerprint.set(position);	
		featureCount++;
	}
	
    @Override
	public int getFeatureCount() {
		return featureCount;
	}
	
	/**
	 * Returns the fingerprint.
	 */
    @Override
	public BitFingerprint getResult() {
		return fingerprint;
	}
}
