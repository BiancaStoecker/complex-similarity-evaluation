package index.util;

import java.util.Random;

/**
 * Utility Class for different hashing functions
 * 
 * @author Nils Kriege
 */
public class Hashing {

	/**
     * Multiplicative hashing.
     * 
     * Note: Inefficient implementation due to lack of unsigned integer!
     * 
     * @param str
     *            the {@link String} to hash
     * @param m
     *            the maximal hash value
     * @return the hash
	 */
	public static int multHash(String str, int m) {

		final double A = (Math.sqrt(5)-1)/2;
		int k = str.hashCode();
		double hash = ((A*k) % 1) * m;

		return (int)Math.floor(Math.abs(hash));
	}
	
	/**
	 * Java HashMap hashing function.
	 * 
	 * Note: Works well only if m is power of 2!
     * 
     * @param o
     *            the {@link Object} to hash
     * @param m
     *            the maximal hash value
     * @return the hash
	 */
	public static int hash(Object o, int m) {
		int k = o.hashCode();
        k ^= (k >>> 20) ^ (k >>> 12);
        k ^= (k >>> 7) ^ (k >>> 4);
        return k & (m-1);
	}
	
	/**
	 * Hashing function used by CDK.
     * 
     * @param o
     *            the {@link Object} to hash
     * @param m
     *            the maximal hash value
     * @return the hash
	 */
	public static int cdkHash(Object o, int m) {
        return new java.util.Random(o.hashCode()).nextInt(m);
	}
	
	/**
	 * CRC32 based hashing function.
     * 
     * @param s
     *            the {@link String} to hash
     * @param m
     *            the maximal hash value
     * @return the hash
	 */
	public static int crc32Hash(String s, int m) {
		long crc32 = crc32(s);
		return Math.abs((int)(crc32 % m));
	}

	/**
	 * CRC32+RNG based hashing function.
     * 
     * @param s
     *            the {@link String} to hash
     * @param m
     *            the maximal hash value
     * @return the hash
	 */
	public static int crc32RandomHash(String s, int m) {
		long crc32 = crc32(s);
		return new Random(crc32).nextInt(m);
	}

	/**
     * djb2 hashing function.
     * 
     * @param str
     *            the {@link String} to hash
     * @param m
     *            the maximal hash value
     * @return the hash
     */
	public static int djb2Hash(String str, int m) {
		int hash = 5381;

		for(int i = 0; i < str.length(); i++) {
			hash = ((hash << 5) + hash) + str.charAt(i);
		}
		
		return Math.abs((int)(hash % m));
	}
	

    /**
     * crc32 hashing function.
     * 
     * @param s
     *            the {@link String} to hash
     * @return the hash
     */
	public static long crc32(String s) {
		java.util.zip.CRC32 crc32 = new java.util.zip.CRC32();
		crc32.update(s.getBytes());
		return crc32.getValue();
	}

    /**
     * DEK hashing function.
     * 
     * @param str
     *            the {@link String} to hash
     * @param m
     *            the maximal hash value
     * @return the hash
     */
	public static int DEKHash(String str, int m) {
		int hash = str.length();
		
		for(int i = 0; i < str.length(); i++) {
			hash = ((hash << 5) ^ (hash >> 27)) ^ str.charAt(i);
		}
		
		return Math.abs((int)(hash % m));
	}
	
    /**
     * ELF hashing function.
     * 
     * @param str
     *            the {@link String} to hash
     * @param m
     *            the maximal hash value
     * @return the hash
     */
	public static int ELFHash(String str, int m) {
		long hash = 0;
		long x    = 0;
		
		for(int i = 0; i < str.length(); i++) {
			hash = (hash << 4) + str.charAt(i);
			
			if((x = hash & 0xF0000000L) != 0) {
				hash ^= (x >> 24);
			}
			hash &= ~x;
		}
		
		return Math.abs((int)(hash % m));
	}

    /**
     * SDBM hashing function.
     * 
     * @param str
     *            the {@link String} to hash
     * @param m
     *            the maximal hash value
     * @return the hash
     */
	public static int SDBMHash(String str, int m) {
		int hash = 0;
		
		for(int i = 0; i < str.length(); i++) {
			hash = str.charAt(i) + (hash << 6) + (hash << 16) - hash;
		}
		
		return Math.abs((int)(hash % m));
	}

}
