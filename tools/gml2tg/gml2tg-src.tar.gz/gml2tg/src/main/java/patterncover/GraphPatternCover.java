package patterncover;

import graph.Graph;
import graph.Node;

import java.util.LinkedList;

import match.MatchDelegate.CollectAll;
import match.Matcher;
import match.MatcherVF2;
import match.NodePair;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Represents a pattern cover for one pair of pattern and graph.
 * 
 * @author Markus Kloss
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public class GraphPatternCover<NL, EL> {
    
    /**
     * Used to enable debugging output.
     */
    public static final boolean DEBUG = false;
    private static final Logger logger = LoggerFactory.getLogger(GraphPatternCover.class);
    
    protected Graph<NL, EL> HostGraph;
    protected Graph<NL, EL> Pattern;
    
    protected Matcher<NL, EL> matcher;
    
    protected LinkedList<LinkedList<NodePair<NL, EL>>> FoundMatches;
    protected Graph<NL, EL> CoverSubgraph;
    
    protected boolean countCoveredNodes = false;
    protected int coverSize;
    protected double coverSizeRelative;
    protected boolean inputHasChanged = false;
    
    /**
     * Initializes the class to find a graph cover for the given pattern
     * @param graph The input test graph
     * @param pattern The input pattern graph
     */
    public GraphPatternCover(Graph<NL, EL> graph, Graph<NL, EL> pattern)
    {
        this.HostGraph = graph;
        this.Pattern = pattern;
        
        FoundMatches = new LinkedList<LinkedList<NodePair<NL, EL>>>();
        this.matcher = new MatcherVF2(this.Pattern, this.HostGraph);
        this.coverSize = 0;
        this.inputHasChanged = true;
    }
    
    /**
     * Observes if the input data has changed
     * @return True iff the graph or the pattern have been changed
     */
    public boolean inputHasChanged()
    {
        return this.inputHasChanged;
    }
    
    public void setMatcher(Matcher<NL, EL> matcher)
    {
        this.matcher = matcher;
    }
    
    /**
     * Sets the property to decide if nodes are counted for the cover size
     * @param countProperty true iff host nodes are counted in the cover size
     */
    public void setCoverSizeCountProperty(boolean countProperty)
    {
        this.countCoveredNodes = countProperty;
    }
    
    /**
     * Generates the pattern matches for the test graph
     */
    public void generateMatches()
    {     
        CollectAll<NL, EL> md = new CollectAll<NL, EL>();       
        this.matcher.setMatchDelegate(md);       
        this.matcher.match();        
        this.FoundMatches = md.getMatches();
    }
    
    public Node<NL, EL> getCorrespondingPatternNodeForMatch(LinkedList<NodePair<NL, EL>> match, Node<NL, EL> hostNode)
    {
        for(NodePair<NL, EL> pair : match)
        {
            if(pair.hostNode.equals(hostNode))
            {
                return pair.patternNode;
            }
        }
        return null;
    }
    
    /**
     * Returns the cover size relatively to the size node set of the host graph
     * @return Relative cover size
     */
    public double getCoverSizeRelative()
    {
        return this.coverSizeRelative;
    }
    
    /**
     * Return the calculated matches if already calculated
     * @return the calculated matches
     */
    public LinkedList<LinkedList<NodePair<NL, EL>>> getMatches()
    {
        return this.FoundMatches;
    }

    public Graph getPattern() {
        return this.Pattern;
    }

}
