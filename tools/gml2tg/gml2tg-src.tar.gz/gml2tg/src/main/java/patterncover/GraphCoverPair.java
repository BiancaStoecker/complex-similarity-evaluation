package patterncover;

import graph.*;

public class GraphCoverPair<NL, EL> {

    protected Graph<NL, EL> Graph;
    protected Graph<NL, EL> Cover;
    
    public GraphCoverPair(Graph<NL,EL> graph, Graph<NL, EL> cover)
    {
        this.Graph = graph;
        this.Cover = cover;
    }
    
    public Graph<NL, EL> getCover()
    {
        return this.Cover;
    }
    
    public Graph<NL, EL> getGraph()
    {
        return this.Graph;
    }
}
