package hsahn.comparison.kernel.basic;

import hsahn.comparison.kernel.Kernel;

public class DiracKernel implements Kernel<Object> {

	/**
	 * Returns 1 iff g1.equals(g2) returns true, 0 otherwise.
	 */
	@Override
    public double compute(Object g1, Object g2) {
		return (/*g1 == g2 ||*/ g1.equals(g2)) ? 1d : 0d;
	}

	@Override
    public String getID() {
		return "D";
	}

}
