package hsahn.comparison.kernel.graph;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import hsahn.algorithm.graph.isomorphism.labelrefinement.VertexLabelConverter;
import hsahn.algorithm.graph.isomorphism.labelrefinement.WeisfeilerLehmanRefiner;
import hsahn.comparison.kernel.CompositeKernel;
import hsahn.comparison.kernel.ExplicitMappingKernel;
import hsahn.comparison.kernel.Kernel;
import hsahn.concepts.TransformationTools;
import hsahn.datastructure.SparseFeatureVector;
import hsahn.graph.LGraph;

/**
 * Implementation of Weisfeiler-Lehman graph kernels depending on an arbitrary
 * base kernel (Shervashidze, 2011). This class computes a sequence of graphs
 * with refined vertex labels for both input graphs and compares the i-th graph
 * in the first sequence with the i-th graph in the second sequence by the base
 * kernel, where 0 <= i <= sequenceSize. This class supports 1:1 kernel
 * computation as well as explicit mapping into feature space for fast n:n
 * computation if the base kernel supports explicit mapping.
 * 
 * @see WeisfeilerLehmanShortestPathKernel
 * 
 * @author kriege
 * @param <V>
 *            vertex label type
 * @param <E>
 *            edge label type
 * @param <F>
 *            feature type of explicit mapping
 */
// TODO make this a general class for all types of vertex refinements
public class WeisfeilerLehmanKernel<V, E, F> extends CompositeKernel<LGraph<V, E>>
        implements ExplicitMappingKernel<LGraph<V, E>, SparseFeatureVector<F>> {

    protected int sequenceSize;
    protected Kernel<LGraph<Integer, E>> baseKernel;
    protected VertexLabelConverter<E> vlc = new VertexLabelConverter<>();
    protected boolean stableLabelConverter;

    /**
     * Creates a new instance of a Weisfeiler-Lehmann kernel.
     * 
     * @param sequenceSize
     *            the number of graphs in the computed WL sequence
     * @param baseKernel
     *            kernel applied to the individual graphs of the WL sequence
     */
    public WeisfeilerLehmanKernel(int sequenceSize, Kernel<LGraph<Integer, E>> baseKernel) {
        this(sequenceSize, baseKernel, false);
    }

    /**
     * Creates a new instance of a Weisfeiler-Lehmann kernel.
     * 
     * @param sequenceSize
     *            the number of graphs in the computed WL sequence
     * @param baseKernel
     *            kernel applied to the individual graphs of the WL sequence
     * @param stableLabelConverter
     *            iff true {@link #computeExplicitMapping(Collection)} can be
     *            called multiple times without loosing the label mapping. i.e.
     *            the generated explicit mappings of different runs can be
     *            compared to each other. Be aware, that this can lead to many
     *            unused attributes in the feature vectors if the same kernel
     *            object is used for multiple datasets that should not be
     *            compared to each other.
     */
    public WeisfeilerLehmanKernel(int sequenceSize, Kernel<LGraph<Integer, E>> baseKernel,
            boolean stableLabelConverter) {
        this.sequenceSize = sequenceSize;
        this.baseKernel = baseKernel;
        this.stableLabelConverter = stableLabelConverter;
    }

    /**
     * Returns a separate result for each graph of the WL graph sequence.
     */
    @Override
    public double[] computeComposition(LGraph<V, E> g1, LGraph<V, E> g2) {
        double[] d = new double[sequenceSize];

        // do initial label refinement
        VertexLabelConverter<E> vlc = new VertexLabelConverter<>();
        LGraph<Integer, E> slg1 = vlc.refineGraph(g1);
        LGraph<Integer, E> slg2 = vlc.refineGraph(g2);
        vlc.clearLabelMap();

        // first iteration
        d[0] = baseKernel.compute(slg1, slg2);

        // additional iterations
        WeisfeilerLehmanRefiner<E> wlr = new WeisfeilerLehmanRefiner<>();
        for (int i = 1; i < sequenceSize; i++) {
            slg1 = vlc.refineGraph(wlr.refineGraph(slg1));
            slg2 = vlc.refineGraph(wlr.refineGraph(slg2));
            vlc.clearLabelMap();
            d[i] = baseKernel.compute(slg1, slg2);
        }

        return d;
    }

    /**
     * {@inheritDoc}
     * 
     * @throws IllegalStateException
     *             if the underlying base kernel does not allow explicit mapping
     */
    @Override
    @SuppressWarnings("unchecked")
    public ArrayList<SparseFeatureVector<F>> computeExplicitMapping(List<? extends LGraph<V, E>> graphs) {
        ExplicitMappingKernel<LGraph<Integer, E>, SparseFeatureVector<F>> baseKernel = (ExplicitMappingKernel<LGraph<Integer, E>, SparseFeatureVector<F>>) this.baseKernel;

        int n = graphs.size();

        if (stableLabelConverter) {
            vlc.setIteration(0);
        } else {
            vlc = new VertexLabelConverter<>();
        }
        // assign integer label
        // using the same VertexLabelConverter assures that new labels (from
        // refinement) will
        // be assigned higher integer values, such that labels of different
        // iterations can be
        // distinguished
        ArrayList<LGraph<Integer, E>> lgs = TransformationTools.transformAll(vlc, graphs);
        if (!stableLabelConverter) {
            vlc.clearLabelMap();
        }

        // create initial feature vectors
        ArrayList<SparseFeatureVector<F>> result = baseKernel.computeExplicitMapping(lgs);

        WeisfeilerLehmanRefiner<E> wlr = new WeisfeilerLehmanRefiner<>();
        for (int i = 1; i < sequenceSize; i++) {
            // refinement
            ArrayList<LGraph<String, E>> refLgs = TransformationTools.transformAll(wlr, lgs);
            // compression
            if (stableLabelConverter) {
                vlc.setIteration(i);
            }
            lgs = TransformationTools.transformAll(vlc, refLgs);
            if (!stableLabelConverter) {
                vlc.clearLabelMap();
            }

            // compute new feature vectors and combine with the old one
            ArrayList<SparseFeatureVector<F>> r2 = baseKernel.computeExplicitMapping(lgs);
            for (int j = 0; j < n; j++) {
                result.get(j).add(r2.get(j));
            }
        }

        return result;
    }

    /**
     * Precondition: stableLabelConverter is set to true.
     * 
     * @return the used {@link VertexLabelConverter}
     * 
     * @throws IllegalStateException
     *             in the case stableLabelConverter is set to false
     */
    public VertexLabelConverter<E> getVertexLabelConverter() {
        if (!stableLabelConverter) {
            throw new IllegalStateException("stableLabelConverter must be true");
        }
        return vlc;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getComponentCount() {
        return sequenceSize;
    }

    @Override
    public String toString() {
        return "Weisfeiler-Lehman kernel+\n" + "\tsequenceSize=" + sequenceSize + "\n" + "\tbaseKernel="
                + String.valueOf(baseKernel);
    }

    @Override
    public String getID() {
        return "WL_" + sequenceSize + "_" + baseKernel.getID();
    }
}
