package hsahn.graph.properties;

import hsahn.graph.Graph.Vertex;

public interface VertexProperty<V> extends GraphProperty<Vertex, V> {

}
