package hsahn.graph.properties;

import hsahn.graph.Graph.Edge;

public interface EdgeProperty<V> extends GraphProperty<Edge, V> {

}
