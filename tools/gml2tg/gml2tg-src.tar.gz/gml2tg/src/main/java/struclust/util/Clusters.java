package struclust.util;

import graph.Graph;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import struclust.Cluster;
import struclust.ClusterFactory;
import struclust.graph.GraphContainer;
import struclust.graph.Graphs;

/**
 * Convenience methods for {@link Cluster}s
 * 
 * @author Till Schäfer
 */
public class Clusters {
    /**
     * Create an {@link ArrayList} of {@link Cluster}s from a nested Collection
     * of Graphs (nested {@link Collection}s are interpreted as clusters)
     * 
     * @param clusters
     *            the clusters in collection structure
     * @param cf
     *            the cluster factory
     * @return an {@link ArrayList} of {@link Cluster}s
     */
    public static <NL, EL, G extends Graph<NL, EL>> ArrayList<Cluster<NL, EL, G>> toClusterList(
            Collection<? extends Collection<G>> clusters, ClusterFactory<NL, EL, G> cf) {
        ArrayList<Cluster<NL, EL, G>> retVal = new ArrayList<>(clusters.size());

        for (Collection<G> clusterMembers : clusters) {
            Cluster<NL, EL, G> cluster = cf.emptyCluster();
            for (G g : clusterMembers) {
                GraphContainer<NL, EL, G> gc = new GraphContainer<>(g);
                cluster.add(gc);
            }
            retVal.add(cluster);
        }

        return retVal;
    }

    /**
     * Create an {@link ArrayList} of {@link Cluster}s from a nested Collection
     * of GraphContainers (nested {@link Collection}s are interpreted as
     * clusters)
     * 
     * @param clusters
     *            the clusters in collection structure
     * @param cf
     *            the cluster factory
     * @return an {@link ArrayList} of {@link Cluster}s
     */
    public static <NL, EL, G extends Graph<NL, EL>> ArrayList<Cluster<NL, EL, G>> toClusterListGC(
            Collection<? extends Collection<GraphContainer<NL, EL, G>>> clusters, ClusterFactory<NL, EL, G> cf) {
        ArrayList<Cluster<NL, EL, G>> retVal = new ArrayList<>(clusters.size());

        for (Collection<GraphContainer<NL, EL, G>> clusterMembers : clusters) {
            Cluster<NL, EL, G> cluster = cf.emptyCluster();
            for (GraphContainer<NL, EL, G> gc : clusterMembers) {
                cluster.add(gc);
            }
            retVal.add(cluster);
        }

        return retVal;
    }

    /**
     * Clones everything of the clusters, but the members. The ordering of the
     * clusters is preserved.
     * 
     * @param oldClusters
     *            the clusters to clone
     * @return the cloned clusters, with empty member sets.
     */
    public static <NL, EL, G extends Graph<NL, EL>> List<Cluster<NL, EL, G>> cloneClusteringWithoutMembers(
            List<Cluster<NL, EL, G>> oldClusters) {
        LinkedList<Cluster<NL, EL, G>> clusters = new LinkedList<>();
        for (Cluster<NL, EL, G> cluster : oldClusters) {
            clusters.add(cluster.emptyCopy());
        }
        return clusters;
    }

    /**
     * Creates isomorphic clusters, i.e. all cluster members are replaced by a
     * isomorphic counterpart from the graph parameter. The cluster
     * representatives set and ids are copied.
     * 
     * The replacing is done by an injection, i.e. distinct cluster members are
     * replaced with distinct GraphContainers.
     * 
     * @param clusters
     *            a {@link List} of {@link Cluster}s
     * @param graphs
     *            the {@link GraphContainer}s that should replace the
     *            {@link GraphContainer}s stored in the {@link Cluster}s
     * @return new clusters with identical ids and replace graph members
     */
    public static <NL, EL, G extends Graph<NL, EL>> List<Cluster<NL, EL, G>> replaceMembersWithIsomorphicGcs(
            List<Cluster<NL, EL, G>> clusters, List<GraphContainer<NL, EL, G>> graphs) {
        List<GraphContainer<NL, EL, G>> gcs = clusters.stream().flatMap(c -> c.stream()).collect(Collectors.toList());
        Map<GraphContainer<NL, EL, G>, GraphContainer<NL, EL, G>> graphMap = Graphs.getIsomorphicGraphMapping(gcs,
                graphs);
        List<Cluster<NL, EL, G>> mappedClusters = new ArrayList<>();
        for (Cluster<NL, EL, G> cluster : clusters) {
            Collection<GraphContainer<NL, EL, G>> members = new ArrayList<>();
            for (GraphContainer<NL, EL, G> gc : cluster) {
                members.add(graphMap.get(gc));
            }
            mappedClusters
                    .add(new Cluster<>(members, cluster.getRepresentatives(), cluster.getId(), cluster.getGSize()));
        }
        return mappedClusters;
    }

    /**
     * Creates isomorphic clusters, i.e. all cluster members are replaced by a
     * isomorphic counterpart from the graph parameter. The cluster
     * representatives set and ids are copied.
     * 
     * The replacing is done by a non-injective function, i.e. distinct cluster
     * members are not necessarily replaced with distinct GraphContainers.
     * 
     * @param clusters
     *            a {@link List} of {@link Cluster}s
     * @param graphs
     *            the {@link GraphContainer}s that should replace the
     *            {@link GraphContainer}s stored in the {@link Cluster}s
     * @return new clusters with identical ids and replace graph members
     */
    public static <NL, EL, G extends Graph<NL, EL>> List<Cluster<NL, EL, G>> replaceMembersWithMultiIsomorphicGcs(
            List<Cluster<NL, EL, G>> clusters, List<GraphContainer<NL, EL, G>> graphs) {
        List<GraphContainer<NL, EL, G>> gcs = clusters.stream().flatMap(c -> c.stream()).collect(Collectors.toList());
        Map<GraphContainer<NL, EL, G>, GraphContainer<NL, EL, G>> graphMap = Graphs.getIsomorphicMultiGraphMapping(gcs,
                graphs);
        List<Cluster<NL, EL, G>> mappedClusters = new ArrayList<>();
        for (Cluster<NL, EL, G> cluster : clusters) {
            Collection<GraphContainer<NL, EL, G>> members = new ArrayList<>();
            for (GraphContainer<NL, EL, G> gc : cluster) {
                members.add(graphMap.get(gc));
            }
            mappedClusters
                    .add(new Cluster<>(members, cluster.getRepresentatives(), cluster.getId(), cluster.getGSize()));
        }
        return mappedClusters;
    }

}
