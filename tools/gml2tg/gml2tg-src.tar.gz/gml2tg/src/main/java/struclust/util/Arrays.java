package struclust.util;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Class for convenient methods regarding arrays
 * 
 * @author Till Schäfer
 */
public class Arrays {
    /**
     * An unbiased shuffling algorithm in linear time
     * 
     * @param a
     *            the array to shuffle
     * @param rnd
     *            the random number generator for shuffling
     */
    public static void fisherYatesShuffle(int[] a, Random rnd) {
        int temp;
        for (int i = a.length - 1; i > 0; i--) {
            //RAND: draw shuffling index
            int sIndex = rnd.nextInt(i + 1);

            temp = a[sIndex];
            a[sIndex] = a[i];
            a[i] = temp;
        }
    }

    /**
     * An unbiased shuffling algorithm in linear time
     * 
     * @param a
     *            the array to shuffle
     */
    public static void fisherYatesShuffle(int[] a) {
        fisherYatesShuffle(a, ThreadLocalRandom.current());
    }
}
