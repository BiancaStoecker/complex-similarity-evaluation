package struclust.mining;

import graph.Graph;
import index.features.BitFingerprint;
import index.features.FingerprintBuilder;

import java.util.List;

import org.apache.commons.math3.stat.inference.AlternativeHypothesis;
import org.apache.commons.math3.stat.inference.BinomialTest;
import org.apache.commons.math3.stat.interval.BinomialConfidenceInterval;
import org.apache.commons.math3.stat.interval.ConfidenceInterval;
import org.apache.commons.math3.stat.interval.NormalApproximationInterval;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import struclust.SharedMemorySCC;
import struclust.datastructures.MutableInt;
import struclust.datastructures.RandomQueue;
import struclust.graph.GraphContainer;

import com.google.common.base.Preconditions;

/**
 * Calculated the Support heuristically using sampling and a binomial test (for
 * #supported) or binomial interval (for #support). <b>No</b> multiple
 * hypothesis testing correction is applied.
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class BinomialSC<NL, EL, G extends Graph<NL, EL>> extends AbstractSC<NL, EL, G> {
    private static final Logger logger = LoggerFactory.getLogger(BinomialSC.class);
    protected static final int minSampleSize = 30;

    protected double alpha;
    protected double maxError;
    protected final boolean fpPreFiltering;

    private BinomialTest binTest = new BinomialTest();

    /**
     * Constructor.
     * 
     * maxError is fixed to 0.1 (see
     * {@link #BinomialSC(double, double, MutableInt)})-
     * 
     * @param alpha
     *            the significance level for the binomial test
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism}
     */
    public BinomialSC(double alpha, MutableInt parallelism) {
        this(alpha, 0.1, parallelism);
    }

    /**
     * Constructor.
     * 
     * maxError is fixed to 0.1 (see
     * {@link #BinomialSC(double, double, MutableInt)})-
     * 
     * @param alpha
     *            the significance level for the binomial test
     * @param fpPreFiltering
     *            if true fingerprint prefiltereing is applied before running
     *            subgraph isomorphism tests.
     * @param fpBuilder
     *            the {@link FingerprintBuilder} to calculate fingerprints for
     *            the search patterns. This is allowed to be null if
     *            fpPreFiltering is set to false.
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism}
     */
    public BinomialSC(double alpha, boolean fpPreFiltering, FingerprintBuilder fpBuilder, MutableInt parallelism) {
        this(alpha, 0.1, fpPreFiltering, fpBuilder, parallelism);
    }

    /**
     * Constructor
     * 
     * @param alpha
     *            the significance level for the binomial test
     * @param maxError
     *            the relative maximal error for {@link #support(List, Graph)}.
     *            E.g. a value of 0.1 means, that that the error is smaller than
     *            0.1 times the support value with probability 1-alpha.
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism}
     */
    public BinomialSC(double alpha, double maxError, MutableInt parallelism) {
        this(alpha, maxError, false, null, parallelism);
    }

    /**
     * Constructor
     * 
     * @param alpha
     *            the significance level for the binomial test
     * @param maxError
     *            the relative maximal error for {@link #support(List, Graph)}.
     *            E.g. a value of 0.1 means, that that the error is smaller than
     *            0.1 times the support value with probability 1-alpha.
     * @param fpPreFiltering
     *            if true fingerprint prefiltereing is applied before running
     *            subgraph isomorphism tests.
     * @param fpBuilder
     *            the {@link FingerprintBuilder} to calculate fingerprints for
     *            the search patterns. This is allowed to be null if
     *            fpPreFiltering is set to false.
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism})
     */
    public BinomialSC(double alpha, double maxError, boolean fpPreFiltering, FingerprintBuilder fpBuilder,
            MutableInt parallelism) {
        super(fpBuilder, parallelism);
        Preconditions.checkArgument(!fpPreFiltering || fpBuilder != null,
                "fpBuilder must NOT be null if fpPreFiltering is true");
        this.alpha = alpha;
        this.maxError = maxError;
        this.fpPreFiltering = fpPreFiltering;
    }

    @Override
    public boolean supported(List<GraphContainer<NL, EL, G>> graphs, G pattern, double minSup, int numHypothesis,
            boolean parallel) {
        return supported(graphs, pattern, minSup, parallel, alpha);
    }

    protected boolean supported(List<GraphContainer<NL, EL, G>> graphs, G pattern, double minSup, boolean parallel,
            double alpha) {
        Preconditions.checkArgument(!graphs.isEmpty(), "graphs must not be empty");

        // RAND: draw random graphs
        RandomQueue<GraphContainer<NL, EL, G>> rq = new RandomQueue<>(graphs);
        int sampleSize = Math.min(minSampleSize, graphs.size());
        int alreadyTested = 0;
        int numSuportedGraphs = 0;
        double sampleSupport;
        BitFingerprint patternFp = null;
        while (!rq.isEmpty()) {
            List<GraphContainer<NL, EL, G>> currentGraphs = rq.multiPoll(sampleSize - alreadyTested);
            assert currentGraphs.size() == sampleSize - alreadyTested : "random Queue vs sample size mismatch: currentGraphs.size: "
                    + currentGraphs.size() + ", current sample size: " + (sampleSize - alreadyTested);
            if (fpPreFiltering) {
                if (patternFp == null) {
                    patternFp = fpBuilder.getFingerprint(pattern);
                }
                currentGraphs = calculateCandidates(currentGraphs, pattern, patternFp);
            }
            numSuportedGraphs += numSuportedGraphs(currentGraphs, pattern, parallel);
            sampleSupport = (double) numSuportedGraphs / sampleSize;
            if (sampleSupport < minSup) {
                boolean binomialTest = binTest.binomialTest(sampleSize, numSuportedGraphs, minSup,
                        AlternativeHypothesis.LESS_THAN, alpha);
                if (binomialTest) {
                    logger.debug(
                            "Quitting. Binomiual Test passed with {} / {} graphs tested. Sample support {}, min support {}",
                            sampleSize, graphs.size(), sampleSupport, minSup);
                    return false;
                } else {
                    logger.debug(
                            "Continiue. Binomiual Test failed with {} / {} graphs tested. Sample support {}, min support {}",
                            sampleSize, graphs.size(), sampleSupport, minSup);
                }
            } else if (sampleSupport > minSup) {
                boolean binomialTest = binTest.binomialTest(sampleSize, numSuportedGraphs, minSup,
                        AlternativeHypothesis.GREATER_THAN, alpha);
                if (binomialTest) {
                    logger.debug(
                            "Quitting. Binomiual Test passed with {} / {} graphs tested. Sample support {}, min support {}",
                            sampleSize, graphs.size(), sampleSupport, minSup);
                    return true;

                } else {
                    logger.debug(
                            "Continiue. Binomiual Test failed with {} / {} graphs tested. Sample support {}, min support {}",
                            sampleSize, graphs.size(), sampleSupport, minSup);
                }
            }

            alreadyTested = sampleSize;
            sampleSize = Math.min(sampleSize * 2, graphs.size());
        }
        assert sampleSize == graphs.size();

        logger.debug("Quitting. Exact Test over {} graphs.", graphs.size());
        return numSuportedGraphs >= minSup * graphs.size();
    }

    @Override
    public String getDescription() {
        return "BinomialSC(alpha: " + alpha + ", maxError: " + maxError + ", minSampleSize: " + minSampleSize
                + ", fpPreFiltering: " + fpPreFiltering + ")";
    }

    @Override
    public double support(List<GraphContainer<NL, EL, G>> graphs, G pattern, boolean parallel) {
        Preconditions.checkArgument(!graphs.isEmpty(), "graphs must not be empty");
        Preconditions.checkNotNull(pattern);

        // RAND: draw random graphs
        RandomQueue<GraphContainer<NL, EL, G>> rq = new RandomQueue<>(graphs);
        int sampleSize = Math.min(minSampleSize, graphs.size());
        int alreadyTested = 0;
        int numSuportedGraphs = 0;
        double sampleSupport = Double.NaN;
        BitFingerprint patternFp = null;
        while (!rq.isEmpty()) {
            List<GraphContainer<NL, EL, G>> currentGraphs = rq.multiPoll(sampleSize - alreadyTested);
            assert currentGraphs.size() == sampleSize - alreadyTested : "random Queue vs sample size mismatch: currentGraphs.size: "
                    + currentGraphs.size() + ", current sample size: " + (sampleSize - alreadyTested);
            if (fpPreFiltering) {
                if (patternFp == null) {
                    patternFp = fpBuilder.getFingerprint(pattern);
                }
                currentGraphs = calculateCandidates(currentGraphs, pattern, patternFp);
            }
            numSuportedGraphs += numSuportedGraphs(currentGraphs, pattern, parallel);

            BinomialConfidenceInterval bInterval = new NormalApproximationInterval();
            if (numSuportedGraphs == sampleSize) {
                logger.debug("Quitting with 100% supported");
                return 1;
            }
            if (numSuportedGraphs == 0) {
                logger.debug("Quitting with 0% supported");
                return 0;
            }
            ConfidenceInterval interval = bInterval.createInterval(sampleSize, numSuportedGraphs, 1 - alpha);

            double intervalWidth = interval.getUpperBound() - interval.getLowerBound();
            sampleSupport = (double) numSuportedGraphs / sampleSize;

            if (intervalWidth < maxError * sampleSupport * 2) {
                logger.debug(
                        "Quitting. Error small enough for {} / {} graphs tested. Sample support {}, interval width {}",
                        sampleSize, graphs.size(), sampleSupport, intervalWidth);
                return sampleSupport;
            } else {
                logger.debug(
                        "Continiue. Error to large for {} / {} graphs tested. Sample support {}, interval width {}",
                        sampleSize, graphs.size(), sampleSupport, intervalWidth);
            }

            alreadyTested = sampleSize;
            sampleSize = Math.min(sampleSize * 2, graphs.size());
        }
        assert sampleSize == graphs.size();
        assert !Double.isNaN(sampleSupport);

        logger.debug("Quitting. Exact Support over {} graphs.", graphs.size());
        return sampleSupport;
    }

}
