package struclust.mining;

import graph.Graph;
import index.features.BitFingerprint;
import index.features.FingerprintBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;

import match.MatcherFast;
import match.pattern.SearchPattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import struclust.SharedMemorySCC;
import struclust.datastructures.MutableInt;
import struclust.graph.GraphContainer;
import struclust.util.Concurrent;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.ThreadFactoryBuilder;

/**
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public abstract class AbstractSC<NL, EL, G extends Graph<NL, EL>> implements SupportCounting<NL, EL, G> {
    private static final Logger logger = LoggerFactory.getLogger(AbstractSC.class);

    protected FingerprintBuilder fpBuilder;
    protected ExecutorService executor;

    /**
     * Constructor
     * 
     * @param fpBuilder
     *            the {@link FingerprintBuilder} to calculate fingerprints for
     *            the search patterns
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism}
     */
    protected AbstractSC(FingerprintBuilder fpBuilder, MutableInt parallelism) {
        this.fpBuilder = fpBuilder;
        final ThreadFactory threadFactory = new ThreadFactoryBuilder().setNameFormat("SupportCounting-%d")
                .setDaemon(true).build();
        executor = Executors.newFixedThreadPool(Concurrent.getEffectiveParallelism(parallelism.get()), threadFactory);
    }

    /**
     * Constructor<br>
     * 
     * <b>Attention:</b> If this constructor is used
     * {@link #calculateCandidates(List, Graph, BitFingerprint)} cannot be
     * called with a null parameter for the patternFP.
     *
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism}
     */
    protected AbstractSC(MutableInt parallelism) {
        this.fpBuilder = null;
        final ThreadFactory threadFactory = new ThreadFactoryBuilder().setNameFormat("SupportCounting-%d")
                .setDaemon(true).build();
        executor = Executors.newFixedThreadPool(Concurrent.getEffectiveParallelism(parallelism.get()), threadFactory);
    }

    /**
     * calculates the total number of supported graphs (without finderprint
     * prefiltering)
     * 
     * @param graphs
     *            the set of graphs in which are searched
     * @param pattern
     *            the pattern to search for
     * @param parallel
     * @return the total number of supported graphs
     */
    protected int numSuportedGraphs(List<GraphContainer<NL, EL, G>> graphs, G pattern) {
        return numSuportedGraphs(graphs, pattern, true);
    }

    /**
     * calculates the total number of supported graphs (without finderprint
     * prefiltering)
     * 
     * @param graphs
     *            the set of graphs in which are searched
     * @param pattern
     *            the pattern to search for
     * @param parallel
     *            whether the task should be executed in parallel
     * @return the total number of supported graphs
     */
    protected int numSuportedGraphs(List<GraphContainer<NL, EL, G>> graphs, G pattern, boolean parallel) {
        int count = 0;
        /*
         * PERF: Extend Pattern interface for external prio hashmap (similar to
         * molecule node prio). If we already know the node frequency, we can
         * use it here for faster matching.
         * 
         * Background: Normal Molecule prio was slow here. Maybe the general
         * frequencies do not apply here because of fingerprint prefiltering or
         * the way we construct our patterns.
         */
        SearchPattern<NL, EL> sp = new SearchPattern<>(pattern, false);

        if (parallel) {
            int batchSize = 20;
            List<Future<Integer>> futures = new ArrayList<>(graphs.size());
            for (List<GraphContainer<NL, EL, G>> gcs : Lists.partition(graphs, batchSize)) {
                // PARALLEL: number of supported graphs
                futures.add(executor.submit(new MatcherJob(sp, gcs)));
            }
            try {
                for (Future<Integer> future : futures) {
                    count += future.get();
                }
            } catch (InterruptedException e) {
                logger.warn("support counting aborted");
            } catch (ExecutionException e) {
                logger.error("Error while support counting in parallel", e);
                throw new RuntimeException("ExecutionException while support counting in parallel", e);
            }
        } else {
            count = new MatcherJob(sp, graphs).call();
        }
        return count;
    }

    /**
     * Calculates the candidates of supported graphs by fingerprint
     * pre-filtering (i.e. it filters out some graphs, that are definitely not
     * supported)<br>
     *
     * Assumes that the fingerprints are already calculated for all graphs
     * (excluding the pattern).
     * 
     * @param graphs
     *            the graphs
     * @param pattern
     *            the pattern
     * @param patterFp
     *            the {@link BitFingerprint} of the pattern graph. If null, the
     *            Fingerprint is calculated on demand (for each call). Note,
     *            that patternFp must not be null if fpBuilder is not set.
     * @return the candidates for supported graphs
     */
    protected ArrayList<GraphContainer<NL, EL, G>> calculateCandidates(List<GraphContainer<NL, EL, G>> graphs,
            G pattern, BitFingerprint patternFp) {
        // calculate fingerprint for search pattern
        if (patternFp == null) {
            patternFp = fpBuilder.getFingerprint(pattern);
        }
        ArrayList<GraphContainer<NL, EL, G>> candidates = new ArrayList<>();

        for (GraphContainer<NL, EL, G> graph : graphs) {
            if (graph.getFp().contains(patternFp)) {
                candidates.add(graph);
            }
        }
        return candidates;
    }

    /**
     * parallelize support counting
     * 
     * @author Till Schäfer
     *
     */
    private class MatcherJob implements Callable<Integer> {

        private SearchPattern<NL, EL> sp;
        private List<GraphContainer<NL, EL, G>> gcs;

        public MatcherJob(SearchPattern<NL, EL> sp, List<GraphContainer<NL, EL, G>> gcs) {
            this.sp = sp;
            this.gcs = gcs;
        }

        @Override
        public Integer call() {
            Integer retVal = 0;

            for (GraphContainer<NL, EL, G> gc : gcs) {
                if (new MatcherFast<NL, EL>(sp, gc).match()) {
                    retVal++;
                }
            }

            return retVal;
        }

    }

}
