package struclust.util;

import java.util.Collection;
import java.util.List;
import java.util.function.ToDoubleFunction;

import graph.Graph;
import struclust.Cluster;

/**
 * Convenience methods to calculate ratings and measures that may be reused
 * among different modules.
 * 
 * @author Till Schäfer
 */
public class Ratings {
    /**
     * Calculates the relative repToMemberSize size in comparison with all other
     * clusters.
     * 
     * <pre>
     * If k is the current cluster:
     * 
     *                 avgRepSize_k / avgMemberSize_k
     * relRelRepSize = ----------------------------------------------------
     *                 avg_{i \in clusters} (avgRepSize_i / avgMemberSize_i)
     * 
     * </pre>
     * 
     * @param current
     *            the cluster to calculate the rating for. Must have a non-empty
     *            collection of representatives and cluster members.
     * @param validClusters
     *            all other clusters. All Clusters must have a non-empty
     *            collection of representatives and cluster members.
     * @return relRepSize
     */
    public static <NL, EL, G extends Graph<NL, EL>> double relRepToMemberSize(Cluster<NL, EL, G> current,
            List<Cluster<NL, EL, G>> validClusters) {
        assert !current.isEmpty();
        assert !current.getRepresentatives().isEmpty();
        for (Cluster<NL, EL, G> cluster : validClusters) {
            assert !cluster.isEmpty();
            assert !cluster.getRepresentatives().isEmpty();
        }

        double avgAllRelRepSize = validClusters.stream().mapToDouble(x -> x.getRepToMemberSize()).average()
                .getAsDouble();

        double relRepSize = current.getRepToMemberSize() / avgAllRelRepSize;
        return relRepSize;
    }

    /**
     * @return the weighted average over all cluster regarding the
     *         repToMemberSizeValue
     */
    public static ToDoubleFunction<Collection<? extends Cluster<?, ?, ?>>> weightedAvgRTMS() {
        return new ToDoubleFunction<Collection<? extends Cluster<?, ?, ?>>>() {

            @Override
            public double applyAsDouble(Collection<? extends Cluster<?, ?, ?>> clusters) {
                int numElements = clusters.stream().mapToInt(c -> c.size()).sum();
                return clusters.stream().mapToDouble(c -> c.getRepToMemberSize() * c.size() / numElements).sum();
            }

            @Override
            public String toString() {
                return "weightedAvgRTMS";
            }
        };
    }

    /**
     * weightedAvgRTMS / (cluster ^ numClustExponent)
     * 
     * @param numClustExponent
     *            adjustment of the influence of the number of clusters. larger
     *            values increase the balance towards the number of clusters.
     * @return the weighted average over all cluster regarding the
     *         repToMemberSizeValue divided by the number of clusters to the
     *         power of numClustExponent
     */
    public static ToDoubleFunction<Collection<? extends Cluster<?, ?, ?>>> wAvgRTMS2NumClust(double numClustExponent) {
        return new ToDoubleFunction<Collection<? extends Cluster<?, ?, ?>>>() {

            @Override
            public double applyAsDouble(Collection<? extends Cluster<?, ?, ?>> clusters) {
                int numElements = clusters.stream().mapToInt(c -> c.size()).sum();
                return clusters.stream().mapToDouble(c -> c.getRepToMemberSize() * c.size() / numElements).sum()
                        / Math.pow(clusters.size(), numClustExponent);
            }

            @Override
            public String toString() {
                return "wAvgRTMS2NumClust (" + numClustExponent + ")";
            }
        };
    }
}
