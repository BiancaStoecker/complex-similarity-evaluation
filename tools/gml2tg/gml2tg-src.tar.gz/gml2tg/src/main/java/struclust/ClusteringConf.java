package struclust;

import struclust.eval.MetaDataAddable;

/**
 * Configuration object for {@link Clustering}
 * 
 * @author Till Schäfer
 * 
 * @param <T>
 *            the data type
 */
public interface ClusteringConf<T> extends Cloneable, MetaDataAddable {

}
