package struclust.granularity;

import graph.Graph;

import java.util.List;

import org.apache.commons.lang3.tuple.Pair;

import struclust.Cluster;
import struclust.ClusterFactory;
import struclust.Describable;
import struclust.StructuralClustering;

/**
 * A merge strategy merges a list of cluster pairs.
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface MergeStrategy<NL, EL, G extends Graph<NL, EL>> extends Describable {
    /**
     * Merge cluster pairs in toMerge
     * 
     * @param toMerge
     *            the cluster pairs to merge.
     * @param allClusters
     *            all clusters in the current clustering (including the clusters
     *            form toSplit).
     * @param clusterFactory
     *            for the creation of clusters with unique id
     * @param parentClusterer
     *            the parent clustering algorithm (used for representative
     *            updates)
     * @return the merged clustering (all clusters after merging)
     */
    public List<Cluster<NL, EL, G>> merge(List<Pair<Cluster<NL, EL, G>, Cluster<NL, EL, G>>> toMerge,
            List<Cluster<NL, EL, G>> allClusters, ClusterFactory<NL, EL, G> clusterFactory,
            StructuralClustering<NL, EL, G> parentClusterer);
}
