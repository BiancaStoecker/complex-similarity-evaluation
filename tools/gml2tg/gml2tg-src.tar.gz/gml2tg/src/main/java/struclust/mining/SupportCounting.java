package struclust.mining;

import graph.Graph;

import java.util.List;

import struclust.Describable;
import struclust.graph.GraphContainer;

/**
 * Interface for a support counting strategy. That means it checks if the
 * frequency of a search pattern exceeds a specified threshold in a set of
 * graphs. The frequency is measured in terms of subgraph isomorphism.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface SupportCounting<NL, EL, G extends Graph<NL, EL>> extends Describable {

    /**
     * Checks if the patter is supported with a frequency of minSup in the set
     * graphs.
     * 
     * @param graphs
     *            the set of graphs (not null)
     * @param pattern
     *            the search pattern (not null)
     * @param minSup
     *            relative frequency in the interval [0,1] (i.e. a support
     *            threshold of 10% is equal to a value of 0.1)
     * @return whether the pattern is supported
     */
    default public boolean supported(List<GraphContainer<NL, EL, G>> graphs, G pattern, double minSup) {
        return supported(graphs, pattern, minSup, 0, true);
    }

    /**
     * Checks if the patter is supported with a frequency of minSup in the set
     * graphs.
     * 
     * @param graphs
     *            the set of graphs (not null)
     * @param pattern
     *            the search pattern (not null)
     * @param minSup
     *            relative frequency in the interval [0,1] (i.e. a support
     *            threshold of 10% is equal to a value of 0.1)
     * @param numHypothesis
     *            this parameter allows Bonferroni compensation of multiple
     *            hypothesis testing. It should be set to the maximum number of
     *            possible {@link #supported(List, Graph, double, int, boolean)}
     *            calls within the test group. This parameter is only usable for
     *            stochastic approximations and therefore might be ignored by
     *            some implementations of this interface. The value must be
     *            greater or equal to 1. For uncorrected testing choose 1.
     * @param parallel
     *            whether the task is allowed to be executed in parallel,
     *            default is true
     * 
     * @return whether the pattern is supported
     */
    public boolean supported(List<GraphContainer<NL, EL, G>> graphs, G pattern, double minSup, int numHypothesis,
            boolean parallel);

    /**
     * Calculates the support / frequency of the pattern in the set of graphs
     * 
     * @param graphs
     *            the set of graphs (not null)
     * @param pattern
     *            the search pattern (not null)
     * @return relative frequency in the interval [0,1] (i.e. a support of 10%
     *         is equal to a value of 0.1)
     */
    default public double support(List<GraphContainer<NL, EL, G>> graphs, G pattern) {
        return support(graphs, pattern, true);
    }

    /**
     * Calculates the support / frequency of the pattern in the set of graphs
     * 
     * @param graphs
     *            the set of graphs (not null)
     * @param pattern
     *            the search pattern (not null)
     * @param parallel
     *            whether the task is allowed to be executed in parallel,
     *            default is true
     * @return relative frequency in the interval [0,1] (i.e. a support of 10%
     *         is equal to a value of 0.1)
     */
    public double support(List<GraphContainer<NL, EL, G>> graphs, G pattern, boolean parallel);

    /**
     * @return a short description of the {@link SupportCounting} including
     *         configuration parameters (single line)
     */
    @Override
    public String getDescription();
}
