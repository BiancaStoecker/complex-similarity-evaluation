package struclust.graph;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.math3.util.Pair;

import graph.Edge;
import graph.Graph;
import graph.GraphSize;
import graph.Node;
import index.features.BitFingerprint;

/**
 * Container class that encapsule a graph. It adds further attributes that are
 * used during clusteirng but not directly realated to the {@link Graph} itself.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class GraphContainer<NL, EL, G extends Graph<NL, EL>> implements Graph<NL, EL> {

    private final G graph;
    private BitFingerprint fp;
    private HashMap<String, String> properties = null;

    /**
     * Constructor
     * 
     * @param graph
     *            the {@link Graph} to encapsule
     */
    public GraphContainer(G graph) {
        this.graph = graph;
        setFp(null);
    }

    /**
     * Constructor
     * 
     * @param graph
     *            the {@link Graph} to encapsule
     * @param fp
     *            the structural fingerprint of the graph used for substructure
     *            filtering and distance measures
     */
    public GraphContainer(G graph, BitFingerprint fp) {
        this.graph = graph;
        this.setFp(fp);
    }

    /**
     * @return the encapsuled {@link Graph}
     */
    public G getGraph() {
        return graph;
    }

    /**
     * @return the structural fingerprint
     */
    public BitFingerprint getFp() {
        return fp;
    }

    /**
     * @return if a fingerprint is available
     */
    public boolean hasFp() {
        return fp != null;
    }

    /**
     * @param fp
     *            the structural fingerprint to set
     */
    public void setFp(BitFingerprint fp) {
        this.fp = fp;
    }

    /**
     * Invalidated the structural fingerprint. This should be usually called
     * after the structure of the graph has changed and the fingerprint is
     * outdated
     */
    public void invalidateFp() {
        fp = null;
    }

    /**
     * add an arbitrary property to the graph
     * 
     * @param key
     *            the key of the property
     * @param value
     *            the value of the property
     */
    public void putProperty(String key, String value) {
        if (properties == null) {
            properties = new HashMap<>();
        }
        properties.put(key, value);
    }

    /**
     * get a property of the graph
     * 
     * @param key
     *            the key of the property
     * @return the value of the property or null of the property is not stored
     */
    public String getProperty(String key) {
        return properties == null ? null : properties.get(key);
    }

    /**
     * @return an unmodifiable properties map
     */
    public Map<String, String> getProperties() {
        return Collections.unmodifiableMap(properties == null ? new HashMap<>() : properties);
    }

    @Override
    public List<? extends Node<NL, EL>> nodes() {
        return graph.nodes();
    }

    @Override
    public List<? extends Edge<NL, EL>> edges() {
        return graph.edges();
    }

    @Override
    public Node<NL, EL> getNode(int index) {
        return graph.getNode(index);
    }

    @Override
    public int getNodeCount() {
        return graph.getNodeCount();
    }

    @Override
    public int getEdgeCount() {
        return graph.getEdgeCount();
    }

    @Override
    @Deprecated
    public int size() {
        return graph.size();
    }

    @Override
    public int size(GraphSize s) {
        return graph.size(s);
    }

    @Override
    public boolean hasEdge(Node<NL, EL> u, Node<NL, EL> v) {
        return graph.hasEdge(u, v);
    }

    @Override
    public Edge<NL, EL> getEdge(Node<NL, EL> u, Node<NL, EL> v) {
        return graph.getEdge(u, v);
    }

    @Override
    public Node<NL, EL> addNode(NL label) {
        return graph.addNode(label);
    }

    @Override
    public void removeNode(Node<NL, EL> u) {
        graph.removeNode(u);
    }

    @Override
    public Edge<NL, EL> addEdge(Node<NL, EL> u, Node<NL, EL> v, EL label) {
        return graph.addEdge(u, v, label);
    }

    @Override
    public void addEdge(Edge<NL, EL> e) {
        graph.addEdge(e);
    }

    @Override
    public void removeEdge(Edge<NL, EL> e) {
        graph.removeEdge(e);
    }

    @Override
    public Pair<? extends List<? extends Node<NL, EL>>, ? extends List<? extends Edge<NL, EL>>> addGraph(
            Graph<NL, EL> g) {
        return graph.addGraph(g);
    }

    @Override
    public String toString() {
        return graph.toString();
    }

    @Override
    public boolean isIndexConsistent() {
        return graph.isIndexConsistent();
    }

}
