package struclust.mining;

import graph.Graph;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import struclust.Describable;
import struclust.eval.MetaDataAddable;
import struclust.graph.GraphContainer;

/**
 * Interface of a frequent graph miner. That means it mines a collection of
 * frequent subgraphs {@link Graph}s for a given collection of {@link Graph}s.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface FrequentGraphMiner<NL, EL, G extends Graph<NL, EL>> extends Describable {

    /**
     * mines a collection of representative {@link Graph}s
     * 
     * @param graphs
     *            the {@link Graph}s to mine
     * @param count
     *            the number of representative {@link Graph}s that should be
     *            mined
     * @param minSup
     *            the minimal support value
     * 
     * @return the mined subgraphs
     */
    public ArrayList<GraphContainer<NL, EL, G>> mineGraphs(List<GraphContainer<NL, EL, G>> graphs, int count,
            double minSup);

    /**
     * @param conf
     *            the configuration
     */
    public void setConf(GraphMinerConf<NL, EL, G> conf);

    /**
     * @return the configuration
     */
    public GraphMinerConf<NL, EL, G> getConf();

    /**
     * Interface for a {@link FrequentGraphMiner} configuration (i.e. the
     * configuration)
     * 
     * @author Till Schäfer
     *
     * @param <NL>
     *            the node label type
     * @param <EL>
     *            the edge label type
     * @param <G>
     *            the graph type
     */
    public abstract class GraphMinerConf<NL, EL, G> implements Cloneable, MetaDataAddable {
        private static final Logger logger = LoggerFactory.getLogger(GraphMinerConf.class);

        @Override
        public Object clone() {
            Object clone = null;
            try {
                clone = super.clone();
            } catch (CloneNotSupportedException e) {
                logger.error("This should be impossible", e);
            }
            return clone;
        }
    }
}
