package struclust.hashing;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.math3.util.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import it.unimi.dsi.fastutil.objects.Object2DoubleOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import struclust.comparison.JaccardIndexSBFVS;

/**
 * Does approximate {@link JaccardIndexSBFVS} range queries with min hashing,
 * i.e., find every object x, that fulfills jaccard(x,o) >= simThresh. The
 * approximation has no false positives, but may miss some objects (false
 * negatives). The miss rate can be bounded by a user defined probability.
 * 
 * The objects are mapped to binary sparse integer feature vectors in order to
 * apply the MinHashing and the JaccardDissimilarity.
 * 
 * @author Till Schäfer
 *
 * @param <O>
 *            the object type
 */
public class MinHashJaccardRangeQuery<O> {
    private static final Logger logger = LoggerFactory.getLogger(MinHashJaccardRangeQuery.class);

    private ArrayList<IntArrayHashTable<O, Set<Integer>, ContiuousIntHashFunction<Set<Integer>>>> tables = new ArrayList<>();
    private final JaccardIndexSBFVS<Integer> dist = new JaccardIndexSBFVS<>();

    private Function<? super O, ? extends Set<Integer>> okMapper;
    private double simThresh;

    /**
     * Constructor
     * 
     * @param objects
     *            the objects to do the range query over
     * @param okMapper
     *            the mapper, that maps the objects to binary sparse integer feature
     *            vectors
     * @param maxU
     *            the maximum feature vector integer
     * @param simThresh
     *            the jaccard similarity threshold
     * @param falseNegativeRate
     *            the maximal probabilistic miss rate
     * @param parallel
     *            if set true the hash table creation is done in parallel using java
     *            streams
     */
    public MinHashJaccardRangeQuery(Collection<O> objects, Function<? super O, ? extends Set<Integer>> okMapper,
            int maxU, double simThresh, double falseNegativeRate, boolean parallel) {
        this.okMapper = okMapper;
        this.simThresh = simThresh;

        int numHashTables = simThresh == 1 ? 1 : (int) Math.ceil(Math.log(falseNegativeRate) / Math.log(1 - simThresh));
        logger.info("using {} hash table(s)", numHashTables);
        IntStream tableIndicesStream = IntStream.range(0, numHashTables);
        if (parallel) {
            tableIndicesStream = tableIndicesStream.parallel();
        }

        tableIndicesStream.forEach(i -> {
            MinHashCIHF hf = new MinHashCIHF(new LookupTableCPIHF(maxU));
            IntArrayHashTable<O, Set<Integer>, ContiuousIntHashFunction<Set<Integer>>> table = new IntArrayHashTable<>(
                    hf, okMapper);
            synchronized (tables) {
                tables.add(table);
            }
            table.addObjects(objects);
        });
    }

    /**
     * Query objects x in range <tt>jaccard(o,x) >= minThresh</tt>
     * 
     * @param o
     *            the query object
     * @return the objects in range
     */
    public Set<O> getObjectsInRange(O o) {
        Set<O> allObjects = new ObjectOpenHashSet<>();
        for (IntArrayHashTable<O, Set<Integer>, ContiuousIntHashFunction<Set<Integer>>> table : tables) {
            allObjects.addAll(table.elementsInBucketOf(o));
        }

        Set<O> retVal = allObjects.stream().filter(c -> dist.calc(okMapper.apply(c), okMapper.apply(o)) >= simThresh)
                .collect(Collectors.toCollection(ObjectOpenHashSet::new));

        logger.debug("retrieved {} candidates of {} real in range objects. ({}%)", allObjects.size(), retVal.size(),
                (double) retVal.size() / allObjects.size());

        return retVal;
    }

    /**
     * Query objects x in range <tt>jaccard(o,x) >= minThresh</tt> and return them
     * together with their distance
     * 
     * @param o
     *            the query object
     * @return a mapping from the objects in range (<em>inRangeObj</em>) to
     *         <tt>jaccard(o,inRangeObj)</tt>
     */
    public Map<O, Double> getObjectsWithDistInRange(O o) {
        Set<O> allObjects = new ObjectOpenHashSet<>();
        for (IntArrayHashTable<O, Set<Integer>, ContiuousIntHashFunction<Set<Integer>>> table : tables) {
            allObjects.addAll(table.elementsInBucketOf(o));
        }

        Map<O, Double> retVal = allObjects.stream()
                .map(c -> Pair.create(c, dist.calc(okMapper.apply(c), okMapper.apply(o))))
                .filter(t -> t.getValue() >= simThresh)
                .collect(Collectors.toMap(Pair::getFirst, Pair::getSecond, (a, b) -> {
                    throw new IllegalStateException();
                }, Object2DoubleOpenHashMap::new));

        logger.debug("retrieved {} candidates of {} real in range objects. ({}%)", allObjects.size(), retVal.size(),
                (double) retVal.size() / allObjects.size());

        return retVal;
    }

}
