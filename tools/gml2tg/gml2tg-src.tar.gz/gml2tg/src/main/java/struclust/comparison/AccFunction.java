package struclust.comparison;

/**
 * Functions, that can be used for accumulation of values.
 * 
 * @author Till Schäfer
 */
public enum AccFunction {
    /**
     * The minimum of all values
     */
    MIN,
    /**
     * The maximum of all values
     */
    MAX,
    /**
     * The average of all values
     */
    AVG,
    /**
     * The Sum of all values
     */
    SUM;
}
