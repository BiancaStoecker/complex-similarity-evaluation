package struclust.mining;

import graph.Graph;

import java.util.List;

import struclust.Describable;
import struclust.graph.GraphContainer;

import com.google.common.collect.HashMultimap;

/**
 * An estimator for the maximum number of calls of
 * {@link SupportCounting#supported(List, Graph, double, int, boolean)} for
 * mining a single pattern with {@link RandomGM}. This allows to correct for
 * multiple hypothesis testing.
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface SupportedCallsEstimator<NL, EL, G extends Graph<NL, EL>> extends Describable {
    /**
     * Estimates the the maximum number of calls of
     * {@link SupportCounting#supported(List, Graph, double, int, boolean)}
     * 
     * @param graphs
     *            the graphs to mine the pattern from.
     * @param minSup
     *            the minimum support threshold.
     * @param edgeMap
     *            the edge map from ORIGAMI for all frequent edges. Edge Map:
     *            Node Label -> (Edge Label, Other Nodes Label)
     * @return and estimation of the maximum pattern size (in terms of nodes)
     */
    public int estimate(List<GraphContainer<NL, EL, G>> graphs, double minSup,
            HashMultimap<NL, NodeEdgelabelPair<NL, EL>> edgeMap);
}
