package struclust.comparison;

import graph.Graph;
import struclust.Cluster;
import struclust.graph.GraphContainer;

/**
 * Distance between a {@link Cluster} and a {@link Graph}
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface ClusterGraphDistance<NL, EL, G extends Graph<NL, EL>>
        extends Distance<Cluster<NL, EL, G>, GraphContainer<NL, EL, G>> {
    /**
     * Calculate the distance between a {@link Cluster} and a {@link Graph}.
     * 
     * Cluster and graph must not be null and the cluster representatives must not
     * be empty.
     * 
     * @param cluster
     *            the {@link Cluster}
     * @param graph
     *            the {@link Graph}
     * @return the distance between {@link Cluster} and {@link Graph}
     */
    @Override
    public double calc(Cluster<NL, EL, G> cluster, GraphContainer<NL, EL, G> graph);

    /**
     * @return the used {@link GraphGraphDistance} for accumulating
     *         {@link ClusterGraphDistance}s or null in the other case.
     */
    public GraphGraphDistance<NL, EL, G> getGGDist();
}
