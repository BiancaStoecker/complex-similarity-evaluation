package struclust;

import graph.Graph;
import graph.GraphSize;

import java.util.Collection;
import java.util.LinkedList;

import struclust.graph.GraphContainer;

/**
 * Factory for generating clusters with unique ids.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class ClusterFactory<NL, EL, G extends Graph<NL, EL>> {
    private int currentClusterId = 0;
    private GraphSize gSize;

    /**
     * Constructor
     * 
     * @param conf
     *            the configuration
     */
    public ClusterFactory(SharedMemorySCC<NL, EL, G> conf) {
        gSize = conf.gSize;
    }

    /**
     * Constructor
     * 
     * @param gSize
     *            the {@link GraphSize} setting
     */
    public ClusterFactory(GraphSize gSize) {
        this.gSize = gSize;
    }

    /**
     * @return a new empty cluster (no representatives, no members)
     */
    public Cluster<NL, EL, G> emptyCluster() {
        Cluster<NL, EL, G> emptyCluster = new Cluster<>(new LinkedList<>(), new LinkedList<>(), currentClusterId, gSize);
        currentClusterId++;
        return emptyCluster;
    }

    /**
     * @param elements
     *            the elements of the Cluster
     * @param representatives
     *            the representatives of the cluster
     * @return an new cluster
     */
    public Cluster<NL, EL, G> newCluster(Collection<GraphContainer<NL, EL, G>> elements,
            Collection<GraphContainer<NL, EL, G>> representatives) {
        Cluster<NL, EL, G> emptyCluster = new Cluster<>(elements, representatives, currentClusterId, gSize);
        currentClusterId++;
        return emptyCluster;
    }

    /**
     * @param elements
     *            the elements of the Cluster
     * @return an new cluster with no representatives
     */
    public Cluster<NL, EL, G> newCluster(Collection<GraphContainer<NL, EL, G>> elements) {
        Cluster<NL, EL, G> emptyCluster = new Cluster<>(elements, new LinkedList<>(), currentClusterId, gSize);
        currentClusterId++;
        return emptyCluster;
    }

}
