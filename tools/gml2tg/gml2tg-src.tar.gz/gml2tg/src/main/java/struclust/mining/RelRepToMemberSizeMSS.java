package struclust.mining;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;

import graph.Graph;
import graph.GraphSize;
import struclust.Cluster;
import struclust.util.Ratings;

/**
 * Calculates the minimal support value, by using the representative divided by
 * the the cluster members size in relation to the average value over all
 * clusters.
 * 
 * <pre>
 * If k is the current cluster:
 * 
 *              avgRepSize_k / avgMemberSize_k
 * relRepSize = ----------------------------------------------------
 *              avg_{i \in clusters} (avgRepSize_i / avgMemberSize_i)
 * 
 * </pre>
 * 
 * It is possible to specify the a lower and an upper relRepSize together with
 * an associated minimal support value. The minimal support values scales linear
 * between this two points. Below and above this boundaries, the values are
 * constant.
 * 
 * Special Case: if the current {@link Cluster} or all {@link Cluster}s in the
 * parameter all do not contain any representative or member, the lowSup value
 * will be returned.
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class RelRepToMemberSizeMSS<NL, EL, G extends Graph<NL, EL>> implements MinSupStrategy<NL, EL, G> {

    private static final Logger logger = LoggerFactory.getLogger(RelRepToMemberSizeMSS.class);
    private double lowRelRepSize;
    private double lowSup;
    private double highRelRepSize;
    private double highSup;
    private int maxRepSize;
    private GraphSize gSize;

    /**
     * Constructor
     * 
     * @param lowRelRepSize
     *            the low value for the relRepSize (see class description).
     *            Example: A value of 0.5 means that the lowSup value will be
     *            used if the average representative size compared to the
     *            average member size is half as big as it is the average over
     *            all clusters.
     * @param lowSup
     *            the minimal minimum support value
     * @param highRelRepSize
     *            the high value for the relRepSize (see class description).
     *            Example: A value of 2.0 means that the highSup value will be
     *            used if the average representative size compared to the
     *            average member size is double as big as it is the average over
     *            all clusters.
     * @param highSup
     *            the maximum minimum support value
     */
    public RelRepToMemberSizeMSS(double lowRelRepSize, double lowSup, double highRelRepSize, double highSup) {
        this(lowRelRepSize, lowSup, highRelRepSize, highSup, Integer.MAX_VALUE, GraphSize.edges);
    }

    /**
     * Constructor
     * 
     * @param lowRelRepSize
     *            the low value for the relRepSize (see class description).
     *            Example: A value of 0.5 means that the lowSup value will be
     *            used if the average representative size compared to the
     *            average member size is half as big as it is the average over
     *            all clusters.
     * @param lowSup
     *            the minimal minimum support value
     * @param highRelRepSize
     *            the high value for the relRepSize (see class description).
     *            Example: A value of 2.0 means that the highSup value will be
     *            used if the average representative size compared to the
     *            average member size is double as big as it is the average over
     *            all clusters.
     * @param highSup
     *            the maximum minimum support value
     * @param maxRepSize
     *            if representative size is limited, clusters with
     *            representatives of this size should not be considered for
     *            relative score calculation. Furthermore, if the current
     *            cluster reaches the reprensetative size maximum, the highSup
     *            is returned.
     * @param gSize
     *            the way the graph size is measured
     */
    public RelRepToMemberSizeMSS(double lowRelRepSize, double lowSup, double highRelRepSize, double highSup,
            int maxRepSize, GraphSize gSize) {
        Preconditions.checkArgument(lowRelRepSize < highRelRepSize);

        this.lowRelRepSize = lowRelRepSize;
        this.lowSup = lowSup;
        this.highRelRepSize = highRelRepSize;
        this.highSup = highSup;
        this.maxRepSize = maxRepSize;
        this.gSize = gSize;
    }

    @Override
    public double calc(List<Cluster<NL, EL, G>> all, Cluster<NL, EL, G> current) {
        if (current.getRepresentatives().size() == 0 || current.size() == 0) {
            return lowSup;
        }

        if (current.getRepresentatives().stream().mapToInt(g -> g.size(gSize)).min().orElse(0) >= maxRepSize) {
            return highSup;
        }

        /*
         * Valid are clusters which are not empty and have no at least one
         * representative. Furthermore, if maxRepSize is specified, clusters
         * which reach the maxRepSize should not considered for score
         * calculation.
         */
        List<Cluster<NL, EL, G>> validClusters = all.stream()
                .filter(x -> x.getRepresentatives().size() != 0 && x.size() != 0
                        && x.getRepresentatives().stream().mapToInt(g -> g.size(gSize)).min().orElse(0) <= maxRepSize)
                .collect(Collectors.toList());
        if (validClusters.isEmpty()) {
            return lowSup;
        }

        double relRepSize = Ratings.relRepToMemberSize(current, validClusters);

        double retVal = 0;

        if (relRepSize < lowRelRepSize) {
            retVal = lowSup;
        } else if (relRepSize > highRelRepSize) {
            retVal = highSup;
        } else {
            double m = (highSup - lowSup) / (highRelRepSize - lowRelRepSize);
            double t = lowSup - (m * lowRelRepSize);
            retVal = m * relRepSize + t;
        }

        logger.debug("MinSup: {}, Cluster {}, RelRepSize {}", retVal, current.getId(), relRepSize);
        return retVal;
    }

    @Override
    public String getDescription() {
        return "RelRelRepToMemberSizeMSS (lowSize " + lowRelRepSize + ", lowSup " + lowSup + ", highSize "
                + highRelRepSize + ", highSup " + highSup + ")";
    }

}
