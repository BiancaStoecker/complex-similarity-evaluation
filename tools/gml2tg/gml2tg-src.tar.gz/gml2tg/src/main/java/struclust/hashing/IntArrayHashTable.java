package struclust.hashing;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;

/**
 * A {@link HashTable} that maps a ContiuousIntHashFunction to a continuous
 * integer array.
 * 
 * @author Till Schäfer
 * @param <O>
 *            the object type
 * @param <K>
 *            the key type
 * @param <H>
 *            the {@link HashFunction} type
 */
public class IntArrayHashTable<O, K, H extends ContiuousIntHashFunction<K>> implements HashTable<O, K, Integer, H> {

    private H hf;
    private ArrayList<ArrayList<O>> table;
    private Function<? super O, ? extends K> okMapper;
    private int size;

    /**
     * Constructor
     * 
     * @param hf
     *            the hash function to use
     * @param okMapper
     */
    public IntArrayHashTable(H hf, Function<? super O, ? extends K> okMapper) {
        this.hf = hf;
        this.okMapper = okMapper;
        table = newTable(hf);
        size = 0;
    }

    @Override
    public void setHashFunction(H hf) {
        List<O> storedObjects = getAllObjects();
        table = newTable(hf);
        this.hf = hf;
        addObjects(storedObjects);
    }

    @Override
    public void setObjectKeyMapper(Function<? super O, ? extends K> okMapper) {
        List<O> storedObjects = getAllObjects();
        table = newTable(hf);
        this.okMapper = okMapper;
        addObjects(storedObjects);
    }

    @Override
    public void addObjects(Collection<O> os) {
        for (O o : os) {
            add(o);
        }
    }

    @Override
    public void add(O o) {
        K key = okMapper.apply(o);
        Integer b = hf.hash(key);
        add(b, o);
    }

    @Override
    public ArrayList<O> getAllObjects() {
        ArrayList<O> retVal = new ArrayList<>();
        for (ArrayList<O> al : table) {
            if (al != null) {
                retVal.addAll(al);
            }
        }
        return retVal;
    }

    @Override
    public List<O> elementsInBucket(Integer v) {
        return Collections.unmodifiableList(table.get(v));
    }

    @Override
    public List<O> elementsInBucketOf(O o) {
        K key = okMapper.apply(o);
        Integer b = hf.hash(key);
        return Collections.unmodifiableList(table.get(b));
    }

    @Override
    public void clearTable() {
        table = newTable(hf);
        size = 0;
    }

    @Override
    public int size() {
        assert getAllObjects().size() == size;

        return size;
    }

    /**
     * Caclulated the table size based on the {@link ContiuousIntHashFunction}
     * 
     * @param hf
     *            the {@link HashFunction}
     * @return the size of the tabke
     */
    private int tableSizeOf(H hf) {
        return hf.maxValue() + 1;
    }

    /**
     * creates a new hash table filled with null values up to
     * {@link #tableSizeOf(ContiuousIntHashFunction)}
     * 
     * @param hf
     *            the {@link HashFunction}
     * @return new hash table
     */
    private ArrayList<ArrayList<O>> newTable(H hf) {
        return new ArrayList<>(Collections.nCopies(tableSizeOf(hf), null));
    }

    /**
     * add a Object to the bucket b and increase the size counter
     * 
     * @param b
     *            the bucket
     * @param o
     *            the object
     */
    private void add(Integer b, O o) {
        ArrayList<O> bucketList = table.get(b);
        if (bucketList == null) {
            bucketList = new ArrayList<>();
            bucketList.add(o);
            table.set(b, bucketList);
        } else {
            bucketList.add(o);
        }
        size++;
    }

}
