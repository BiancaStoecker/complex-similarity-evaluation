package struclust.comparison;

import graph.Graph;
import struclust.graph.GraphContainer;

/**
 * Distance between two Graphs
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface GraphGraphDistance<NL, EL, G extends Graph<NL, EL>>
        extends SameTypeDistance<GraphContainer<NL, EL, G>> {
    /**
     * Calculate the distance between two {@link Graph}s
     * 
     * @param graph1
     *            the first {@link Graph}. For directed distance measures this first
     *            {@link Graph} is always the pattern graph.
     * @param graph2
     *            the second {@link Graph}. For directed distance measures this
     *            second {@link Graph} is always the target/host graph.
     * @return the distance between graph1 and graph2
     */
    @Override
    public double calc(GraphContainer<NL, EL, G> graph1, GraphContainer<NL, EL, G> graph2);
}
