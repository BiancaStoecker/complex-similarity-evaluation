package struclust.mining;

import graph.Edge;
import graph.Graph;
import graph.LabelEdge;
import graph.Node;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import struclust.datastructures.CountingInt;
import struclust.datastructures.SwappingArrayList;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.HashMultimap;

/**
 * Encapsules the extensions to a node. It extends the graph given a source node
 * and tracks the which extensions already have been attempted. Furthermore, it
 * checks which extensions are possible at all.
 * 
 * Attention: The implementation is not Thread-Safe. Never try do concurrently
 * modify the same graph (with different NodeExtenders)
 * 
 * @author Till Schäfer
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
class NodeExtender<NL, EL> {
    private static final Logger logger = LoggerFactory.getLogger(NodeExtender.class);

    // RAND: for node extendsions
    private Random rand;

    /*
     * the node which we want to extend
     */
    private Node<NL, EL> sourceNode;

    /*
     * the graph of the sourceNode
     */
    private Graph<NL, EL> graph;

    /*
     * A set of extensions (in form of labels) that are possible for this node.
     * It is pruned after failed extension attempts and some other pruning
     * strategies.
     */
    private SwappingArrayList<NodeEdgelabelPair<NL, EL>> possibleExtensions;

    /*
     * the frequency of an edge (in form of labels) in the graph. It is used for
     * pruning the possibleExtensions
     */
    private HashMap<LabelEdge<NL, EL>, GraphCount> edgeFrequency;
    /*
     * the number of occurrences of an LabelEdge in the Graph
     * 
     * Attention: This value can be modified from outside between each
     * NodeExtender#nextExtension call
     */
    private HashMap<LabelEdge<NL, EL>, CountingInt> labelEdgeCount;
    private ArrayListMultimap<NL, Node<NL, EL>> nodesWithLabel;

    private HashSet<LabelEdge<NL, EL>> failedForwardExtensions = new HashSet<>();
    /**
     * for each extension node label -> store a list of failed backward nodes
     * together with the edge label
     */
    private HashMultimap<NL, NodeAndEdgeLabel<NL, EL>> failedBackwardExtensions = HashMultimap.create();

    private Edge<NL, EL> lastExtEdge = null;
    private Node<NL, EL> lastExtNode = null;

    private HashMap<Node<NL, EL>, NodeExtender<NL, EL>> extensions;

    private HashMultimap<NL, NodeEdgelabelPair<NL, EL>> edgeMap;

    /**
     * Constructor
     * 
     * @param graph
     *            the graph to extend
     * @param sourceNode
     *            the source node
     * @param edgeFrequency
     *            the edge frequencies
     * @param labelEdgeCount
     *            the current counts for each labelEdge
     * @param edgeMap
     *            the edge map
     * @param nodesWithLabel
     *            mapping from node labels to nodes in graph
     * @param rand
     *            reused random object
     * @param extensions
     *            the mapping from node to extender. We need this to tell the
     *            other nodes extender if we have added an edge, so that the
     *            reverse edge is not extended.
     */
    public NodeExtender(Graph<NL, EL> graph, Node<NL, EL> sourceNode,
            HashMap<LabelEdge<NL, EL>, GraphCount> edgeFrequency,
            HashMap<LabelEdge<NL, EL>, CountingInt> labelEdgeCount,
            HashMultimap<NL, NodeEdgelabelPair<NL, EL>> edgeMap, ArrayListMultimap<NL, Node<NL, EL>> nodesWithLabel,
            Random rand, HashMap<Node<NL, EL>, NodeExtender<NL, EL>> extensions) {
        this.graph = graph;
        this.sourceNode = sourceNode;
        this.edgeFrequency = edgeFrequency;
        this.labelEdgeCount = labelEdgeCount;
        this.edgeMap = edgeMap;
        this.nodesWithLabel = nodesWithLabel;
        this.rand = rand;
        this.extensions = extensions;

        possibleExtensions = new SwappingArrayList<>(edgeMap.get(sourceNode.getLabel()));

    }

    /**
     * Selects a random extension to the node. It automatically counts the
     * extensions and returns the same extension only maxCountInGraph (see
     * {@link GraphCount}) times.
     * 
     * Attention: You must call {@link NodeExtender#permanentlyApplyExtension}
     * or {@link NodeExtender#failLastExtension} before another call of this
     * method!
     * 
     * @return a random extension. That is the edge and the node that is added
     *         to the graph by this extension. If no extension is possible edge
     *         and node are null. If the extension was a backward extension to
     *         an existing node the node is null.
     */
    public NodeEdgePair<NL, EL> nextExtension() {
        logger.trace("---------- running extension on node " + sourceNode + " ------------");
        assert lastExtEdge == null;
        assert lastExtNode == null;

        while (true) {
            /*
             * lastExtEdge is null if there is no possible extension
             */
            if (possibleExtensions.isEmpty()) {
                return new NodeEdgePair<>(lastExtNode, lastExtEdge);
            }

            /*
             * select a possible extension (NodeEdgeLabelPair) randomly and
             * create a label edge from it
             */
            int randIndex = rand.nextInt(possibleExtensions.size());
            NodeEdgelabelPair<NL, EL> extension = possibleExtensions.get(randIndex);
            LabelEdge<NL, EL> extLE = new LabelEdge<NL, EL>(sourceNode.getLabel(), extension.nodeLabel,
                    extension.edgeLabel);

            /*
             * If we have already added this type of edge more times than its
             * occurrence in any graph we can directly abort this extension and
             * remove this extension from the possible extensions
             */
            CountingInt extLECount = labelEdgeCount.get(extLE);
            if (edgeFrequency.get(extLE).getMaxCountInGraph() <= (extLECount == null ? 0 : extLECount.get())) {
                possibleExtensions.swapAndRemove(randIndex);

                // try next extension
                continue;
            }

            /*
             * Randomly select if we want to do a forward or backward extension
             * 
             * The probability for the forward and each possible backward
             * extension is equally distributed. (e.g. if we have 2 possible
             * backward extensions, the probability to to an forward extension
             * is 1/3)
             */
            List<Node<NL, EL>> possibleBackExtNodes = possibleBackwardExtensions(extension);
            if (rand.nextDouble() < 1.0 / (possibleBackExtNodes.size() + 1) && !failedForwardExtensions.contains(extLE)) { // forward
                extendForward(extension, extLE);
                // we quit the loop because we found a valid forward extension
                return new NodeEdgePair<>(lastExtNode, lastExtEdge);
            } else if (possibleBackExtNodes.size() != 0) { // backward
                extendBackward(extension, extLE, possibleBackExtNodes);
                // we quit the loop because we found a valid backward extension
                return new NodeEdgePair<>(lastExtNode, lastExtEdge);
            } else { // no extension possible anymore
                possibleExtensions.swapAndRemove(randIndex);
            }
        }
    }

    /**
     * Calculate the possible backward extension nodes for a given label
     * extension
     * 
     * @param extension
     *            the extension in label form
     * @return possible backward extension nodes (i.e. all nodes that are not
     *         failed with this extension before and which are not the same node
     *         as the sourceNode)
     */
    private List<Node<NL, EL>> possibleBackwardExtensions(NodeEdgelabelPair<NL, EL> extension) {
        Set<NodeAndEdgeLabel<NL, EL>> failedBackExtNodes = failedBackwardExtensions.get(extension.nodeLabel);
        List<Node<NL, EL>> possibleBackExtNodes = new ArrayList<>(nodesWithLabel.get(extension.nodeLabel));
        possibleBackExtNodes.remove(sourceNode);
        // filter all failed backward extensions with the same label
        possibleBackExtNodes.removeAll(failedBackExtNodes.stream().filter(x -> x.edgeLabel.equals(extension.edgeLabel))
                .map(x -> x.node).collect(Collectors.toList()));
        return possibleBackExtNodes;
    }

    /**
     * Do a backward extension and set lastExtNode and lastExtEdge
     */
    private void extendBackward(NodeEdgelabelPair<NL, EL> extension, LabelEdge<NL, EL> extLE,
            List<Node<NL, EL>> possibleBackExtNodes) {
        Node<NL, EL> backExtNode = possibleBackExtNodes.get(rand.nextInt(possibleBackExtNodes.size()));

        lastExtNode = backExtNode;
        lastExtEdge = graph.addEdge(sourceNode, backExtNode, extension.edgeLabel);
    }

    /**
     * Do a forward extension and set lastExtNode and lastExtEdge
     */
    private void extendForward(NodeEdgelabelPair<NL, EL> extension, LabelEdge<NL, EL> extLE) {
        lastExtNode = graph.addNode(extension.nodeLabel);
        lastExtEdge = graph.addEdge(sourceNode, lastExtNode, extension.edgeLabel);
    }

    /**
     * Fail the last extension. I.e. remove the added nodes and edges form the
     * graph and remember the failed extension to not try it again.
     */
    public void failLastExtension() {
        assert lastExtEdge != null;
        assert lastExtNode != null;

        boolean isForwardExtension = lastExtNode.getDegree() == 1;
        if (isForwardExtension) {
            graph.removeNode(lastExtNode);
            failedForwardExtensions.add(new LabelEdge<>(lastExtEdge));
        } else {
            graph.removeEdge(lastExtEdge);
            invalidateBackExtension(lastExtNode, lastExtEdge.getLabel());
        }

        lastExtEdge = null;
        lastExtNode = null;
    }

    /**
     * Inform the node extender, that a extension was successful. It updates the
     * statistics of the graph (e.g. labelEdgeCount) and ensures, that this
     * extension will never be tried again (from this and the opposite node)
     */
    public void permanentlyApplyExtension() {
        assert lastExtEdge != null;
        assert lastExtNode != null;

        CountingInt.incrementCount(labelEdgeCount, new LabelEdge<>(lastExtEdge));

        boolean forwardExtension = lastExtNode.getDegree() == 1;
        if (forwardExtension) {
            assert !nodesWithLabel.get(lastExtNode.getLabel()).contains(lastExtNode);
            nodesWithLabel.get(lastExtNode.getLabel()).add(lastExtNode);

        }
        // never try this extension again as a backward extension
        invalidateBackExtension(lastExtNode, lastExtEdge.getLabel());

        /*
         * inform the other nodes extender about the new edge (that cannot be
         * extended anymore form the reverse direction)
         */
        NodeExtender<NL, EL> oppositeExtender = RandomGM.getExtender(edgeFrequency, edgeMap, graph, extensions,
                nodesWithLabel, labelEdgeCount, lastExtNode, rand);
        oppositeExtender.invalidateBackExtension(sourceNode, lastExtEdge.getLabel());

        lastExtEdge = null;
        lastExtNode = null;
    }

    /**
     * inform this extender, that an edge has been added to this node
     */
    private void invalidateBackExtension(Node<NL, EL> otherNode, EL edgeLabel) {
        failedBackwardExtensions.put(otherNode.getLabel(), new NodeAndEdgeLabel<NL, EL>(otherNode, edgeLabel));
    }

    /**
     * Simple struct to store a node and an edge label
     * 
     * @param <NL>
     * @param <EL>
     */
    @SuppressWarnings("hiding")
    private class NodeAndEdgeLabel<NL, EL> {
        public Node<NL, EL> node;
        public EL edgeLabel;

        public NodeAndEdgeLabel(Node<NL, EL> node, EL edgeLabel) {
            this.node = node;
            this.edgeLabel = edgeLabel;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null) {
                return false;
            }
            if (!(o instanceof NodeAndEdgeLabel)) {
                return false;
            }
            @SuppressWarnings("rawtypes")
            NodeAndEdgeLabel other = (NodeAndEdgeLabel) o;
            return new EqualsBuilder().append(node, other.node).append(edgeLabel, other.edgeLabel).isEquals();
        }

        @Override
        public int hashCode() {

            return new HashCodeBuilder().append(node).append(edgeLabel).hashCode();
        }
    }
}
