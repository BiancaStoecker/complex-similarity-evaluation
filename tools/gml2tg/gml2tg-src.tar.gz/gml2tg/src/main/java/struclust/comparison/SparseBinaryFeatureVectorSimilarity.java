package struclust.comparison;

import java.util.Set;

import struclust.Describable;

/**
 * Similarity between to sparse binary feature vectors. As the feature vectors
 * are sparse, they are represented by sets of positive entries.
 * 
 * @author Till Schäfer
 *
 * @param <T>
 *            the type of the features keys
 */
public interface SparseBinaryFeatureVectorSimilarity<T> extends Describable {
    /**
     * Calculate the distance between the vectors v1 and v2
     * 
     * @param v1
     *            the first binary vector
     * @param v2
     *            the second binary vector
     * @return the distance between v1 and v2
     */
    public double calc(Set<T> v1, Set<T> v2);

    /**
     * @return the maximum similarity value for this measure.
     */
    public double maxSim();
}
