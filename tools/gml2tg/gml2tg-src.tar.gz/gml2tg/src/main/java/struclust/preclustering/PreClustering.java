package struclust.preclustering;

import graph.Graph;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import struclust.Describable;
import struclust.graph.GraphContainer;

/**
 * Interface for a pre clustering. This is distinguishable from a normal
 * clustering by its semantic. A pre clustering should only give a good starting
 * point for the real clustering. Therefore this clusterings are usually
 * computationally lightweight and rough heuristics. Furthermore, the clusters
 * of a PreClustering have no representatives.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface PreClustering<NL, EL, G extends Graph<NL, EL>> extends Describable {
    /**
     * Calculated a pre clustering
     * 
     * @param graphs
     *            the {@link Collection} of {@link Graph}s to cluster
     * 
     * @return a {@link Collection} of clusters
     */
    public List<? extends List<GraphContainer<NL, EL, G>>> calc(ArrayList<GraphContainer<NL, EL, G>> graphs);

    /**
     * Calculated a pre clustering with a specified number of clusters.
     * 
     * <br>
     * <b>Attention:</b> some implementations may ignore the numCluster setting
     * or adjust the value to their needs.
     * 
     * @param graphs
     *            the {@link Collection} of {@link Graph}s to cluster
     * @param numClusters
     *            the desired number of clusters
     * 
     * @return a {@link Collection} of clusters
     */
    public List<? extends List<GraphContainer<NL, EL, G>>> calc(ArrayList<GraphContainer<NL, EL, G>> graphs,
            int numClusters);
}
