package struclust.hashing;

import com.google.common.base.Preconditions;

import struclust.util.Arrays;

/**
 * This {@link PerfectHashFunction} generates a random ordering of the
 * key-universe and the value of each key is mapped to the index in the
 * ordering. The universe is fixed to {@link Integer}s in the interval [0,maxU].
 * 
 * To store the ordering, a lookup table with linear size to the key universe U
 * is stored. The memory consumption and initialization complexity is in
 * &Theta;(U) and the lookup complexity is in O(1).
 * 
 * @author Till Schäfer
 */
public class LookupTableCPIHF
        implements ContinuousPerfectIntHashFunction<Integer> {

    private int[] table;

    /**
     * constructor
     * 
     * @param maxU
     *            the maximum Integer in the key universe [0,maxU]
     */
    public LookupTableCPIHF(int maxU) {
        Preconditions.checkArgument(maxU >= 0, "maxU must be positive");

        table = new int[maxU + 1];
        for (int i = 0; i < table.length; i++) {
            table[i] = i;
        }
        Arrays.fisherYatesShuffle(table);
    }

    @Override
    public Integer hash(Integer key) {
        assert key >= 0 || key < table.length : "key out of range";
        return table[key];
    }

    @Override
    public String getDescription() {
        return "ContinuousIntUniverseLookupTablePHF (maxU: " + maxValue() + ")";
    }

    @Override
    public Integer maxValue() {
        return table.length - 1;
    }

}
