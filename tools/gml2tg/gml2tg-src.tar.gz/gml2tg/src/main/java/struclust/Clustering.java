package struclust;

import java.util.List;

import struclust.eval.MetaDataAddable;

/**
 * This is the interface for a (flat) clustering algorithm.
 * 
 * @author Till Schäfer
 * 
 * @param <T>
 *            the data type
 */
public interface Clustering<T> extends MetaDataAddable {
    /**
     * Calculate the Clustering
     * 
     * @return the {@link Cluster}s
     */
    public List<? extends List<T>> calc();

    /**
     * @return the configuration of the clustering
     */
    public ClusteringConf<T> getConf();
}
