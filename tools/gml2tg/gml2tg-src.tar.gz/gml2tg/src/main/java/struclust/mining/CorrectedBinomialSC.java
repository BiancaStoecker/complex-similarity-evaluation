package struclust.mining;

import graph.Graph;
import index.features.FingerprintBuilder;

import java.util.List;

import org.apache.commons.math3.util.FastMath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import struclust.SharedMemorySCC;
import struclust.datastructures.MutableInt;
import struclust.graph.GraphContainer;

/**
 * Calculated the Support heuristically using sampling and a binomial test (for
 * #supported) or binomial interval (for #support).
 * 
 * Additionally to {@link BinomialSC}, a Bonferroni multiple hypothesis testing
 * correction is applied. It takes into account the numHypothesis parameter of
 * {@link #supported(List, Graph, double, int, boolean)} as well as the doubling
 * of the sample size (which is done internally in this module).
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class CorrectedBinomialSC<NL, EL, G extends Graph<NL, EL>> extends BinomialSC<NL, EL, G> {
    private static final Logger logger = LoggerFactory.getLogger(CorrectedBinomialSC.class);
    private static final double log2base10 = FastMath.log10(2);

    private double alphaSupported;

    /**
     * Constructor.
     * 
     * maxError is fixed to 0.1 (see
     * {@link #CorrectedBinomialSC(double, double, double, MutableInt)})-
     * 
     * @param alphaSupport
     *            the alpha value for the binomial interval
     * @param alphaSupported
     *            the uncorrected significance level for the binomial test
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism}
     */
    public CorrectedBinomialSC(double alphaSupport, double alphaSupported, MutableInt parallelism) {
        super(alphaSupport, parallelism);
        this.alphaSupported = alphaSupported;
    }

    /**
     * Constructor.
     * 
     * maxError is fixed to 0.1 (see
     * {@link #CorrectedBinomialSC(double, double, double, MutableInt)})-
     * 
     * @param alphaSupport
     *            the alpha value for the binomial interval
     * @param alphaSupported
     *            the uncorrected significance level for the binomial test
     * @param fpPreFiltering
     *            if true fingerprint prefiltereing is applied before running
     *            subgraph isomorphism tests.
     * @param fpBuilder
     *            the {@link FingerprintBuilder} to calculate fingerprints for
     *            the search patterns. This is allowed to be null if
     *            fpPreFiltering is set to false.
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism}
     */
    public CorrectedBinomialSC(double alphaSupport, double alphaSupported, boolean fpPreFiltering,
            FingerprintBuilder fpBuilder, MutableInt parallelism) {
        super(alphaSupport, fpPreFiltering, fpBuilder, parallelism);
        this.alphaSupported = alphaSupported;
    }

    /**
     * Constructor
     * 
     * @param alphaSupport
     *            the alpha value for the binomial interval
     * @param alphaSupported
     *            the uncorrected significance level for the binomial test
     * @param maxError
     *            the relative maximal error for {@link #support(List, Graph)}.
     *            E.g. a value of 0.1 means, that that the error is smaller than
     *            0.1 times the support value with probability 1-alpha.
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism})
     */
    public CorrectedBinomialSC(double alphaSupport, double alphaSupported, double maxError, MutableInt parallelism) {
        super(alphaSupport, maxError, parallelism);
        this.alphaSupported = alphaSupported;
    }

    /**
     * Constructor
     * 
     * @param alphaSupport
     *            the alpha value for the binomial interval
     * @param alphaSupported
     *            the uncorrected significance level for the binomial test
     * @param maxError
     *            the relative maximal error for {@link #support(List, Graph)}.
     *            E.g. a value of 0.1 means, that that the error is smaller than
     *            0.1 times the support value with probability 1-alpha.
     * @param fpPreFiltering
     *            if true fingerprint prefiltereing is applied before running
     *            subgraph isomorphism tests.
     * @param fpBuilder
     *            the {@link FingerprintBuilder} to calculate fingerprints for
     *            the search patterns. This is allowed to be null if
     *            fpPreFiltering is set to false.
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism})
     */
    public CorrectedBinomialSC(double alphaSupport, double alphaSupported, double maxError, boolean fpPreFiltering,
            FingerprintBuilder fpBuilder, MutableInt parallelism) {
        super(alphaSupport, maxError, fpPreFiltering, fpBuilder, parallelism);
        this.alphaSupported = alphaSupported;
    }

    @Override
    public boolean supported(List<GraphContainer<NL, EL, G>> graphs, G pattern, double minSup, int numHypothesis,
            boolean parallel) {
        double maxTimesSampleDoubling = FastMath.ceil(FastMath.log10(graphs.size() / minSampleSize) / log2base10);
        double bonferroniAlpha = alphaSupported / (maxTimesSampleDoubling * numHypothesis);

        logger.debug(
                "Bonferroni correction of alphaSupported: {}, alphaSupported: {}, maxTimesSampleDoubling: {}, numHypothesis: {}",
                bonferroniAlpha, alphaSupported, maxTimesSampleDoubling, numHypothesis);

        return supported(graphs, pattern, minSup, parallel, bonferroniAlpha);
    }

    @Override
    public String getDescription() {
        return "CorrectedBinomialSC(alphaSuppport: " + alpha + ", alphaSupported: " + alphaSupported + ", maxError: "
                + maxError + ", minSampleSize: " + minSampleSize + ", fpPreFiltering: " + fpPreFiltering + ")";
    }

}
