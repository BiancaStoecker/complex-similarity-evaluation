package struclust.granularity;

import graph.Graph;

import java.util.List;

import org.apache.commons.lang3.tuple.Pair;

import struclust.Cluster;
import struclust.Describable;

/**
 * Criteria, that defines which clusters should be merged (because they are two
 * close to each other)
 * 
 * @author Till Schäfer
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface MergeCriteria<NL, EL, G extends Graph<NL, EL>> extends Describable {
    /**
     * Calculate the pairs of clusters to merge.
     * 
     * <br>
     * Constraint: A cluster must be selected for only a single merge. That
     * means a cluster cannot occur in two distinct pairs.
     * 
     * @param clusters
     *            the complete clustering
     * @return the cluster pairs to merge
     */
    public List<Pair<Cluster<NL, EL, G>, Cluster<NL, EL, G>>> toMerge(List<Cluster<NL, EL, G>> clusters);
}
