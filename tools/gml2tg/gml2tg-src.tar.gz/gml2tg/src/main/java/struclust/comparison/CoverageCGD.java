package struclust.comparison;

import graph.Graph;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import patterncover.GraphCoverPair;
import patterncover.GraphDistance;
import struclust.Cluster;
import struclust.SharedMemorySCC;
import struclust.graph.GraphContainer;

/**
 * This {@link ClusterGraphDistance} calculates the coverage of nodes and edges
 * in the graph by the representatives of the cluster. In other words, coverage
 * can be defines as the number of nodes and/or edges in the graph that are part
 * of at least one embedding of any representative graph.
 *
 * <br>
 * The actual distance value is calculated by: 1 - coversize / graphsize
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class CoverageCGD<NL, EL, G extends Graph<NL, EL>> implements ClusterGraphDistance<NL, EL, G> {
    private static final Logger logger = LoggerFactory.getLogger(CoverageCGD.class);
    private GraphDistance<NL, EL> gDis = new GraphDistance<>();
    private SharedMemorySCC<NL, EL, G> conf;

    /**
     * Constructor
     * 
     * @param conf
     *            the configuration
     */
    public CoverageCGD(SharedMemorySCC<NL, EL, G> conf) {
        this.conf = conf;
    }

    @Override
    public double calc(Cluster<NL, EL, G> cluster, GraphContainer<NL, EL, G> graph) {

        if (cluster.getRepresentatives().isEmpty()) {
            return 1;
        }

        List<GraphCoverPair<NL, EL>> graphCoverPairs = gDis.calculateGraphCovers(Collections.singletonList(graph),
                cluster.getRepresentatives());

        assert graphCoverPairs.size() == 1;
        Graph<NL, EL> cover = graphCoverPairs.get(0).getCover();

        int coversize = cover.size(conf.gSize);
        double distance = coversize == 0 ? 1 : 1 - (double) coversize / graph.size(conf.gSize);
        logger.debug("Cover Size: {}, Graph Size {}, Value: {}", coversize, graph.size(conf.gSize), distance);
        assert distance <= 1.0 && distance >= 0.0;
        return distance;
    }

    @Override
    public double maxDist() {
        return 1;
    }

    @Override
    public GraphGraphDistance<NL, EL, G> getGGDist() {
        return null;
    }

    @Override
    public String getDescription() {
        return "Coverage Cluster Graph Distance";
    }

}
