package struclust.convergence;

import java.util.Collection;
import java.util.LinkedList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import struclust.Cluster;
import struclust.SharedMemorySCC;
import struclust.comparison.CoverageCGD;
import struclust.graph.GraphContainer;

/**
 * Assumes that the algorithm is convergent if the average coverage over the
 * last avgCount calls of
 * {@link ConvergenceCriteria#convergent(int, int, Collection)} are no longer
 * decreasing.
 * 
 * Special case: until avgCount change values are collected,
 * {@link ConvergenceCriteria#convergent(int, int, Collection)} will always
 * return false.
 * 
 * @author Till Schäfer
 */
public class CoverageIncreasingCC implements ConvergenceCriteria {
    private static final Logger logger = LoggerFactory.getLogger(CoverageIncreasingCC.class);

    @SuppressWarnings("rawtypes")
    private CoverageCGD dist;

    private int avgCount;
    private LinkedList<Double> values = new LinkedList<>();

    /**
     * Constructor
     * 
     * @param conf
     * 
     * @param avgCount
     *            the number of values which are considered for average
     *            calculation.
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public CoverageIncreasingCC(SharedMemorySCC conf, int avgCount) {
        this.avgCount = avgCount;
        dist = new CoverageCGD(conf);
    }

    @Override
    public boolean convergent(int changes, int totalElements, Collection<? extends Cluster<?, ?, ?>> clustering) {
        double averageCovered = 0;
        int count = 0;

        for (Cluster<?, ?, ?> cluster : clustering) {
            for (GraphContainer<?, ?, ?> gc : cluster) {
                @SuppressWarnings("unchecked")
                double percentageCovered = cluster.getRepresentatives().isEmpty() ? 0 : 1 - dist.calc(cluster, gc);
                averageCovered += percentageCovered;
                count++;
            }
        }

        averageCovered /= count;

        if (values.size() < avgCount) {
            values.add(averageCovered);
            logger.debug("average covered: {}, previous average: {}, current average {}", averageCovered, Double.NaN,
                    Double.NaN);
            return false;
        }

        assert values.size() == avgCount;

        double prevAvg = values.stream().mapToDouble(x -> x.doubleValue()).average().getAsDouble();
        values.add(averageCovered);
        values.remove();
        double currentAvg = values.stream().mapToDouble(x -> x.doubleValue()).average().getAsDouble();

        logger.debug("average covered: {}, previous average: {}, current average {}", averageCovered, prevAvg,
                currentAvg);

        return prevAvg >= currentAvg;
    }

    @Override
    public void reset() {
        values = new LinkedList<>();
        logger.debug("reseting");
    }

    @Override
    public String getDescription() {
        return "CoverageIncreasingCC over " + avgCount + " values)";
    }
}
