package struclust.mining;

import java.util.List;
import java.util.ListIterator;

import org.apache.commons.math3.stat.descriptive.rank.Percentile;
import org.apache.commons.math3.util.FastMath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.HashMultimap;

import graph.Graph;
import struclust.graph.GraphContainer;

/**
 * Estimates the supported calls, by
 * 
 * (V_max^2+V_max)*maxExtensionsPerNode
 * 
 * where V_max is estimated by the (1 - minSup) quantile of the graphs node
 * counts and maxExtensionsionsPerNode is the maximum number of FrequentEdges
 * with a common node label.
 * 
 * This is a conservative estimator that never underestimates the real node
 * count.
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class ConservativeSCE<NL, EL, G extends Graph<NL, EL>> implements SupportedCallsEstimator<NL, EL, G> {
    private static Logger logger = LoggerFactory.getLogger(ConservativeSCE.class);

    @Override
    public int estimate(List<GraphContainer<NL, EL, G>> graphs, double minSup,
            HashMultimap<NL, NodeEdgelabelPair<NL, EL>> edgeMap) {

        assert minSup >= 0 && minSup <= 1;

        double[] graphSizes = new double[graphs.size()];
        for (ListIterator<GraphContainer<NL, EL, G>> it = graphs.listIterator(); it.hasNext();) {
            int pos = it.nextIndex();
            graphSizes[pos] = it.next().getNodeCount();
        }

        double vMax = new Percentile().evaluate(graphSizes, 100 * Math.max(1. - minSup , 1. / graphs.size()));

        int maxExtensionsPerNode = 0;
        for (NL nl : edgeMap.keySet()) {
            maxExtensionsPerNode = FastMath.max(maxExtensionsPerNode, edgeMap.get(nl).size());
        }

        int maxExtensions = (int) ((FastMath.pow(vMax, 2) + vMax) * maxExtensionsPerNode);

        logger.debug("maxExtensions: {}, vMax: {}, maxExtensionsPerNode: {}", maxExtensions, vMax,
                maxExtensionsPerNode);

        return maxExtensions;
    }

    @Override
    public String getDescription() {
        return "ConservativeSCE";
    }

}
