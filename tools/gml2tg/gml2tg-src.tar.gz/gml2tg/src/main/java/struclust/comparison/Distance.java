package struclust.comparison;

import graph.Graph;
import struclust.Describable;

/**
 * Distance between two Objects. The Objects may have different type.
 * 
 * If the Distance is directed the direction is first -> second.
 * 
 * @author Till Schäfer
 *
 * @param <S>
 *            the first object type
 * @param <T>
 *            the second object type
 */
public interface Distance<S, T> extends Describable {
    /**
     * Calculate the distance between two {@link Graph}s
     * 
     * @param first
     *            the first {@link Object}.
     * @param second
     *            the second {@link Object}.
     * @return the distance between graph1 and graph2
     */
    public double calc(S first, T second);

    /**
     * @return the maximal value of this distance or NAN if there is no such value
     */
    public double maxDist();
}
