package struclust.granularity;

import graph.Graph;

import java.util.List;

import struclust.Cluster;
import struclust.Describable;

/**
 * Criteria, that defines which clusters should be split (because they are to
 * generic)
 * 
 * @author Till Schäfer
 *
 */
public interface SplitCriteria extends Describable {
    /**
     * calculate the clusters to split
     * 
     * @param clusters
     *            the complete clustering
     * @return the clusters to split
     */
    public <NL, EL, G extends Graph<NL, EL>> List<Cluster<NL, EL, G>> toSplit(List<Cluster<NL, EL, G>> clusters);
}
