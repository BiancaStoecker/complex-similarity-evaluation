package graph;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.math3.util.Pair;

import struclust.datastructures.SwappingArrayList;

/**
 * XXX: This implementation is not thread-safe!
 * 
 * @author Nils Kriege
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public class DefaultGraph<NL, EL> implements Graph<NL, EL>, Serializable {

    private static final long serialVersionUID = 1L;
    protected SwappingArrayList<DefaultNode<NL, EL>> nodes;
    protected int edgeCount;

    /**
     * Constructor
     */
    public DefaultGraph() {
        nodes = new SwappingArrayList<>();
        edgeCount = 0;
    }

    /**
     * Constructor
     * 
     * @param initialNodeCapacity
     *            the initial capacity of the underlying {@link Node} data
     *            structure
     */
    public DefaultGraph(int initialNodeCapacity) {
        nodes = new SwappingArrayList<>(initialNodeCapacity);
    }

    /**
     * Copy Constructor
     * 
     * @param g
     *            the {@link Graph} to copy
     */
    public DefaultGraph(Graph<NL, EL> g) {
        this(g.getNodeCount());

        addGraph(g);
    }

    @Override
    public DefaultGraph<NL, EL> clone() {
        return new DefaultGraph<>(this);
    }

    @Override
    public List<DefaultNode<NL, EL>> nodes() {
        return Collections.unmodifiableList(nodes);
    }

    @Override
    public List<DefaultEdge<NL, EL>> edges() {
        ArrayList<DefaultEdge<NL, EL>> edges = new ArrayList<>(edgeCount);
        for (DefaultNode<NL, EL> u : nodes)
            for (DefaultEdge<NL, EL> e : u.getEdges())
                if (u.getIndex() < e.getOppositeNode(u).getIndex())
                    edges.add(e);

        return edges;
    }

    @Override
    public DefaultNode<NL, EL> getNode(int index) {
        return nodes.get(index);
    }

    @Override
    public int getNodeCount() {
        return nodes.size();
    }

    @Override
    public int getEdgeCount() {
        assert edges().size() == edgeCount;
        return edgeCount;
    }

    @Override
    public boolean hasEdge(Node<NL, EL> u, Node<NL, EL> v) {
        return getEdge(u, v) != null;
    }

    @Override
    public DefaultEdge<NL, EL> getEdge(Node<NL, EL> u, Node<NL, EL> v) {
        assertValidNodeParameter(u);
        assertValidNodeParameter(v);

        if (u.getEdges().size() < v.getEdges().size()) {
            List<DefaultEdge<NL, EL>> edges = ((DefaultNode<NL, EL>) u).getEdges();
            for (DefaultEdge<NL, EL> e : edges)
                if (e.getOppositeNode(u) == v)
                    return e;
        } else {
            List<DefaultEdge<NL, EL>> edges = ((DefaultNode<NL, EL>) v).getEdges();
            for (DefaultEdge<NL, EL> e : edges)
                if (e.getOppositeNode(v) == u)
                    return e;
        }
        return null;
    }

    @Override
    public DefaultNode<NL, EL> addNode(NL label) {
        DefaultNode<NL, EL> node = new DefaultNode<>(label, nodes.size());
        nodes.add(node);
        return node;
    }

    @Override
    public DefaultEdge<NL, EL> addEdge(Node<NL, EL> u, Node<NL, EL> v, EL label) {
        assertValidNodeParameter(u);
        assertValidNodeParameter(v);

        DefaultEdge<NL, EL> edge = new DefaultEdge<>(u, v, label);
        u.addEdge(edge);
        v.addEdge(edge);
        edgeCount++;
        return edge;
    }

    @Override
    public Pair<ArrayList<DefaultNode<NL, EL>>, ArrayList<DefaultEdge<NL, EL>>> addGraph(Graph<NL, EL> g) {
        ArrayList<DefaultNode<NL, EL>> addedNodes = new ArrayList<>(g.getNodeCount());
        ArrayList<DefaultEdge<NL, EL>> addedEdges = new ArrayList<>(g.getEdgeCount());

        int offset = this.getNodeCount();

        for (int i = 0; i < g.getNodeCount(); i++)
            addedNodes.add(this.addNode(g.getNode(i).getLabel()));

        for (Edge<NL, EL> e : g.edges()) {
            DefaultNode<NL, EL> u = this.getNode(e.getFirstNode().getIndex() + offset);
            DefaultNode<NL, EL> v = this.getNode(e.getSecondNode().getIndex() + offset);
            addedEdges.add(this.addEdge(u, v, e.getLabel()));
        }
        return Pair.create(addedNodes, addedEdges);
    }

    @Override
    public String toString() {
        final String eol = System.getProperty("line.separator");
        StringBuilder sb = new StringBuilder();
        sb.append("V={");
        for (Node<NL, EL> n : nodes()) {
            sb.append("(");
            sb.append(n.getIndex());
            sb.append(",");
            sb.append(n.getLabel());
            sb.append(") ");
        }
        if (!nodes().isEmpty()) {
            sb.deleteCharAt(sb.length() - 1);
        }
        sb.append("}");
        sb.append(eol);
        sb.append("E={");
        for (Edge<NL, EL> e : edges()) {
            sb.append("(");
            sb.append(e.getFirstNode().getIndex());
            sb.append(",");
            sb.append(e.getSecondNode().getIndex());
            sb.append(",");
            sb.append(e.getLabel());
            sb.append(") ");
        }
        if (!edges().isEmpty()) {
            sb.deleteCharAt(sb.length() - 1);
        }
        sb.append("}");

        return sb.toString();
    }

    @Override
    public void addEdge(Edge<NL, EL> e) {
        assert !e.getFirstNode().getEdges().contains(e);
        assert !e.getSecondNode().getEdges().contains(e);

        e.getFirstNode().addEdge(e);
        e.getSecondNode().addEdge(e);
        edgeCount++;
    }

    @Override
    public void removeNode(Node<NL, EL> u) {
        assertValidNodeParameter(u);

        List<? extends Edge<NL, EL>> edges = new LinkedList<>(u.getEdges());
        for (Edge<NL, EL> adjEdge : edges) {
            removeEdge(adjEdge);
        }

        // the last node will get the index of the deleted one
        if (nodes.size() > 1) {
            nodes.get(nodes.size() - 1).setIndex(u.getIndex());
        }

        nodes.swapAndRemove(u.getIndex());

        assert isIndexConsistent();
    }

    @Override
    public void removeEdge(Edge<NL, EL> e) {
        assertValidNodeParameter(e.getFirstNode());
        assertValidNodeParameter(e.getSecondNode());

        e.getFirstNode().removeEdge(e);
        e.getSecondNode().removeEdge(e);
        edgeCount--;
    }

    /**
     * @param u
     */
    protected void assertValidNodeParameter(Node<NL, EL> u) {
        assert u instanceof DefaultNode;
        assert nodes.get(u.getIndex()) == u;
    }

    @Override
    public boolean isIndexConsistent() {
        for (int i = 0; i < getNodeCount(); i++) {
            DefaultNode<NL, EL> n = nodes.get(i);
            if (n.getIndex() != i) {
                return false;
            }

            for (DefaultEdge<NL, EL> e : n.getEdges()) {
                if (e.getOppositeNode(n).getIndex() >= nodes.size()) {
                    return false;
                }
            }
        }
        return true;
    }

}
