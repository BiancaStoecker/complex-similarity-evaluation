package graph;

import org.openscience.cdk.CDKConstants;
import org.openscience.cdk.interfaces.IBond;

/**
 * A {@link Graph} {@link DefaultEdge} that has additional linkage to the
 * corresponding {@link IBond}
 * 
 * @author Nils Kriege
 * 
 */
public class MoleculeEdge extends DefaultEdge<String, String> {
    private static final long serialVersionUID = 1L;
    
    IBond bond;

    /**
     * Constructor
     * 
     * @param u
     *            the fist incident {@link Node}
     * @param v
     *            the second incident {@link Node}
     * @param bond
     *            the linked bond
     */
    protected MoleculeEdge(Node<String, String> u, Node<String, String> v, IBond bond) {
        super(u, v, getLabel(bond));
        assert u instanceof MoleculeNode;
        assert v instanceof MoleculeNode;
        
        this.bond = bond;
    }

    /**
     * Constructor
     * 
     * @param u
     *            the fist incident {@link Node}
     * @param v
     *            the second incident {@link Node}
     * @param label
     *            the linked bond
     */
    protected MoleculeEdge(Node<String, String> u, Node<String, String> v, String label) {
        super(u, v, label);
        assert u instanceof MoleculeNode;
        assert v instanceof MoleculeNode;
        
        this.bond = null;
    }

    /**
     * Get the linked {@link IBond}
     * 
     * @return the linked {@link IBond} or null if not set
     */
    public IBond getBond() {
        return bond;
    }

    /**
     * Strip the {@link IBond} reference
     */
    public void stripIBond() {
        bond = null;
    }

    private static String getLabel(IBond bond) {
        // TODO dont misuse stereo bonds for wildcards
        if (bond.getStereo() == IBond.Stereo.E_OR_Z) {
            return "*";
        } else if (bond.getFlag(CDKConstants.ISAROMATIC)) {
            return ":";
        } else if (bond.getOrder() == IBond.Order.SINGLE) {
            return "-";
        } else if (bond.getOrder() == IBond.Order.DOUBLE) {
            return "=";
        } else if (bond.getOrder() == IBond.Order.TRIPLE) {
            return "#";
        } else if (bond.getOrder() == IBond.Order.UNSET) {
            return "?";
        } else {
            throw new IllegalArgumentException("Unknown bond type: " + bond.toString());
        }

    }
}
