package struclust.eval.testsetups.rahmannthreshgraphcli;

import com.beust.jcommander.Parameter;
import com.beust.jcommander.validators.PositiveInteger;

/**
 * The Parameters for
 * 
 * @author Till Schäfer
 *
 */
public class Parameters {
    @Parameter(names = { "--in" }, description = "The folder with the input gml files", required = true)
    String inGmlFolder;

    @Parameter(names = { "--out" }, description = "The results folder", required = true)
    String outFolder;

    @Parameter(names = { "--thresh" }, description = "The jaccard threshold", required = true)
    Double simThresh;

    @Parameter(names = {
            "--falsenegativerate" }, description = "Maximum expected false negative rate for min hash range query. "
                    + "The real error is usually much smaller.", required = false)
    Double falseNegativeRate = 0.01;

    @Parameter(names = {
            "--sizelimit" }, description = "Filter graphs smaller than this value from the input", required = false)
    Integer filterLargerThen = Integer.MAX_VALUE;

    @Parameter(names = {
            "--wl0weight" }, description = "Weight of the zeroth weisfeiler lehmann iteration", required = false, validateWith = {
                    PositiveInteger.class })
    Integer wl0weight = 1;

    @Parameter(names = {
            "--wl1weight" }, description = "Weight of the first weisfeiler lehmann iteration", required = false, validateWith = {
                    PositiveInteger.class })
    Integer wl1weight = 1;

    @Parameter(names = { "--duplicateremoval" }, description = "Filter duplicates", required = false)
    Boolean filterDuplicates = true;
    
    @Parameter(names = "--help", help = true)
    Boolean help = false;
}