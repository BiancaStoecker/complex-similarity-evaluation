/*
 * Scaffold Hunter
 * Copyright (C) 2006-2008 PG504
 * Copyright (C) 2010-2011 PG552
 * Copyright (C) 2012 LS11
 * See the file README.txt in the root directory of the Scaffold Hunter
 * source tree for details.
 *
 * Scaffold Hunter is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Scaffold Hunter is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package struclust.eval.metamodules;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import struclust.eval.EvalException;
import struclust.eval.EvalResult;
import struclust.util.FsOperations;

/**
 * Saves the EvaluationResults to disk. The result files are stored in the
 * format:
 * folderPath[/&lt;uniqueFolder&gt;]/[&lt;filePrefix&gt;]&lt;result#getMeasurement&gt;&lt;uniqueSuffix&gt;.(txt|csv)
 * 
 * @author Till Schäfer
 */
public class FileSaverEMM extends AbstractEMM {
    private static final Logger logger = LoggerFactory.getLogger(FileSaverEMM.class);

    private final String folderPath;
    private final boolean saveCSV;

    private boolean createUniqueSubfolder;

    private String filePrefix;

    /**
     * Constructor
     * 
     * @param folderPath
     *            the path to the folder, where the results are stored
     * @param saveCSV
     *            store a second file with the CSV data only.
     */
    public FileSaverEMM(String folderPath, boolean saveCSV) {
        this(folderPath, saveCSV, false);
    }

    /**
     * Constructor
     * 
     * @param folderPath
     *            the path to the folder, where the results are stored
     * @param saveCSV
     *            store a second file with the CSV data only.
     * @param createUniqueSubfolder
     *            if true a unique subfolder will be created for each call of
     *            {@link #run}
     */
    public FileSaverEMM(String folderPath, boolean saveCSV, boolean createUniqueSubfolder) {
        this(folderPath, saveCSV, createUniqueSubfolder, null);
    }

    /**
     * Constructor
     * 
     * @param folderPath
     *            the path to the folder, where the results are stored
     * @param saveCSV
     *            store a second file with the CSV data only.
     * @param createUniqueSubfolder
     *            if true a unique subfolder will be created for each call of
     *            {@link #run}
     * @param filePrefix
     *            if set to a non-null value, the results files will be prefixed
     *            with this string
     */
    public FileSaverEMM(String folderPath, boolean saveCSV, boolean createUniqueSubfolder, String filePrefix) {
        this.folderPath = folderPath;
        this.saveCSV = saveCSV;
        this.createUniqueSubfolder = createUniqueSubfolder;
        this.filePrefix = filePrefix;
    }

    @Override
    public Collection<EvalResult> process(Collection<EvalResult> results) throws EvalException {
        try {
            save(results);
        } catch (IOException e) {
            logger.error("saving results failed", e);
        }
        return results;
    }

    /**
     * Save the {@link EvalResult}s on disc
     * 
     * @param results
     *            the {@link EvalResult}s to save
     * @throws IOException
     *             if folder creation of result saving fails
     */
    private void save(Collection<EvalResult> results) throws IOException {
        String usedFolder = null;
        if (FilenameUtils.getExtension(folderPath).isEmpty()) {
            usedFolder = folderPath;
        }else {
            usedFolder = FilenameUtils.getFullPathNoEndSeparator(folderPath);
        }
        File folder = new File(usedFolder);
        if (folder.exists()) {
            if (!folder.isDirectory()) {
                throw new IOException("folderPath points to an existing file");
            }
        } else {
            if (!folder.mkdir()) {
                throw new IOException("non existing folder \"" + folder + "\" cannot be created");
            }
        }

        if (createUniqueSubfolder) {
            try {
                usedFolder = FsOperations.createUniqueFolder(usedFolder, "");
            } catch (IOException e) {
                throw new IOException("creation of unique folder failed", e);
            }
        }

        for (EvalResult result : results) {
            saveToFile(usedFolder, result.getMeasurement(), "txt", result.toString());
            if (saveCSV) {
                saveToFile(usedFolder, result.getMeasurement(), "csv", result.getCSVString());
            }
        }
    }

    private void saveToFile(String usedFolder, String basename, String extension, String content) throws IOException {
        String uniqueFile = FsOperations.getUniqueFileName(usedFolder,
                (filePrefix != null ? filePrefix : "") + basename, extension, 3);
        try (BufferedWriter out = new BufferedWriter(new FileWriter(uniqueFile, true))) {
            out.write(content);
        } catch (IOException e) {
            throw e;
        }
    }
}
