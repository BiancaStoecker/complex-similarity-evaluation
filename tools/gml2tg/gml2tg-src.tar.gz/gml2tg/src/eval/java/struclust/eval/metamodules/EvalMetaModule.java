package struclust.eval.metamodules;

import java.util.Collection;
import java.util.List;

import struclust.eval.EvalException;
import struclust.eval.EvalResult;
import struclust.eval.modules.EvalModule;

/**
 * A {@link EvalMetaModule} runs an {@link EvalModule} and processes its
 * {@link EvalResult}
 * 
 * @author Till Schäfer
 */
public interface EvalMetaModule {
    /**
     * Runs the {@link EvalModule} and process its {@link EvalResult}
     * 
     * @param module
     *            the {@link EvalModule} to run
     * @return a {@link Collection} of {@link EvalResult}s
     * @throws EvalException
     */
    public Collection<EvalResult> run(EvalModule<?> module) throws EvalException;

    /**
     * Runs a stack of {@link EvalMetaModule}s for the specified {@link EvalModule}.
     * The first Element in the metaModules {@link List} is run last on the results
     * of the second {@link EvalMetaModule}, and so on.
     * 
     * @param metaModules
     *            the stack of {@link EvalMetaModule}s
     * @param module
     *            the {@link EvalModule} to run
     * @return a {@link Collection} of {@link EvalResult}s
     * @throws EvalException
     */
    public Collection<EvalResult> run(List<EvalMetaModule> metaModules, EvalModule<?> module) throws EvalException;

    /**
     * Process a set of given EvalResults directly without running any evaluation.
     * 
     * @param results
     *            the {@link EvalResult}s to process.
     * @return the processed {@link EvalResult}s.
     * @throws EvalException
     * @throws UnsupportedOperationException
     *             some {@link EvalMetaModule}s only model the test flow (i.e.
     *             {@link RepeaterEMM} only repeats the experiments, but do not
     *             process the results)
     */
    public Collection<EvalResult> process(Collection<EvalResult> results)
            throws EvalException, UnsupportedOperationException;

    /**
     * Convenience method to run a stack of {@link EvalMetaModule}s over an
     * {@link EvalModule} without explicitly selecting an {@link EvalMetaModule} to
     * start the run.
     * 
     * @param metaModules
     *            the stack of {@link EvalMetaModule}s
     * @param module
     *            the {@link EvalModule} to run
     * @return a {@link Collection} of {@link EvalResult}s
     */
    public static Collection<EvalResult> runStatic(List<EvalMetaModule> metaModules, EvalModule<?> module) {
        if (metaModules.isEmpty()) {
            return module.run();
        } else {
            EvalMetaModule metaModule = metaModules.iterator().next();
            List<EvalMetaModule> metaModulesRest = metaModules.subList(1, metaModules.size());

            Collection<EvalResult> results = metaModule.run(metaModulesRest, module);
            return results;
        }
    }

}
