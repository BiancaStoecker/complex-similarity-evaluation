package struclust.eval;

/**
 * {@link RuntimeException} that occurs during evaluation
 * 
 * @author Till Schäfer
 * 
 */
public class EvalException extends RuntimeException {
    private static final long serialVersionUID = 6452486289444033011L;

    /**
     * Constructor
     */
    public EvalException() {
        super();
    }

    /**
     * Constructor
     * 
     * @param message
     *            the message
     */
    public EvalException(String message) {
        super(message);
    }

    /**
     * Constructor
     * 
     * @param cause
     *            the cause
     */
    public EvalException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor
     * 
     * @param message
     *            the message
     * @param cause
     *            the cause
     */
    public EvalException(String message, Throwable cause) {
        super(message, cause);
    }
}
