package struclust.eval;

/**
 * All Classes implementing this interface must provide a common method to add
 * meta data to a {@link EvalResult}.
 * 
 * @author Till Schäfer
 */
public interface MetaDataAddable {
    /**
     * Adds meta data to the {@link EvalResult}
     * 
     * @param result
     *            the {@link EvalResult} to add the meta data to.
     */
    public void addAsMetadata(EvalResult result);
}
