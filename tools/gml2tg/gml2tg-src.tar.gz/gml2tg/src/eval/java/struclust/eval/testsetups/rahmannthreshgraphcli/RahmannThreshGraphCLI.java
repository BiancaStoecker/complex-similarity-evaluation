package struclust.eval.testsetups.rahmannthreshgraphcli;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.beust.jcommander.JCommander;

import graph.DefaultGraph;
import graph.DefaultNode;
import graph.Graph;
import hsahn.algorithm.graph.isomorphism.labelrefinement.VertexLabelConverter;
import hsahn.comparison.kernel.ExplicitMappingKernel;
import hsahn.comparison.kernel.graph.WeisfeilerLehmanKernel;
import hsahn.comparison.kernel.graph.WeisfeilerLehmanSubtreeKernel;
import hsahn.datastructure.SparseFeatureVector;
import hsahn.graph.GraphTools;
import hsahn.graph.LGraph;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import struclust.eval.EvalResult;
import struclust.eval.metamodules.MetaDataAdderEMM;
import struclust.eval.testsetups.TSHelpers;
import struclust.graph.GraphContainer;
import struclust.graph.Graphs;
import struclust.hashing.MinHashJaccardRangeQuery;
import struclust.util.FsOperations;
import struclust.util.GraphIO;

public class RahmannThreshGraphCLI {
    
    private static final Logger logger = LoggerFactory.getLogger(RahmannThreshGraphCLI.class);

    public static void main(String[] args)
            throws FileNotFoundException, UnknownHostException, IOException, InterruptedException {
        Parameters param = new Parameters();
        JCommander jCom = new JCommander(param);
        jCom.parse(args);
        
        if (param.help) {
            jCom.usage();
            return;
        }

        Predicate<Graph<String, String>> filter = g -> g.getEdgeCount() <= param.filterLargerThen;
        int wlSequenceLength = 2;
        ExplicitMappingKernel<LGraph<String, String>, SparseFeatureVector<Integer>> kernel = new WeisfeilerLehmanSubtreeKernel<>(
                wlSequenceLength, true);
        double[] simThreshs = new double[] { param.simThresh };

        int gcdWeights = ArithmeticUtils.gcd(param.wl0weight, param.wl1weight);

        defGmlThresholdGraph("Gml2JTG", param.outFolder, param.inGmlFolder, filter, kernel,
                true, simThreshs, param.filterDuplicates, param.falseNegativeRate, param.wl0weight / gcdWeights,
                param.wl1weight / gcdWeights);
    }
    
    /**
     * @param canonicalDescription
     * @param baseFolderPath
     * @param gmlFolderPath
     * @param filter
     * @param explIntKernel
     * @param singleVectorFile
     * @param simThreshs
     * @param filterDuplicates
     * @param falseNegativeRate
     * @param wl1weight
     * @param wl0weight
     * @return the {@link EvalResult}
     * @throws FileNotFoundException
     * @throws IOException
     * @throws UnknownHostException
     * @throws InterruptedException
     */
    public static LinkedList<EvalResult> defGmlThresholdGraph(String canonicalDescription, String baseFolderPath,
            String gmlFolderPath, Predicate<Graph<String, String>> filter,
            ExplicitMappingKernel<LGraph<String, String>, SparseFeatureVector<Integer>> explIntKernel,
            boolean singleVectorFile, double[] simThreshs, Boolean filterDuplicates, Double falseNegativeRate,
            int wl0weight, int wl1weight)
            throws FileNotFoundException, IOException, UnknownHostException, InterruptedException {
        LinkedList<EvalResult> results = new LinkedList<>();

        // load
        File[] gmlFiles = new File(gmlFolderPath).listFiles();
        MetaDataAdderEMM[] datasetNames = new MetaDataAdderEMM[gmlFiles.length];
        MetaDataAdderEMM[] datasetSizes = new MetaDataAdderEMM[gmlFiles.length];
        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> graphContainers = new ArrayList<>();
        IntStream.range(0, gmlFiles.length).parallel()
                .forEach(j -> loadDataset(filter, gmlFiles, datasetNames, datasetSizes, graphContainers, j));
        TSHelpers.logDatasetSummary(false, graphContainers);

        ArrayList<LGraph<String, String>> lGraphs = new ArrayList<>(graphContainers.size());
        for (GraphContainer<String, String, DefaultGraph<String, String>> graph : graphContainers) {
            lGraphs.add(GraphTools.convert(graph));
        }

        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> graphContainersToCluster;
        ArrayList<SparseFeatureVector<Integer>> explicitMapping;
        int sizeWDups = graphContainers.size();
        int sizeWODups = 0;
        if (filterDuplicates) {
            // ---coarse grouping by WL
            WeisfeilerLehmanSubtreeKernel<String,
                    String> wflskDuplicateRem = new WeisfeilerLehmanSubtreeKernel<>(2, true);
            explicitMapping = wflskDuplicateRem.computeExplicitMapping(lGraphs);
            HashMap<SparseFeatureVector<Integer>,
                    ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>>> wlGroups = new HashMap<>();
            for (int i = 0; i < lGraphs.size(); i++) {
                ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> group = wlGroups
                        .get(explicitMapping.get(i));
                if (group == null) {
                    group = new ArrayList<>();
                    wlGroups.put(explicitMapping.get(i), group);
                }
                group.add(graphContainers.get(i));
            }
            // ---fine grouping by isomorphism
            graphContainersToCluster = new ArrayList<>();
            for (ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> group : wlGroups.values()) {
                // System.out.println("Group size "+group.size());
                List<List<GraphContainer<String, String, DefaultGraph<String, String>>>> isoGroups = Graphs
                        .groupByIsomorphismParallel(group);
                graphContainersToCluster.addAll(isoGroups.stream().map(g -> g.iterator().next())
                        .collect(Collectors.toCollection(ArrayList::new)));
            }

            sizeWODups = graphContainersToCluster.size();
            logger.info("Duplicates: {} ({}/{})", sizeWDups - sizeWODups, sizeWDups, sizeWODups);

            // recreate lgraphs for later use
            lGraphs = new ArrayList<>(graphContainersToCluster.size());
            for (GraphContainer<String, String, DefaultGraph<String, String>> graph : graphContainersToCluster) {
                lGraphs.add(GraphTools.convert(graph));
            }
        } else {
            graphContainersToCluster = graphContainers;
        }

        String folderPath = FsOperations.createUniqueFolder(baseFolderPath, "", 3);

        for (double simThresh : simThreshs) {
            MetaDataAdderEMM[] extraMetaData = { TSHelpers.hostNameMetaData(),
                    new MetaDataAdderEMM("gml folder path", gmlFolderPath),
                    new MetaDataAdderEMM("kernel", explIntKernel.toString()),
                    new MetaDataAdderEMM("similarity threshold", String.valueOf(simThresh)),
                    new MetaDataAdderEMM("wl0weight", String.valueOf(wl0weight)),
                    new MetaDataAdderEMM("wl1weight", String.valueOf(wl1weight)),
                    new MetaDataAdderEMM("min hash range query falseNegativeRate", String.valueOf(falseNegativeRate)),
                    new MetaDataAdderEMM("duplicate removal", String.valueOf(filterDuplicates)),
                    new MetaDataAdderEMM("overall dataset size", String.valueOf(sizeWDups)) };
            if (filterDuplicates) {
                extraMetaData = ArrayUtils.addAll(extraMetaData, new MetaDataAdderEMM[] {
                        new MetaDataAdderEMM("data set size without duplicates", String.valueOf(sizeWODups)) });
            }

            extraMetaData = ArrayUtils.addAll(extraMetaData, datasetNames);
            extraMetaData = ArrayUtils.addAll(extraMetaData, datasetSizes);
            results.add(TSHelpers.logAndSaveMetadataInfo(canonicalDescription, null, folderPath, extraMetaData));

            // compute feature vectors
            explicitMapping = explIntKernel.computeExplicitMapping(lGraphs);
            int maxLabel = explicitMapping.stream().flatMap(fv -> fv.positiveFeatures().stream()).mapToInt(i -> i).max()
                    .orElse(0);

            // apply weighting

            int[] featureWeights = new int[maxLabel + 1];

            if (explIntKernel instanceof WeisfeilerLehmanKernel) {
                logger.info("WL Kernel used. Applying weighting of iteration 0 and 1");
                @SuppressWarnings("unchecked")
                VertexLabelConverter<String> vlc = ((WeisfeilerLehmanKernel<String, String, Integer>) explIntKernel)
                        .getVertexLabelConverter();
                for (Entry<Pair<Integer, Object>, Integer> entry : vlc.getLabelMap().entrySet()) {
                    Integer iteration = entry.getKey().getKey();
                    Integer feature = entry.getValue();
                    switch (iteration) {
                    case 0:
                        featureWeights[feature] = wl0weight;
                        break;
                    case 1:
                        featureWeights[feature] = wl1weight;
                        break;
                    default:
                        logger.warn("Weighting cannot be applied to WL interation >=2");
                    }
                }

            }

            for (SparseFeatureVector<Integer> fv : explicitMapping) {
                for (int f : fv.positiveFeatures()) {
                    fv.increaseCount(f, fv.getCount(f) * (featureWeights[f] - 1));
                }
            }

            // convert numerical to binary feature vectors
            long[] maxLabelCounts = new long[maxLabel + 1];

            for (SparseFeatureVector<Integer> fv : explicitMapping) {
                for (Entry<Integer, Long> e : fv.positiveEntries()) {
                    maxLabelCounts[e.getKey()] = Math.max(maxLabelCounts[e.getKey()], e.getValue());
                }
            }

            int[] offsetLabels = new int[maxLabel + 1];
            int offset = 0;
            for (int j = 0; j < offsetLabels.length; j++) {
                offsetLabels[j] = offset;
                offset += maxLabelCounts[j];
            }

            logger.debug("orig num labels: {}", maxLabelCounts.length);
            logger.debug("summed labels: {}", Arrays.stream(maxLabelCounts).sum());
            logger.debug("max single label count: {}", Arrays.stream(maxLabelCounts).max());

            ArrayList<Set<Integer>> binaryFeatureVectors = new ArrayList<>(explicitMapping.size());
            for (SparseFeatureVector<Integer> fv : explicitMapping) {
                Set<Integer> binaryFeatureVector = new IntOpenHashSet();
                for (Entry<Integer, Long> e : fv.positiveEntries()) {
                    int offsetLabel = offsetLabels[e.getKey()];
                    for (int j = 0; j < e.getValue(); j++) {
                        binaryFeatureVector.add(offsetLabel + j);
                    }
                }
                binaryFeatureVectors.add(binaryFeatureVector);
            }

            logger.debug("average postive fingerprint entries: {}",
                    binaryFeatureVectors.stream().mapToInt(s -> s.size()).average().getAsDouble());

            HashMap<GraphContainer<String, String, DefaultGraph<String, String>>,
                    Set<Integer>> graphBVectorMapping = new HashMap<>();
            for (int j = 0; j < graphContainersToCluster.size(); j++) {
                graphBVectorMapping.put(graphContainersToCluster.get(j), binaryFeatureVectors.get(j));
            }

            // range queries
            int maxBinaryLabel = Math
                    .toIntExact((offsetLabels[offsetLabels.length - 1] + maxLabelCounts[offsetLabels.length - 1] - 1));
            logger.debug("max binary label: {}", maxBinaryLabel);
            MinHashJaccardRangeQuery<GraphContainer<String, String,
                    DefaultGraph<String, String>>> rangeQuery = new MinHashJaccardRangeQuery<>(graphContainersToCluster,
                            gc -> graphBVectorMapping.get(gc), maxBinaryLabel, simThresh, falseNegativeRate, true);

            DefaultGraph<String, String> thresholdGraph = new DefaultGraph<>();
            HashMap<GraphContainer<String, String, DefaultGraph<String, String>>,
                    DefaultNode<String, String>> gc2Node = new HashMap<>();
            for (GraphContainer<String, String, DefaultGraph<String, String>> gc : graphContainersToCluster) {
                String source = FilenameUtils.getName(gc.getProperty("source"));
                String index = gc.getProperty("sourceIndex");
                DefaultNode<String, String> node = thresholdGraph.addNode(source + "_" + index);
                gc2Node.put(gc, node);
            }

            ForkJoinPool customFJPool = new ForkJoinPool(Runtime.getRuntime().availableProcessors() * 4);
            customFJPool.submit(() -> graphContainersToCluster.parallelStream()
                    .forEach(gc -> queryAndAddEdges(rangeQuery, thresholdGraph, gc2Node, gc)));
            customFJPool.shutdown();
            customFJPool.awaitTermination(Long.MAX_VALUE, TimeUnit.DAYS);

            logger.debug("threshold graph -> nodes: {}, edges: {}", thresholdGraph.getNodeCount(),
                    thresholdGraph.getEdgeCount());

            try (FileWriter fw = new FileWriter(
                    FilenameUtils.concat(folderPath, "thresholdGraph_" + simThresh + ".gml"));
                    BufferedWriter bw = new BufferedWriter(fw)) {
                GraphIO.writeGMLGraph(bw, thresholdGraph);
            }
        }

        return results;
    }
    
    private static int numQueryAndAddEdgesCalls = 0;

    /**
     * @param rangeQuery
     * @param thresholdGraph
     * @param gc2Node
     * @param gc
     */
    private static void queryAndAddEdges(
            MinHashJaccardRangeQuery<GraphContainer<String, String, DefaultGraph<String, String>>> rangeQuery,
            DefaultGraph<String, String> thresholdGraph,
            HashMap<GraphContainer<String, String, DefaultGraph<String, String>>, DefaultNode<String, String>> gc2Node,
            GraphContainer<String, String, DefaultGraph<String, String>> gc) {
        numQueryAndAddEdgesCalls++;
        if (numQueryAndAddEdgesCalls % 1000 == 0) {
            logger.debug("numQueryAndAddEdgesCalls={}", numQueryAndAddEdgesCalls);
        }

        Map<GraphContainer<String, String, DefaultGraph<String, String>>,
                Double> objectsInRange = rangeQuery.getObjectsWithDistInRange(gc);
        DefaultNode<String, String> gcNode = gc2Node.get(gc);
        for (Entry<GraphContainer<String, String, DefaultGraph<String, String>>, Double> pair : objectsInRange
                .entrySet()) {
            GraphContainer<String, String, DefaultGraph<String, String>> gcInRange = pair.getKey();
            DefaultNode<String, String> inRangeNode = gc2Node.get(gcInRange);
            synchronized (thresholdGraph) {
                if (gcNode != inRangeNode && !thresholdGraph.hasEdge(gcNode, inRangeNode)) {
                    thresholdGraph.addEdge(gcNode, inRangeNode, String.valueOf(pair.getValue()));
                }
            }
        }
    }
    
    /**
     * @param filter
     * @param gmlFiles
     * @param datasetNames
     * @param datasetSizes
     * @param graphContainers
     * @param j
     * @throws FileNotFoundException
     * @throws IOException
     */
    private static void loadDataset(Predicate<Graph<String, String>> filter, File[] gmlFiles,
            MetaDataAdderEMM[] datasetNames, MetaDataAdderEMM[] datasetSizes,
            ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> graphContainers, int j) {
        String gmlPath = gmlFiles[j].getAbsolutePath();
        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> graphContainersSingle;
        try {
            graphContainersSingle = GraphIO.gmlToPropertyGraphContainer(gmlPath, filter);
            for (int i = 0; i < graphContainersSingle.size(); i++) {
                GraphContainer<String, String, DefaultGraph<String, String>> gc = graphContainersSingle.get(i);
                gc.putProperty("source", gmlPath);
                gc.putProperty("sourceIndex", String.valueOf(i));
            }
            synchronized (graphContainers) {
                graphContainers.addAll(graphContainersSingle);
            }
            TSHelpers.logDatasetSummary(false, graphContainersSingle);
            datasetNames[j] = new MetaDataAdderEMM("dataset " + j, gmlPath);
            datasetSizes[j] = new MetaDataAdderEMM("dataset " + j + " size",
                    String.valueOf(graphContainersSingle.size()));
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
