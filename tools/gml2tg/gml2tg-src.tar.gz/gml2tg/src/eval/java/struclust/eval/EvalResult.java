package struclust.eval;

import java.lang.management.ManagementFactory;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import com.google.common.base.Preconditions;

import struclust.Describable;

/**
 * Stores the results of an evaluation measurement including the measurements
 * metadata.
 * 
 * @author Till Schäfer
 */
public class EvalResult {
    /**
     * A short description of the measurement (used for filenames)
     */
    private String measurement;
    /**
     * Unique identifier for this {@link EvalResult}
     */
    private UUID id = UUID.randomUUID();
    /**
     * References to other {@link EvalResult}s. This should be used for any
     * aggregation or modification of values from other {@link EvalResult} to be
     * able to reconstruct the process.
     */
    private List<UUID> refs = new LinkedList<>();
    /**
     * The time of creation of this EvalResult
     */
    private Date date = new Date();

    /**
     * conditional reference to the commit id of the binary build
     */
    private String commitId = System.getProperty("build.commitid");

    /**
     * conditional reference to the repository dirty status of the binary build
     * (i.e. if there where changes since commitId)
     */
    private String buildDirty = System.getProperty("build.dirty");

    /**
     * conditional reference to the build of the binary build
     */
    private String buildTime = System.getProperty("build.time");

    /**
     * The meta data of the measurement (e.g. the settings for the test run,
     * informations about accumulations of values, etc)
     */
    private final LinkedHashMap<String, String> metadata = new LinkedHashMap<>();
    /**
     * A set of key-value pairs, which describes the results. Unique Keys.
     */
    private final LinkedHashMap<String, String> results = new LinkedHashMap<>();

    /**
     * Constructor
     * 
     * @param measurement
     *            a short description of the measurement (used for filenames)
     */
    public EvalResult(String measurement) {
        this.measurement = measurement;
    }

    /**
     * Constructor
     * 
     * @param measurement
     *            a short description of the measurement (used for filenames)
     * @param metadata
     *            a map of metadata key value pairs
     */
    public EvalResult(String measurement, Map<String, String> metadata) {
        this.measurement = measurement;
        this.metadata.putAll(metadata);
    }

    /**
     * Adds a new metadata key-value pair.
     * 
     * Please be aware that the metadata key must be unique. If a metadata key
     * already exists, its value is overridden by the new value.
     * 
     * @param key
     *            the metadata key/description
     * @param value
     *            the metadata value
     * 
     */
    public void addMetadata(String key, String value) {
        metadata.put(key, value);
    }

    /**
     * Adds a new metadata key-value pair.
     * 
     * Please be aware that the metadata key must be unique. If a metadata key
     * already exists, its value is overridden by the new value.
     * 
     * @param key
     *            the metadata key/description
     * @param value
     *            the metadata value
     * 
     */
    public void addMetadata(String key, long value) {
        addMetadata(key, Long.toString(value));
    }

    /**
     * Adds a new metadata key-value pair.
     * 
     * Please be aware that the metadata key must be unique. If a metadata key
     * already exists, its value is overridden by the new value.
     * 
     * @param key
     *            the metadata key/description
     * @param value
     *            the metadata value
     * 
     */
    public void addMetadata(String key, double value) {
        addMetadata(key, Double.toString(value));
    }

    /**
     * Adds a new metadata key-value pair.
     * 
     * Please be aware that the metadata key must be unique. If a metadata key
     * already exists, its value is overridden by the new value.
     * 
     * @param key
     *            the metadata key/description
     * @param value
     *            the metadata value
     * 
     */
    public void addMetadata(String key, boolean value) {
        addMetadata(key, Boolean.toString(value));
    }

    /**
     * Adds a new metadata key-value pair.
     * 
     * Please be aware that the metadata key must be unique. If a metadata key
     * already exists, its value is overridden by the new value.
     * 
     * @param key
     *            the metadata key/description
     * @param value
     *            the metadata value
     * 
     */
    public void addMetadata(String key, Describable value) {
        addMetadata(key, value.getDescription());
    }

    /**
     * Adds all meta data from a {@link MetaDataAddable}.
     * 
     * @param addable
     *            the {@link MetaDataAddable}
     */
    public void addMetadata(MetaDataAddable addable) {
        addable.addAsMetadata(this);
    }

    /**
     * Adds a new measurement's result key-value pair.
     * 
     * Please be aware that the metadata key must be unique. If a metadata key
     * already exists, its value is overridden by the new value.
     * 
     * @param key
     *            the result key/description
     * @param value
     *            the result value
     */
    public void addResult(String key, String value) {
        Preconditions.checkArgument(!results.containsKey(key), "the result already contains that key");
        results.put(key, value);
    }

    /**
     * Adds a new measurement's result key-value pair.
     * 
     * Please be aware that the metadata key must be unique. If a metadata key
     * already exists, its value is overridden by the new value.
     * 
     * @param key
     *            the result key/description
     * @param value
     *            the result value
     */
    public void addResult(String key, double value) {
        addResult(key, Double.toString(value));
    }

    /**
     * Adds a new measurement's result key-value pair.
     * 
     * Please be aware that the metadata key must be unique. If a metadata key
     * already exists, its value is overridden by the new value.
     * 
     * @param key
     *            the result key/description
     * @param value
     *            the result value
     */
    public void addResult(String key, long value) {
        addResult(key, Long.toString(value));
    }

    /**
     * Adds a new measurement's result key-value pair.
     * 
     * Please be aware that the metadata key must be unique. If a metadata key
     * already exists, its value is overridden by the new value.
     * 
     * @param key
     *            the result key/description
     * @param value
     *            the result value
     */
    public void addResult(String key, boolean value) {
        addResult(key, Boolean.toString(value));
    }

    /**
     * Returns the results as CSV data without metadata
     * 
     * @return the CSV results
     */
    public String getCSVString() {
        StringBuilder builder = new StringBuilder();

        // key / value header
        builder.append("key,value");
        String eol = System.getProperty("line.separator").toString();
        builder.append(eol);

        // key / value pairs
        for (Entry<String, String> entry : results.entrySet()) {
            builder.append(entry.getKey());
            builder.append(",");
            builder.append(entry.getValue());
            builder.append(eol);
        }

        builder.deleteCharAt(builder.length() - 1);
        return builder.toString();
    }

    /**
     * @param measurement
     *            the measurement to set
     */
    public void setMeasurement(String measurement) {
        this.measurement = measurement;
    }

    /**
     * @return the measurement
     */
    public String getMeasurement() {
        return measurement;
    }

    /**
     * @return the results
     */
    public Map<String, String> getResults() {
        return Collections.unmodifiableMap(results);
    }

    /**
     * @return the metadata
     */
    public Map<String, String> getMetadata() {
        return Collections.unmodifiableMap(metadata);
    }

    /**
     * Removes all metadata with the specified key.
     * 
     * @param key
     *            the metadata key
     * @return whether the key was present in the metadata
     */
    public boolean removeMetadata(String key) {
        return metadata.remove(key) != null;
    }

    /**
     * @return a UUID which is unique for each instance of {@link EvalResult}
     */
    public UUID getId() {
        return id;
    }

    /**
     * @return the references to other {@link EvalResult}s. This should be used
     *         for any aggregation or modification of values from other
     *         {@link EvalResult} to be able to reconstruct the process.
     */
    public List<UUID> getRefs() {
        return refs;
    }

    /**
     * @param ref
     *            add a new reference to another {@link EvalResult}. This should
     *            be used for any aggregation or modification of values from
     *            other {@link EvalResult} to be able to reconstruct the
     *            process.
     */
    public void addRef(EvalResult ref) {
        refs.add(ref.getId());
    }

    /**
     * @param refs
     *            add new references to other {@link EvalResult}. This should be
     *            used for any aggregation or modification of values from other
     *            {@link EvalResult} to be able to reconstruct the process.
     */
    public void addRefs(Collection<EvalResult> refs) {
        for (EvalResult result : refs) {
            addRef(result);
        }
    }

    /**
     * Returns if this {@link EvalResult} was run with the same settings as
     * another {@link EvalResult}, i.e. the same metadata, the same measurement
     * and the same result keys. Furthermore, it is possible to specify metadata
     * keys that are not considered relevant for comparison. Result values are
     * allowed to differ.
     * 
     * @param other
     *            the {@link EvalResult} to compare with
     * @param filter
     *            metadata keys that are not included in the comparison. That
     *            means only the keys which are not listed here must be equal.
     *            This parameter is allowed to be null.
     * @return if other was run with the same settings
     */
    public boolean equalSettings(EvalResult other, Collection<String> filter) {
        if (filter == null) {
            filter = Collections.emptySet();
        }

        if (!getMeasurement().equals(other.getMeasurement())) {
            return false;
        }

        // remove filtered keys
        LinkedHashMap<String, String> meta1 = new LinkedHashMap<>(metadata);
        LinkedHashMap<String, String> meta2 = new LinkedHashMap<>(other.metadata);
        for (Iterator<String> it = meta1.keySet().iterator(); it.hasNext();) {
            if (filter.contains(it.next())) {
                it.remove();
            }
        }
        for (Iterator<String> it = meta2.keySet().iterator(); it.hasNext();) {
            if (filter.contains(it.next())) {
                it.remove();
            }
        }

        if (meta1.size() != meta2.size() || results.size() != other.results.size()) {
            return false;
        }

        /*
         * This is sufficient to check if the metadata is equal. if there are
         * different keys, metadata.get() will return null for at least one
         * entry and equals will return false
         */
        for (Entry<String, String> e : meta1.entrySet()) {
            if (!e.getValue().equals(meta2.get(e.getKey()))) {
                return false;
            }
        }

        for (String key : results.keySet()) {
            if (!other.results.keySet().contains(key)) {
                return false;
            }
        }

        return true;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        String eol = System.getProperty("line.separator").toString();

        // measurement method
        builder.append("Meausrement: ");
        builder.append(getMeasurement());
        builder.append(eol);

        // date
        builder.append("Time (Result Creation): ");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mmZ");
        builder.append(df.format(date));
        builder.append(eol);

        // start time
        builder.append("Start Time (Java Process): ");
        builder.append(df.format(new Date(ManagementFactory.getRuntimeMXBean().getStartTime())));
        builder.append(eol);

        // id
        builder.append("UUID: ");
        builder.append(getId().toString());
        builder.append(eol);

        if (commitId != null) {
            // commit id
            builder.append("Commit ID: ");
            builder.append(commitId);
            builder.append(eol);
            if (buildDirty != null) {
                // build status
                builder.append("Build Status Dirty: ");
                builder.append(buildDirty);
                builder.append(eol);
            }
        }
        if (buildTime != null) {
            builder.append("Build Time: ");
            builder.append(buildTime);
            builder.append(eol);
        }

        // command line parameters
        builder.append("Command Line Parameters: ");
        builder.append(ManagementFactory.getRuntimeMXBean().getInputArguments());
        builder.append(eol);

        // jvm info
        builder.append("Java VM: ");
        builder.append(ManagementFactory.getRuntimeMXBean().getVmVendor());
        builder.append(" ");
        builder.append(ManagementFactory.getRuntimeMXBean().getVmName());
        builder.append(" ");
        builder.append(ManagementFactory.getRuntimeMXBean().getVmVersion());
        builder.append(eol);

        // references
        if (!refs.isEmpty()) {
            builder.append("References:");
            for (UUID ref : refs) {
                builder.append(" ");
                builder.append(ref.toString());
            }
            builder.append(eol);
        }

        // metadata
        builder.append(eol);
        builder.append("METADATA");
        builder.append(eol);
        for (Entry<String, String> e : metadata.entrySet()) {
            builder.append(e.getKey());
            builder.append(": ");
            builder.append(e.getValue());
            builder.append(eol);
        }

        // the results
        builder.append(eol);
        builder.append("RESULTS");
        builder.append(eol);
        builder.append(getCSVString());

        // end separation
        builder.append(eol);
        builder.append("--------------------------------------------------");
        builder.append(eol);
        builder.append(eol);

        return builder.toString();
    }
}
