package struclust.eval.metamodules;

import java.util.Collection;
import java.util.List;

import struclust.eval.EvalResult;
import struclust.eval.modules.EvalModule;

/**
 * Base implementation of EvalMetaModule, that provides a unified way to handle
 * stacked metaModules and EvalModule execution<br>
 * 
 * Inherited classes should only implement {@link #process(Collection)}.
 * 
 * @author Till Schäfer
 *
 */
public abstract class AbstractEMM implements EvalMetaModule {

    @Override
    public Collection<EvalResult> run(EvalModule<?> module) {
        return process(module.run());
    }

    @Override
    public Collection<EvalResult> run(List<EvalMetaModule> metaModules, EvalModule<?> module) {
        if (metaModules.isEmpty()) {
            return run(module);
        } else {
            EvalMetaModule metaModule = metaModules.iterator().next();
            List<EvalMetaModule> metaModulesRest = metaModules.subList(1, metaModules.size());

            Collection<EvalResult> results = metaModule.run(metaModulesRest, module);
            return process(results);
        }
    }
}
