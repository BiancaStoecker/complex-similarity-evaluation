package struclust.eval.modules;

import java.util.Collection;

import struclust.eval.EvalException;
import struclust.eval.EvalResult;

/**
 * A {@link EvalModule} runs a measurement and returns a {@link EvalResult}
 * 
 * @author Till Schäfer
 * @param <T>
 *            the type of the test data (e.g. a clustering for any test that
 *            evaluates a clustering)
 */
public interface EvalModule<T> {

    /**
     * Runs the evaluation measurement
     * 
     * @return a {@link EvalResult}
     * @throws EvalException
     */
    public abstract Collection<EvalResult> run() throws EvalException;

    /**
     * Runs the evaluation measurement with precomputed test data
     * 
     * @param testData
     *            the precomputed test data
     * 
     * @return a {@link EvalResult}
     * @throws EvalException
     */
    public abstract Collection<EvalResult> run(T testData) throws EvalException;

    /**
     * @return whether the test can be run with precomputed test data
     */
    public boolean canUsePrecomputedTestData();

    /**
     * @return the test data of the last run (i.e. the clustering for any test
     *         that evaluates a clustering) or null if not test was ran before.
     */
    public T getTestData();

    /**
     * Some {@link EvalModule}s do perform some kind of accumulation. E.g.
     * counting the runs.
     * 
     * By calling reset, the internal statistics are reset and the state of the
     * module is set back to its initialization state.
     */
    default public void reset() {/* do nothing */}
}
