package struclust.eval.testsetups;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;

import graph.DefaultEdge;
import graph.DefaultGraph;
import graph.DefaultNode;
import graph.Graph;
import graph.GraphSize;
import graph.MoleculeGraph;
import struclust.SharedMemorySC;
import struclust.SharedMemorySCC;
import struclust.StructuralClusteringConf;
import struclust.eval.EvalResult;
import struclust.eval.metamodules.EvalMetaModule;
import struclust.eval.metamodules.FileSaverEMM;
import struclust.eval.metamodules.MetaDataAdderEMM;
import struclust.graph.GraphContainer;
import struclust.graph.Graphs;
import struclust.util.GraphIO;

/**
 * Helper class for common test setup functionality
 * 
 * @author Till Schäfer
 */
public class TSHelpers {
    private static final Logger logger = LoggerFactory.getLogger(TSHelpers.class);

    private static MetaDataAdderEMM metaDataAdderEMM = null;

    /**
     * Converts a string graph to an Integer {@link DefaultGraph}. All String labels
     * must be parsable.
     * 
     * Example Use case: Convert graphs read from an gml export, that where exported
     * using Integer labels.
     * 
     * @param sg
     *            the {@link MoleculeGraph} from the gml
     * @return the converted {@link DefaultGraph}
     */
    public static DefaultGraph<Integer, Integer> stringGraphToIntGraph(DefaultGraph<String, String> sg) {
        DefaultGraph<Integer, Integer> retVal = new DefaultGraph<>();

        ArrayList<DefaultNode<Integer, Integer>> addedNodes = new ArrayList<>(sg.getNodeCount());
        ArrayList<DefaultEdge<Integer, Integer>> addedEdges = new ArrayList<>(sg.getEdgeCount());

        try {
            for (int i = 0; i < sg.getNodeCount(); i++)
                addedNodes.add(retVal.addNode(Integer.parseInt(sg.getNode(i).getLabel())));

            for (DefaultEdge<String, String> e : sg.edges()) {
                DefaultNode<Integer, Integer> u = retVal.getNode(e.getFirstNode().getIndex());
                DefaultNode<Integer, Integer> v = retVal.getNode(e.getSecondNode().getIndex());
                addedEdges.add(retVal.addEdge(u, v, Integer.parseInt(e.getLabel())));
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("input graph does not contain integer labels", e);
        }

        return retVal;
    }

    /**
     * Loads a dataset from multiple sdf files, where each sdf file is considered to
     * be a cluster or class. Empty clusters are removed.
     * 
     * @param path
     *            the folder to read the dataset from. Each file that ends with
     *            ".sdf" will be imported.
     * @param configure
     *            configure the CDK molecule before the conversion to the
     *            MoleculeGraph. This will add informations, such as aromaticity.
     * @param stripCDKReference
     *            remove CDKs IAtomcontainer reference (saves Memory)
     * @param filter
     *            a filter that is applied while reading the graphs. e.g. one can
     *            specify to read only graphs of a size less than some threshold. If
     *            the parameter is null, the filter is deactivated.
     * @return the Integer labeled graphs, grouped by their cluster membership.
     * 
     * @throws IOException
     * @throws FileNotFoundException
     */
    public static ArrayList<List<MoleculeGraph>> loadSdfClusters(String path, boolean configure,
            boolean stripCDKReference, Predicate<IAtomContainer> filter) throws FileNotFoundException, IOException {
        ArrayList<List<MoleculeGraph>> retVal = new ArrayList<>();
        File[] clusterFiles = new File(path)
                .listFiles((File dir, String name) -> FilenameUtils.isExtension(name, "sdf"));

        if (clusterFiles == null) {
            throw new FileNotFoundException("no cluster files found in: " + path);
        }

        for (File file : clusterFiles) {
            List<MoleculeGraph> clusterGraphs = GraphIO.sdfToMoleculeGraphs(file.getPath(), configure,
                    stripCDKReference, Integer.MAX_VALUE, filter);
            if (!clusterGraphs.isEmpty()) {
                retVal.add(clusterGraphs);
            }
        }
        return retVal;
    }

    /**
     * Loads an {@link String} labeled dataset that was previously exported via
     * {@link #clusteredGraphsToGml(Collection, String)}. The on disk structure must
     * be have a file for each cluster named "cluster_x.gml", where x is the cluster
     * identifier. Empty clusters are removed.
     * 
     * @param path
     *            the folder to read the dataset from
     * @return the Integer labeled graphs, grouped by their cluster membership.
     * 
     * @throws IOException
     * @throws FileNotFoundException
     */
    public static ArrayList<List<DefaultGraph<String, String>>> loadStringLabeledGmlClusters(String path)
            throws FileNotFoundException, IOException {
        ArrayList<List<DefaultGraph<String, String>>> retVal = new ArrayList<>();
        File[] clusterFiles = new File(path).listFiles(
                (File dir, String name) -> FilenameUtils.isExtension(name, "gml") && name.startsWith("cluster_"));

        if (clusterFiles == null) {
            throw new FileNotFoundException("no cluster files found in: " + path);
        }

        for (File file : clusterFiles) {
            List<DefaultGraph<String, String>> clusterGraphs = GraphIO.gmlToDefaultGraphs(file.getPath());
            if (!clusterGraphs.isEmpty()) {
                retVal.add(clusterGraphs);
            }
        }
        return retVal;
    }

    /**
     * Loads an Integer labeled dataset that was previously exported via
     * {@link #clusteredGraphsToGml(Collection, String)}. The on disk structure must
     * be have a file for each cluster named "cluster_x.gml", where x is the cluster
     * identifier. Empty clusters are removed.
     * 
     * @param path
     *            the folder to read the dataset from
     * @return the Integer labeled graphs, grouped by their cluster membership.
     * 
     * @throws IOException
     * @throws FileNotFoundException
     */
    public static ArrayList<List<DefaultGraph<Integer, Integer>>> loadIntLabeledGmlClusters(String path)
            throws FileNotFoundException, IOException {
        ArrayList<List<DefaultGraph<Integer, Integer>>> retVal = new ArrayList<>();
        File[] clusterFiles = new File(path).listFiles(
                (File dir, String name) -> FilenameUtils.isExtension(name, "gml") && name.startsWith("cluster_"));

        if (clusterFiles == null) {
            throw new FileNotFoundException("no cluster files found in: " + path);
        }

        for (File file : clusterFiles) {
            List<DefaultGraph<String, String>> clusterGraphs = GraphIO.gmlToDefaultGraphs(file.getPath());
            if (!clusterGraphs.isEmpty()) {
                List<DefaultGraph<Integer, Integer>> cluster = new ArrayList<>(clusterGraphs.size());

                for (DefaultGraph<String, String> mg : clusterGraphs) {
                    cluster.add(TSHelpers.stringGraphToIntGraph(mg));
                }

                retVal.add(cluster);
            }
        }
        return retVal;
    }

    /**
     * Exports an arbitrary labeled dataset as sdf file. If the graph collection is
     * ordered, the graphs are also written in the same order.
     * 
     * Note, that the number of distinct labels is limited by the sdf format.
     * 
     * @param graphs
     *            the graphs to export.
     * @param rootFolder
     *            the graphs are exported to the folder "rootFolder/dataset"
     * @throws IOException
     */
    public static <NL, EL> void clusteredGraphsToSdf(Collection<? extends Collection<? extends Graph<NL, EL>>> graphs,
            String rootFolder) throws IOException {
        File folder = new File(FilenameUtils.concat(rootFolder, "dataset"));
        folder.mkdir();

        List<? extends Graph<NL, EL>> flatGraphs = graphs.stream().flatMap(c -> c.stream())
                .collect(Collectors.toList());
        HashMap<EL, Integer> elMap = Graphs.getIntegerEdgeLabelMap(flatGraphs, 1);
        HashMap<Graph<NL, EL>, String> gnMap = new HashMap<>(graphs.size());

        int grapName = 0;
        for (Graph<NL, EL> g : flatGraphs) {
            gnMap.put(g, String.valueOf(grapName++));
        }

        int clusterId = 0;
        for (Collection<? extends Graph<NL, EL>> cluster : graphs) {
            File cFile = new File(FilenameUtils.concat(folder.getAbsolutePath(), "cluster_" + clusterId++ + ".sdf"));

            try (FileWriter fw = new FileWriter(cFile, false); BufferedWriter out = new BufferedWriter(fw)) {
                GraphIO.writeSDFGraphs(out, cluster, gnMap, elMap);
            }
        }

        File allFile = new File(FilenameUtils.concat(folder.getAbsolutePath(), "all.sdf"));
        try (FileWriter fw = new FileWriter(allFile, false); BufferedWriter out = new BufferedWriter(fw)) {
            GraphIO.writeSDFGraphs(out, flatGraphs, gnMap, elMap);
        }
    }

    /**
     * Exports an arbitrary labeled dataset as gml file. If the graph collection is
     * ordered, the graphs are also written in the same order.
     * 
     * Note that the lables are converted using the toString method.
     * 
     * @param graphs
     *            the graphs to export.
     * @param rootFolder
     *            the graphs are exported to the folder "rootFolder/dataset"
     * @throws IOException
     */
    public static <NL, EL> void clusteredGraphsToGml(Collection<? extends Collection<? extends Graph<NL, EL>>> graphs,
            String rootFolder) throws IOException {
        File folder = new File(FilenameUtils.concat(rootFolder, "dataset"));
        folder.mkdir();

        List<? extends Graph<NL, EL>> flatGraphs = graphs.stream().flatMap(c -> c.stream())
                .collect(Collectors.toList());

        int clusterId = 0;
        for (Collection<? extends Graph<NL, EL>> cluster : graphs) {
            File cFile = new File(FilenameUtils.concat(folder.getAbsolutePath(), "cluster_" + clusterId++ + ".gml"));

            try (FileWriter fw = new FileWriter(cFile, false); BufferedWriter out = new BufferedWriter(fw)) {
                for (Graph<NL, EL> g : cluster) {
                    GraphIO.writeGMLGraph(out, g);
                }
            }
        }

        File allFile = new File(FilenameUtils.concat(folder.getAbsolutePath(), "all.gml"));
        try (FileWriter fw = new FileWriter(allFile, false); BufferedWriter out = new BufferedWriter(fw)) {
            for (Graph<NL, EL> g : flatGraphs) {
                GraphIO.writeGMLGraph(out, g);
            }
        }
    }

    /**
     * Return a singleton {@link EvalMetaModule} that adds the hostname as metadata.
     * 
     * @return an {@link EvalMetaModule} that adds the hostname as metadata
     */
    public static MetaDataAdderEMM hostNameMetaData() {
        if (metaDataAdderEMM == null) {
            try {
                metaDataAdderEMM = new MetaDataAdderEMM("hostname",
                        java.net.InetAddress.getLocalHost().getCanonicalHostName());
            } catch (UnknownHostException e) {
                logger.warn("host name resolution failed");
                metaDataAdderEMM = new MetaDataAdderEMM("hostname", "unknown");
            }
        }
        return metaDataAdderEMM;
    }

    /**
     * Create some meta information for a test setup. The meta information is logged
     * and stored in a text file called info.txt.
     * 
     * @param testDescription
     *            a unique test description.
     * @param conf
     *            configuration of the clustering.
     * @param folderPath
     *            the path to save the info.txt to.
     * @param additionalMetaDataEMMs
     *            this meta data is added
     * @return an {@link EvalResult} with the metadata
     * @throws UnknownHostException
     */
    public static EvalResult logAndSaveMetadataInfo(String testDescription, StructuralClusteringConf<?, ?, ?> conf,
            String folderPath, MetaDataAdderEMM... additionalMetaDataEMMs) throws UnknownHostException {
        logger.info("---------------------------------------------------------------------------");
        logger.info("-----------{} ({})------------", testDescription, FilenameUtils.getBaseName(folderPath));
        logger.info("---------------------------------------------------------------------------");
        EvalResult info = new EvalResult("Metadat-Info - " + testDescription);
        if (conf != null) {
            info.addMetadata(conf);
        }
        Set<EvalResult> infoCollection = Collections.singleton(info);
        TSHelpers.hostNameMetaData().process(infoCollection);
        for (MetaDataAdderEMM metaDataAdderEMM : additionalMetaDataEMMs) {
            metaDataAdderEMM.process(infoCollection);
        }
        logger.info(info.toString());

        if (folderPath != null) {
            FileSaverEMM infoSaver = new FileSaverEMM(folderPath, false, false);
            infoSaver.process(infoCollection);
        }

        return info;
    }

    /**
     * generate a canonical test description in the form:
     * <testSetupName>.<testDescription>
     * 
     * @param testSetup
     *            the {@link TestSetup} implementation
     * @return the canonical test description
     */
    public static String canonicalTestDescription(Enum<? extends TestSetup> testSetup) {
        String canonicalTestDescription = testSetup.getDeclaringClass().getSimpleName() + "." + testSetup.name();
        return canonicalTestDescription;
    }

    /**
     * Converts the {@link Graph}s to {@link GraphContainer}s. Additionally filters
     * all {@link Graphs}, which:
     * <ul>
     * <li>have less than a single edge</li>
     * <li>are disconnected</li>
     * </ul>
     * 
     * @param groundTruth
     *            the clustering to filter
     * @return the filtered {@link GraphContainer}s
     */
    public static <NL, EL, G extends Graph<NL, EL>> ArrayList<GraphContainer<NL, EL, G>> groundTruth2filteredGCs(
            Collection<? extends Collection<G>> groundTruth) {
        ArrayList<G> graphs = new ArrayList<>();
        groundTruth.stream().forEach(c -> graphs.addAll(c));
        ArrayList<GraphContainer<NL, EL, G>> graphContainers = new ArrayList<>(graphs.size());

        for (G graph : graphs) {
            if (graph.size(GraphSize.nodesAndEdges) >= 3 && Graphs.isConnected(graph)) {
                graphContainers.add(new GraphContainer<>(graph));
            } else {
                groundTruth.forEach(c -> c.remove(graph));
            }
        }

        if (graphContainers.size() != graphs.size()) {
            logger.warn("Removed {} not connected or small graphs", graphs.size() - graphContainers.size());
        }
        return graphContainers;
    }

    /**
     * Converts the {@link Graph}s to {@link GraphContainer}s. Additionally filters
     * all {@link Graphs}, which:
     * <ul>
     * <li>have less than a single edge</li>
     * <li>are disconnected</li>
     * </ul>
     * 
     * Note, that the Graphs are also filtered from graphs
     * 
     * @param graphs
     *            the graphs to filter
     * @return the filtered {@link GraphContainer}s
     */
    public static <NL, EL, G extends Graph<NL, EL>> ArrayList<GraphContainer<NL, EL, G>> graphs2filteredGCs(
            Collection<G> graphs) {
        ArrayList<GraphContainer<NL, EL, G>> graphContainers = new ArrayList<>(graphs.size());

        for (Iterator<G> it = graphs.iterator(); it.hasNext();) {
            G graph = it.next();
            if (graph.size(GraphSize.nodesAndEdges) >= 3 && Graphs.isConnected(graph)) {
                graphContainers.add(new GraphContainer<>(graph));
            } else {
                it.remove();
            }
        }

        if (graphContainers.size() != graphs.size()) {
            logger.warn("Removed {} not connected or small graphs", graphs.size() - graphContainers.size());
        }
        return graphContainers;
    }

    /**
     * creates and returns an evaluation result folder. The created folder path is:
     * &lt;user.home&gt;/evalResultFolder/&lt;CanonicalHostName&gt;/ testDescription
     * 
     * @param evalResultFolder
     *            the root of the evaluation results relative to the home folder
     * @param testDescription
     *            a unique test description.
     * @return the evaluation result folder path
     */
    public static String effectiveEvalResultFolder(String evalResultFolder, String testDescription) {
        String userHome = System.getProperty("user.home");
        String canonicalHostName;
        try {
            canonicalHostName = java.net.InetAddress.getLocalHost().getCanonicalHostName();
        } catch (UnknownHostException e) {
            logger.warn("host name resolution failed");
            canonicalHostName = "unknown";
        }
        String baseFolderPath = FilenameUtils.concat(userHome, evalResultFolder);
        baseFolderPath = FilenameUtils.concat(baseFolderPath, canonicalHostName);
        baseFolderPath = FilenameUtils.concat(baseFolderPath, testDescription);
        File baseFolder = new File(baseFolderPath);
        if (!baseFolder.exists()) {
            baseFolder.mkdirs();
        }
        return baseFolderPath;
    }

    /**
     * Log the size, the average node count and the average edge count of a dataset.
     * 
     * @param generate
     *            whether this dataset was generated or loaded from a file
     * @param graphs
     *            the dataset
     */
    public static <NL, EL, G extends Graph<NL, EL>> void logDatasetSummary(boolean generate, Collection<G> graphs) {
        Preconditions.checkNotNull(graphs, "graphs must not be null");

        double minNodeCount = graphs.stream().mapToInt(x -> x.getNodeCount()).min().orElse(0);
        double avgNodeCount = graphs.stream().mapToInt(x -> x.getNodeCount()).average().orElse(Double.NaN);
        double maxNodeCount = graphs.stream().mapToInt(x -> x.getNodeCount()).max().orElse(0);
        double minEdgeCount = graphs.stream().mapToInt(x -> x.getEdgeCount()).min().orElse(0);
        double avgEdgeCount = graphs.stream().mapToInt(x -> x.getEdgeCount()).average().orElse(Double.NaN);
        double maxEdgeCount = graphs.stream().mapToInt(x -> x.getEdgeCount()).max().orElse(0);

        logger.info(
                (generate ? "Generated " : "Loaded ")
                        + "{} graphs with node count(min/avg/max): {}/{}/{}, edge count (min/avg/max): {}/{}/{}",
                graphs.size(), minNodeCount, avgNodeCount, maxNodeCount, minEdgeCount, avgEdgeCount, maxEdgeCount);
    }

    /**
     * Saves injection results from {@link SharedMemorySC}s in the folder
     * folderPath/injection/ iff conf.evalModuleInjection is set to true.
     * 
     * @param conf
     *            the clustering configuration.
     * @param clust
     *            the clustering
     * @param folderPath
     *            the folder of the test run to save the results to
     */
    public static void saveInjectionResults(SharedMemorySCC<?, ?, ?> conf, SharedMemorySC<?, ?, ?> clust,
            String folderPath) {
        if (conf.evalModuleInjection) {
            FileSaverEMM injectionsaver = new FileSaverEMM(FilenameUtils.concat(folderPath, "injection/injection.txt"),
                    true, false);
            injectionsaver.process(clust.getInjectionResults());
        }
    }

    /**
     * Returns the cluster structure obtained by a SCAP clustering. As the
     * clustering computes an id mapping, the ids need to be mapped back to graphs.
     * 
     * @param gmlSourceFile
     *            The gml files with the graphs, that were clustered. Note, that
     *            these graphs need to be ordered the same way, the input of the
     *            SCAP algorithm was ordered.
     * @param scapResultFile
     *            the rusult file of the SCAP algorithm.
     * @return the graphs in the clustering structure of SCAP.
     * @throws IOException
     * @throws FileNotFoundException
     */
    public static ArrayList<ArrayList<DefaultGraph<String, String>>> matchScapResults(String gmlSourceFile,
            String scapResultFile) throws FileNotFoundException, IOException {
        ArrayList<DefaultGraph<String, String>> orderedGraphs = GraphIO.gmlToDefaultGraphs(gmlSourceFile);
        ArrayList<ArrayList<DefaultGraph<String, String>>> retVal = new ArrayList<>();

        try (FileReader fr = new FileReader(scapResultFile); BufferedReader br = new BufferedReader(fr)) {
            if (br.readLine() == null) {
                throw new IOException("file is empty");
            } ; // header line
            String line = br.readLine();
            while (line != null) {
                if (line != "") {

                    String[] clusterAndMembers = line.split(",");
                    if (clusterAndMembers.length != 2) {
                        throw new IOException(
                                "illegal file format: cluster line should have two collons seperated by comma");
                    }
                    String[] clusterIds = clusterAndMembers[1].split(":");
                    if (clusterIds.length == 0) {
                        throw new IOException("illegal file formal: each cluster must contain at least one member id");
                    }

                    ArrayList<DefaultGraph<String, String>> cluster = new ArrayList<>();
                    for (String id : clusterIds) {
                        try {
                            Integer intId = Integer.valueOf(id);
                            if (intId < 0 || intId >= orderedGraphs.size()) {
                                throw new IOException(
                                        "cluster id out of range: " + id + " cannot be mapped to any graph");
                            }

                            cluster.add(orderedGraphs.get(intId));
                        } catch (NumberFormatException ex) {
                            throw new IOException("illegal file format: member id cannot be parsed as integer", ex);
                        }
                    }
                    retVal.add(cluster);
                }
                line = br.readLine();
            }
        }

        return retVal;
    }

}
