package struclust.eval.testsetups.rahmannwljaccardcli;

import java.util.ArrayList;
import java.util.List;

import com.beust.jcommander.Parameter;
import com.beust.jcommander.validators.PositiveInteger;

/**
 * The Parameters for WL-Jaccard CLIs
 * 
 * @author Till Schäfer
 *
 */
public class Parameters {
    @Parameter(description = "File1 File2", arity = 2)
    List<String> files = new ArrayList<>();

    @Parameter(names = {
            "--iter" }, description = "The number of WL iterations.", required = false, validateWith = {
                    PositiveInteger.class })
    Integer numIter = 2;

    @Parameter(names = "--help", help = true)
    Boolean help = false;
}