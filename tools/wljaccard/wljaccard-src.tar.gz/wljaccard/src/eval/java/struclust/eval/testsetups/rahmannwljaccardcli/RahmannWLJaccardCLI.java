package struclust.eval.testsetups.rahmannwljaccardcli;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.beust.jcommander.JCommander;
import com.beust.jcommander.ParameterException;

import graph.DefaultGraph;
import hsahn.algorithm.graph.isomorphism.labelrefinement.VertexLabelConverter;
import hsahn.comparison.kernel.graph.WeisfeilerLehmanSubtreeKernel;
import hsahn.datastructure.SparseFeatureVector;
import hsahn.graph.GraphTools;
import hsahn.graph.LGraph;
import it.unimi.dsi.fastutil.ints.Int2LongOpenHashMap;
import struclust.comparison.JaccardNFVD;
import struclust.graph.GraphContainer;
import struclust.util.GraphIO;

public class RahmannWLJaccardCLI {

    private static final JaccardNFVD<Integer> dist = new JaccardNFVD<>();

    public static void main(String[] args)
            throws FileNotFoundException, UnknownHostException, IOException, InterruptedException {
        Parameters param = new Parameters();
        JCommander jCom = new JCommander(param);
        try {
            jCom.parse(args);
        } catch (ParameterException e) {
            printGeneralMessage();
            jCom.usage();
            return;
        }

        if (param.help) {
            printGeneralMessage();
            jCom.usage();
            return;
        }

        WeisfeilerLehmanSubtreeKernel<String, String> kernel = new WeisfeilerLehmanSubtreeKernel<>(param.numIter, true);

        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> firstGCs = GraphIO
                .gmlToPropertyGraphContainer(param.files.get(0));
        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> secondGCs = GraphIO
                .gmlToPropertyGraphContainer(param.files.get(1));

        List<LGraph<String, String>> firstLGraphs = new ArrayList<>(firstGCs.size());
        for (GraphContainer<String, String, DefaultGraph<String, String>> graph : firstGCs) {
            firstLGraphs.add(GraphTools.convert(graph));
        }
        List<LGraph<String, String>> secondLGraphs = new ArrayList<>(secondGCs.size());
        for (GraphContainer<String, String, DefaultGraph<String, String>> graph : secondGCs) {
            secondLGraphs.add(GraphTools.convert(graph));
        }

        ArrayList<SparseFeatureVector<Integer>> firstFVs = kernel.computeExplicitMapping(firstLGraphs);
        ArrayList<SparseFeatureVector<Integer>> secondFVs = kernel.computeExplicitMapping(secondLGraphs);

        VertexLabelConverter<String> vlc = kernel.getVertexLabelConverter();

        ArrayList<Set<Integer>> iterLabels = new ArrayList<>();
        for (int i = 0; i < param.numIter; i++) {
            iterLabels.add(vlc.getLabels(i));
        }

        // origfv / iter / iterFV
        ArrayList<ArrayList<SparseFeatureVector<Integer>>> iterFirstFVs = new ArrayList<>();
        ArrayList<ArrayList<SparseFeatureVector<Integer>>> iterSecondFVs = new ArrayList<>();

        createCurrentIterFVs(firstFVs, iterFirstFVs, iterLabels, param);
        createCurrentIterFVs(secondFVs, iterSecondFVs, iterLabels, param);

        for (int firstGI = 0; firstGI < firstGCs.size(); firstGI++) {
            for (int secondGI = 0; secondGI < secondGCs.size(); secondGI++) {
                for (int iter = 0; iter < param.numIter; iter++) {
                    double sim = 1
                            - dist.calc(iterFirstFVs.get(firstGI).get(iter), iterSecondFVs.get(secondGI).get(iter));
                    System.out.print(sim + "\t");
                }
                System.out.println();
            }
        }

    }

    private static void printGeneralMessage() {
        System.out.println(
                "This tool will caclucalte the jaccard distance based on Weisfeiler-Lehman(WL) Feature Vectors.\n"
                        + "One distance is computed for each pair in File1 x File2. "
                        + "The graphs from the input are compared in the order File1#1xFile2, File1#2xFile2, ...\n"
                        + "For each comparison one value is computed for each WL-Iteartion. "
                        + "The coresponing values are are issued in the format \"val_iter1\\tval_iter2\\t...\"");

    }

    private static void createCurrentIterFVs(ArrayList<SparseFeatureVector<Integer>> FVs,
            ArrayList<ArrayList<SparseFeatureVector<Integer>>> iterFVs, ArrayList<Set<Integer>> iterLabels,
            Parameters param) {
        for (SparseFeatureVector<Integer> fv : FVs) {
            ArrayList<SparseFeatureVector<Integer>> curFVs = new ArrayList<>();
            iterFVs.add(curFVs);
            for (int iter = 0; iter < param.numIter; iter++) {
                Map<Integer, Long> featureMap = new Int2LongOpenHashMap(fv.featureMap());
                featureMap.keySet().retainAll(iterLabels.get(iter));
                curFVs.add(new SparseFeatureVector<>(featureMap));
            }
        }
    }
}
