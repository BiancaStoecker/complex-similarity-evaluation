package match.pattern;

import graph.Edge;

import java.util.HashMap;

/**
 * Interface for classes to determine the compatibility of edges.
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public interface EdgeMatcher<NL, EL> {

    /**
     * Determines the compatibility of the two edges.
     * 
     * @param patternEdge
     *            the edge of the pattern graph
     * @param hosteEdge
     *            the edge of the host graph
     * @return the compatibility
     */
    public boolean match(Edge<NL, EL> patternEdge, Edge<NL, EL> hosteEdge);

    /**
     * Ignores edge label.
     * 
     * @param <NL>
     *            the node label type
     * @param <EL>
     *            the edge label type
     */
    public class IgnoreLabel<NL, EL> implements EdgeMatcher<NL, EL> {
        public boolean match(Edge<NL, EL> patternEdge, Edge<NL, EL> hostEdge) {
            return true;
        }
    }

    /**
     * Verifies edge label.
     * 
     * @param <NL>
     *            the node label type
     * @param <EL>
     *            the edge label type
     */
    public class Label<NL, EL> implements EdgeMatcher<NL, EL> {
        public boolean match(Edge<NL, EL> patternEdge, Edge<NL, EL> hostEdge) {
            return patternEdge.getLabel().equals(hostEdge.getLabel());
        }
    }

    /**
     * Respects Wildcard Labels.
     */
    public class Wildcards implements EdgeMatcher<String, String> {
        private HashMap<Edge<String, String>, GraphQueryLabel<String>> edgeQueryLabels;

        /**
         * Constructor
         * 
         * @param edgeQueryLabels
         *            the query labels for wildcard matching. If an edge is not
         *            contained in this map a standard label comparison based on
         *            equals is done.
         */
        public Wildcards(HashMap<Edge<String, String>, GraphQueryLabel<String>> edgeQueryLabels) {
            this.edgeQueryLabels = edgeQueryLabels;
        }

        public boolean match(Edge<String, String> patternEdge, Edge<String, String> hostEdge) {
            String patternLabel = patternEdge.getLabel();
            GraphQueryLabel<String> queryLabel = edgeQueryLabels.get(patternLabel);
            if (queryLabel != null) {
                return queryLabel.matches(hostEdge.getLabel());
            } else {
                return patternLabel.equals(hostEdge.getLabel());
            }
        }
    }
}
