package match;

import graph.Edge;
import graph.Graph;
import graph.Node;

import java.util.List;

import match.pattern.SearchPattern;
import match.pattern.SearchPlan;

/**
 * The algorithm uses a sequence of pattern nodes with joinEdges (edges from a
 * node to previous nodes) for a backtracking search on the host graph to reduce
 * overhead.
 * 
 * The search-space is pruned by checking the degree of nodes only.
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public class MatcherFast<NL, EL> extends Matcher<NL, EL> {

    PartialMapping<NL, EL> pm;

    /**
     * Constructs a new instance to match the given graphs.
     * 
     * @param patternGraph
     *            the pattern graph
     * @param hostGraph
     *            the host graph
     */
    public MatcherFast(Graph<NL, EL> patternGraph, Graph<NL, EL> hostGraph) {
        super(patternGraph, hostGraph);
        pm = new PartialMapping<>(searchPattern, host);
    }

    /**
     * Constructs a new instance to match the given graphs.
     * 
     * @param searchPattern
     *            the search pattern
     * @param hostGraph
     *            the host graph
     */
    public MatcherFast(SearchPattern<NL, EL> searchPattern, Graph<NL, EL> hostGraph) {
        super(searchPattern, hostGraph);
        pm = new PartialMapping<NL, EL>(searchPattern, host);
    }

    @Override
    public List<NodePair<NL, EL>> getMatch() {
        if (!pm.isComplete())
            return null;

        return pm.getMapping();
    }

    private Node<NL, EL> getJoinHostNode(SearchPlan<NL, EL>.Extension ext, Node<NL, EL> patternCandidate) {
        Edge<NL, EL> joinEdge = ext.getJoinEdges().getFirst();
        Node<NL, EL> joinHostNode = pm.mapToHostNode(joinEdge.getOppositeNode(patternCandidate));
        return joinHostNode;
    }

    /*
     * private Node getMinDegreeJoinHostNode(SearchPlan.Extension ext, Node
     * patternCandidate) { // TODO use number of unmapped nodes instead of
     * degree
     * 
     * Node minJoinHostNode = null; int minDegree = Integer.MAX_VALUE; for (Edge
     * joinEdge : ext.getJoinEdges()) { Node joinHostNode =
     * pm.mapToHostNode(joinEdge.getOppositeNode(patternCandidate)); if
     * (joinHostNode.getDegree() < minDegree) { minJoinHostNode = joinHostNode;
     * minDegree = joinHostNode.getDegree(); } }
     * 
     * return minJoinHostNode; }
     */

    @Override
    public boolean match() {

        if (pm.isComplete())
            return handleMatch(pm);

        SearchPlan<NL, EL>.Extension ext = searchPlan.getExtension(pm.getSize());
        Node<NL, EL> patternCandidate = ext.getNode();

        if (!ext.hasJoinEdges()) {
            // the host candidates can not be restricted to adjacent nodes,
            // all host nodes have to be checked
            for (Node<NL, EL> hostCandidate : host.nodes()) {
                if (pm.isFeasibleNodePair(patternCandidate, hostCandidate)) {
                    pm.extend(patternCandidate, hostCandidate);
                    if (match())
                        return true;
                    pm.remove(patternCandidate, hostCandidate);
                }
            }
        } else {
            Node<NL, EL> joinHostNode = getJoinHostNode(ext, patternCandidate);

            // only check adjacent nodes
            for (Edge<NL, EL> edgeCandidate : joinHostNode.getEdges()) {
                Node<NL, EL> hostCandidate = edgeCandidate.getOppositeNode(joinHostNode);
                if (pm.isFeasibleNodePair(patternCandidate, hostCandidate)
                        && pm.isFeasibleConnectedPair(patternCandidate, hostCandidate, ext.getJoinEdges())) {
                    pm.extend(patternCandidate, hostCandidate);
                    if (match())
                        return true;
                    pm.remove(patternCandidate, hostCandidate);
                }
            }
        }

        return false;
    }
}
