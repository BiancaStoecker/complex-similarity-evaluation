package match.pattern;

import graph.Graph;
import graph.Node;

import java.util.Comparator;
import java.util.Random;

/**
 * Allows to impose random orderings.
 * 
 * Note: this comparator imposes orderings that are inconsistent with equals.
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public class RandomComparator<NL, EL> implements Comparator<Node<NL, EL>> {

    private static final long seed = 88686765;

    private int[] randomValues;

    /**
     * Initializes a new instance.
     * 
     * @param g
     *            the graph whose nodes should be compared
     */
    public RandomComparator(Graph<NL, EL> g) {
        randomValues = new int[g.getNodeCount()];

        Random r = new Random(seed);
        for (int i = 0; i < randomValues.length; i++) {
            randomValues[i] = r.nextInt();
        }
    }

    public int compare(Node<NL, EL> u, Node<NL, EL> v) {
        int uVal = randomValues[u.getIndex()];
        int vVal = randomValues[v.getIndex()];

        if (uVal < vVal)
            return -1;
        if (uVal > vVal)
            return 1;

        return 0;
    }

}
