package match.pattern;

import graph.Edge;
import graph.Graph;
import graph.MoleculeGraph;
import graph.Node;

import java.util.HashMap;

/**
 * Stores a pattern graph together with its search plan and the its node/edge
 * matcher.
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public class SearchPattern<NL, EL> {

    private Graph<NL, EL> graph;
    private NodeMatcher<NL, EL> nodeMatcher;
    private EdgeMatcher<NL, EL> edgeMatcher;
    private SearchPlan<NL, EL> searchPlan;
    private boolean useWildcards;
    /*
     * Mapping from node index to the GraphQueryLabel
     */
    private GraphQueryLabel<String> nodeQueryLabels[];
    /*
     * Mapping from edge to the GraphQueryLabel
     */
    private HashMap<Edge<String, String>, GraphQueryLabel<String>> edgeQueryLabels = new HashMap<>();

    /**
     * Initializes a new search pattern.
     * 
     * @param graph
     *            the pattern graph
     * @param useWildcards
     *            account for wildcard labels
     * @param priorityMode
     *            mode to determine the node order
     */
    public SearchPattern(Graph<NL, EL> graph, boolean useWildcards, int priorityMode) {
        assert graph != null; 
        assert graph.nodes().size() > 0;
        // ensure that the label type is string if we use wildcards
        assert !this.useWildcards || graph.getNode(0).getLabel() instanceof String;

        this.graph = graph;

        configure(useWildcards);

        this.searchPlan = new SearchPlan<NL, EL>(graph, priorityMode);
    }

    /**
     * Note: If useWildcards is true, wildcards label of the graphs will be
     * changed to GraphQueryLabel
     * 
     * @param graph
     * @param useWildcards
     */
    public SearchPattern(Graph<NL, EL> graph, boolean useWildcards) {
        this(graph, useWildcards, (graph instanceof MoleculeGraph) ? SearchPlan.ATOM_FREQUENCY_PRIORITY
                : SearchPlan.NO_PRIORITY);
    }

    @SuppressWarnings("unchecked")
    private void configure(boolean useWildcards) {
        if (useWildcards && compileQueryLabel()) {
            this.nodeMatcher = (NodeMatcher<NL, EL>) new NodeMatcher.Wildcards(nodeQueryLabels);
            this.edgeMatcher = (EdgeMatcher<NL, EL>) new EdgeMatcher.Wildcards(edgeQueryLabels);
            this.useWildcards = true;
        } else {
            this.nodeMatcher = new NodeMatcher.Label<>();
            this.edgeMatcher = new EdgeMatcher.Label<>();
            this.useWildcards = false;
        }
    }

    @SuppressWarnings("unchecked")
    private boolean compileQueryLabel() {
        boolean hasQueryLabel = false;
        for (Node<NL, EL> n : graph.nodes()) {
            String label = (String) n.getLabel();
            int nodeIndex = n.getIndex();
            if (label.equals("*") || label.equals("R")) {
                nodeQueryLabels[nodeIndex] = new GraphQueryLabel.Wildcard();
                hasQueryLabel = true;
            } else if (label.contains("[")) {
                // format must be [symbol,symbol,...] or
                // ![symbol,symbol,...]
                GraphQueryLabel.AbstractList<String> queryList;
                if (label.startsWith("!")) {
                    queryList = new GraphQueryLabel.NotList<>();
                    label = label.substring(1); // remove '!'
                } else {
                    queryList = new GraphQueryLabel.List<>();
                }
                label = label.substring(1, label.length() - 1);
                String[] list = label.split(",");
                queryList.setLabelList(list);
                nodeQueryLabels[nodeIndex] = queryList;
                hasQueryLabel = true;
            }
        }
        for (Edge<NL, EL> e : graph.edges()) {
            String s = (String) e.getLabel();
            if (s.equals("*")) {
                edgeQueryLabels.put((Edge<String, String>) e, new GraphQueryLabel.Wildcard());
                hasQueryLabel = true;
            }
        }
        return hasQueryLabel;
    }

    /**
     * @return the pattern graph
     */
    public Graph<NL, EL> getGraph() {
        return graph;
    }

    /**
     * @return the node matcher
     */
    public NodeMatcher<NL, EL> getNodeMatcher() {
        return nodeMatcher;
    }

    /**
     * @return the edge matcher
     */
    public EdgeMatcher<NL, EL> getEdgeMatcher() {
        return edgeMatcher;
    }

    /**
     * @return the search plan
     */
    public SearchPlan<NL, EL> getSearchPlan() {
        return searchPlan;
    }

    /**
     * @return true if wildcards are considered
     */
    public boolean getUseWildcards() {
        return useWildcards;
    }

}
