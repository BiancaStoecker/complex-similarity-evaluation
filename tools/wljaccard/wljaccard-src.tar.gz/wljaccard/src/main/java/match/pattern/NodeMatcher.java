package match.pattern;

import graph.Node;

/**
 * Interface for classes to determine the compatibility of nodes.
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public interface NodeMatcher<NL, EL> {

    /**
     * Determines the compatibility of the two nodes.
     * 
     * @param patternNode
     *            the node of the pattern graph
     * @param hostNode
     *            the node of the host graph
     * @return the compatibility
     */
    public boolean match(Node<NL, EL> patternNode, Node<NL, EL> hostNode);

    /**
     * Ignores node label. the host edge label type
     * 
     * @param <NL>
     *            the node label type
     * @param <EL>
     *            the edge label type
     */
    public class IgnoreLabel<NL, EL> implements NodeMatcher<NL, EL> {
        @Override
        public boolean match(Node<NL, EL> patternNode, Node<NL, EL> hostNode) {
            return true;
        }
    }

    /**
     * Verifies node label.
     * 
     * @param <NL>
     *            the node label type
     * @param <EL>
     *            the edge label type
     */
    public class Label<NL, EL> implements NodeMatcher<NL, EL> {
        @Override
        public boolean match(Node<NL, EL> patternNode, Node<NL, EL> hostNode) {
            return patternNode.getLabel().equals(hostNode.getLabel());
        }
    }

    /**
     * Respects Wildcard Labels.
     */
    public class Wildcards implements NodeMatcher<String, String> {
        private GraphQueryLabel<String> queryLabels[];

        /**
         * Constructor
         * 
         * @param queryLabels
         *            the query labels for wildcard matching. The index must
         *            match the node index of the pattern node. If an entry is
         *            null a standard label comparison based on equals is done.
         */
        public Wildcards(GraphQueryLabel<String>[] queryLabels) {
            this.queryLabels = queryLabels;

        }

        @Override
        public boolean match(Node<String, String> patternNode, Node<String, String> hostNode) {
            GraphQueryLabel<String> patternLabel = queryLabels[patternNode.getIndex()];
            if (patternLabel != null) {
                return patternLabel.matches(hostNode.getLabel());
            } else {
                return patternNode.getLabel().equals(hostNode.getLabel());
            }
        }
    }
}
