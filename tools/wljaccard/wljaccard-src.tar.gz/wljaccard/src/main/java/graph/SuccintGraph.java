package graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.math3.util.Pair;

import com.google.common.base.Preconditions;

import struclust.util.Numerical;

/**
 * This is a graph that tries to minimize the memory footprint by using an
 * unmodifiable forward star representation. It also packs the labels with the
 * node indices into a single native integer, such that no object overhead is
 * required for nodes and edges. For this reason the graph is limited to integer
 * labels.
 * 
 * Special Properties:
 * <ul>
 * <li>does NOT support multiple edges</li>
 * <li>unmodifiable</li>
 * </ul>
 * 
 * @author Till Schäfer
 */
public class SuccintGraph implements Graph<Integer, Integer> {

    /**
     * Each cell contains a tuple (firstEdgeIndex, nodeLabel), where
     * firstEdgeIndex in the index in the edges array.
     */
    int nodes[];
    /**
     * each cell contains a tuple (secondNodeIndex, edgeLabel), where
     * secondNodeIndex is the index of the second adjacent node. The first
     * adjacent node is implicitly given by the position in the array.
     */
    int edges[];

    /**
     * Copy Constructor
     * 
     * @param graph
     *            the source graph to copy. if null an empty graph is created.
     */
    public SuccintGraph(Graph<Integer, Integer> graph) {
        if (graph == null) {
            return;
        }

        HashMap<Node<Integer, Integer>, Integer> nodeToIndex = new HashMap<>();

        int index = 0;
        for (Node<Integer, Integer> n : graph.nodes()) {
            nodeToIndex.put(n, index);
            index++;
        }

        nodes = new int[graph.getNodeCount()];
        edges = new int[2 * graph.getEdgeCount()];

        int edgeIndex = 0;
        int nodeIndex = 0;
        for (Node<Integer, Integer> n : graph.nodes()) {
            nodes[nodeIndex] = Numerical.packUnsigned1616(edgeIndex, n.getLabel());

            for (Edge<Integer, Integer> e : n.getEdges()) {
                edges[edgeIndex] = Numerical.packUnsigned1616(nodeToIndex.get(e.getOppositeNode(n)), e.getLabel());
                edgeIndex++;
            }
            nodeIndex++;
        }
    }

    /**
     * Copy Constructor with label conversion
     * 
     * @param graph
     *            the source graph to copy. if null an empty graph is created.
     * @param nodeLableMapping
     *            the mapping to convert the node labels to {@link Integer}s
     * @param edgeLabelMapping
     *            the mapping to convert the edge labels to {@link Integer}s
     * @param addNewLabels
     *            if true, missing label maps are automatically added (mapping
     *            to the lowest available integer value)
     */
    public <NL, EL> SuccintGraph(Graph<NL, EL> graph, Map<NL, Integer> nodeLableMapping,
            Map<EL, Integer> edgeLabelMapping, boolean addNewLabels) {
        if (graph == null) {
            return;
        }
        Preconditions.checkNotNull(nodeLableMapping);
        Preconditions.checkNotNull(edgeLabelMapping);

        HashMap<Node<NL, EL>, Integer> nodeToIndex = new HashMap<>();

        int index = 0;
        for (Node<NL, EL> n : graph.nodes()) {
            nodeToIndex.put(n, index);
            index++;
        }

        nodes = new int[graph.getNodeCount()];
        edges = new int[2 * graph.getEdgeCount()];

        int edgeIndex = 0;
        int nodeIndex = 0;
        for (Node<NL, EL> n : graph.nodes()) {
            nodes[nodeIndex] = Numerical.packUnsigned1616(edgeIndex,
                    intLabelMapping(nodeLableMapping, n.getLabel(), addNewLabels));

            for (Edge<NL, EL> e : n.getEdges()) {
                edges[edgeIndex] = Numerical.packUnsigned1616(nodeToIndex.get(e.getOppositeNode(n)),
                        intLabelMapping(edgeLabelMapping, e.getLabel(), addNewLabels));
                edgeIndex++;
            }
            nodeIndex++;
        }
    }

    /**
     * Return the mapped {@link Integer} value of a given label. If the label is
     * not contained in the mapping and addNewLable is true a map from label to
     * the lowest unused {@link Integer} value is added to the mapping. An
     * IllegalStateException is thrown otherwise.
     * 
     * @param mapping
     *            the label to {@link Integer} mapping
     * @param label
     *            the label
     * @param addNewLabels
     *            if true, missing maps are added to the mapping.
     * @return the mapped {@link Integer} value for label
     */
    private <T> Integer intLabelMapping(Map<T, Integer> mapping, T label, boolean addNewLabels) {
        synchronized (mapping) {
            if (mapping.containsKey(label)) {
                return mapping.get(label);
            } else if (!addNewLabels) {
                throw new IllegalStateException("No mapping from defined for: " + label.toString());
            }

            HashSet<Integer> intValues = new HashSet<>(mapping.values());
            for (int i = 0;; i++) {
                if (!intValues.contains(i)) {
                    mapping.put(label, i);
                    return i;
                }
            }
        }
    }

    @Override
    public List<? extends Node<Integer, Integer>> nodes() {
        ArrayList<SuccintNode> nodeList = new ArrayList<>(nodes.length);

        for (int nodeIndex = 0; nodeIndex < nodes.length; nodeIndex++) {
            nodeList.add(new SuccintNode(this, nodeIndex, getNodeLabel(nodeIndex)));
        }

        return nodeList;
    }

    @Override
    public List<? extends Edge<Integer, Integer>> edges() {
        ArrayList<SuccintEdge> retVal = new ArrayList<>();

        for (int nodeIndex = 0; nodeIndex < nodes.length; nodeIndex++) {
            for (int edgeIndex = getFirstEdgeIndex(nodeIndex); edgeIndex < getEndEdgeIndex(nodeIndex); edgeIndex++) {
                int secondNodeIndex = getSecondNodeIndex(edgeIndex);
                if (nodeIndex < secondNodeIndex) {
                    retVal.add(new SuccintEdge(this, nodeIndex, secondNodeIndex, getEdgeLabel(edgeIndex)));
                }
            }
        }

        return retVal;
    }

    /**
     * Get all {@link Edge}s that are adjacent to this node
     * 
     * @param nodeIndex
     *            the index of the node
     * 
     * @return adjacent {@link Edge}s
     */
    public List<? extends Edge<Integer, Integer>> edges(int nodeIndex) {
        ArrayList<SuccintEdge> retVal = new ArrayList<>();

        for (int edgeIndex = getFirstEdgeIndex(nodeIndex); edgeIndex < getEndEdgeIndex(nodeIndex); edgeIndex++) {
            int secondNodeIndex = getSecondNodeIndex(edgeIndex);
            retVal.add(new SuccintEdge(this, nodeIndex, secondNodeIndex, getEdgeLabel(edgeIndex)));
        }

        return retVal;
    }

    @Override
    public Node<Integer, Integer> getNode(int index) {
        assert index < nodes.length : "index out of range";

        return new SuccintNode(this, index, getNodeLabel(index));
    }

    @Override
    public int getNodeCount() {
        return nodes.length;
    }

    @Override
    public int getEdgeCount() {
        return edges.length / 2;
    }

    @Override
    public boolean hasEdge(Node<Integer, Integer> u, Node<Integer, Integer> v) {
        return getEdge(u, v) != null;
    }

    @Override
    public Edge<Integer, Integer> getEdge(Node<Integer, Integer> u, Node<Integer, Integer> v) {
        assertValidNodeParameter(u);
        assertValidNodeParameter(v);

        int uIndex = u.getIndex();
        int vIndex = v.getIndex();

        if (getNodeDegree(uIndex) < getNodeDegree(vIndex)) {
            for (int edgeIndex = getFirstEdgeIndex(uIndex); edgeIndex < getEndEdgeIndex(uIndex); edgeIndex++) {
                if (getSecondNodeIndex(edgeIndex) == vIndex) {
                    return new SuccintEdge(this, uIndex, vIndex, getEdgeLabel(edgeIndex));
                }
            }
        } else {
            for (int edgeIndex = getFirstEdgeIndex(vIndex); edgeIndex < getEndEdgeIndex(vIndex); edgeIndex++) {
                if (getSecondNodeIndex(edgeIndex) == uIndex) {
                    return new SuccintEdge(this, uIndex, vIndex, getEdgeLabel(edgeIndex));
                }
            }
        }
        return null;
    }

    @Override
    public Node<Integer, Integer> addNode(Integer label) {
        throw new UnsupportedOperationException("SuccintGraph is unmodifyable");
    }

    @Override
    public void removeNode(Node<Integer, Integer> u) {
        throw new UnsupportedOperationException("SuccintGraph is unmodifyable");
    }

    @Override
    public Edge<Integer, Integer> addEdge(Node<Integer, Integer> u, Node<Integer, Integer> v, Integer label) {
        throw new UnsupportedOperationException("SuccintGraph is unmodifyable");
    }

    @Override
    public void addEdge(Edge<Integer, Integer> e) {
        throw new UnsupportedOperationException("SuccintGraph is unmodifyable");
    }

    @Override
    public void removeEdge(Edge<Integer, Integer> e) {
        throw new UnsupportedOperationException("SuccintGraph is unmodifyable");
    }

    @Override
    public Pair<? extends List<? extends Node<Integer, Integer>>, ? extends List<? extends Edge<Integer, Integer>>> addGraph(
            Graph<Integer, Integer> g) {
        throw new UnsupportedOperationException("SuccintGraph is unmodifyable");
    }

    /**
     * Get the node degree of a node.
     * 
     * @param nodeIndex
     *            the index of the node
     * @return the node degree of node with index nodeIndex
     */
    public int getNodeDegree(int nodeIndex) {
        return getEndEdgeIndex(nodeIndex) - getFirstEdgeIndex(nodeIndex);
    }

    @Override
    public boolean isIndexConsistent() {
        for (int nodeIndex = 0; nodeIndex < nodes.length; nodeIndex++) {
            if (getFirstEdgeIndex(nodeIndex) >= edges.length) {
                return false;
            }
        }
        for (int edgeIndex = 0; edgeIndex < nodes.length; edgeIndex++) {
            if (getSecondNodeIndex(edgeIndex) >= nodes.length) {
                return false;
            }
        }

        return true;
    }

    @Override
    public String toString() {
        final String eol = System.getProperty("line.separator");
        StringBuilder sb = new StringBuilder();
        sb.append("V={");
        for (Node<Integer, Integer> n : nodes()) {
            sb.append("(");
            sb.append(n.getIndex());
            sb.append(",");
            sb.append(n.getLabel());
            sb.append(") ");
        }
        if (!nodes().isEmpty()) {
            sb.deleteCharAt(sb.length() - 1);
        }
        sb.append("}");
        sb.append(eol);
        sb.append("E={");
        for (Edge<Integer, Integer> e : edges()) {
            sb.append("(");
            sb.append(e.getFirstNode().getIndex());
            sb.append(",");
            sb.append(e.getSecondNode().getIndex());
            sb.append(",");
            sb.append(e.getLabel());
            sb.append(") ");
        }
        if (!edges().isEmpty()) {
            sb.deleteCharAt(sb.length() - 1);
        }
        sb.append("}");

        return sb.toString();
    }

    /**
     * @param u
     */
    protected void assertValidNodeParameter(Node<Integer, Integer> u) {
        assert u instanceof SuccintNode : "no instance of SuccintNode";
        assert ((SuccintNode) u).getGraph() == this : "node from another graph";
        assert u.getIndex() < nodes.length : "node index out of range";
    }

    /**
     * Get the edges array index for the first edge of node.
     * 
     * @param nodeIndex
     *            the node index to get the first edge index for.
     * @return the edges array index for the first outgoing edge
     */
    private int getFirstEdgeIndex(int nodeIndex) {
        return Numerical.unpackUnsigned16Left(nodes[nodeIndex]);
    }

    /**
     * Get the edges array index of the last edge of node + 1. If the node has a
     * degree of 0, this is getFirstEdgeIndex(node).
     * 
     * @param nodeIndex
     *            the node index to get the last edge index for
     * @return the edges array index of the last edge + 1
     */
    private int getEndEdgeIndex(int nodeIndex) {
        return nodeIndex == nodes.length - 1 ? edges.length : getFirstEdgeIndex(nodeIndex + 1);
    }

    /**
     * Get the label of a node.
     * 
     * @param nodeIndex
     *            the node index to get the label for
     * @return the label of node
     */
    private int getNodeLabel(int nodeIndex) {
        return Numerical.unpackUnsigned16Right(nodes[nodeIndex]);
    }

    /**
     * Get the second node index of an edge.
     * 
     * @param edgeIndex
     *            the edge index to get the second edge index for
     * @return the second node index
     */
    private int getSecondNodeIndex(int edgeIndex) {
        return Numerical.unpackUnsigned16Left(edges[edgeIndex]);
    }

    /**
     * Get the label of an edge.
     * 
     * @param edgeIndex
     *            the edge index to get the label for
     * @return the label of edge
     */
    private int getEdgeLabel(int edgeIndex) {
        return Numerical.unpackUnsigned16Right(edges[edgeIndex]);
    }

}
