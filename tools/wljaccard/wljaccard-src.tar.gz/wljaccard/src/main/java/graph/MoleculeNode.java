package graph;

import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IPseudoAtom;

/**
 * A {@link Graph} {@link DefaultNode} that has additional linkage to the
 * corresponding {@link IAtom}
 * 
 * @author Nils Kriege
 * 
 */
public class MoleculeNode extends DefaultNode<String, String> {
    private static final long serialVersionUID = 1L;
    
    IAtom atom;

    /**
     * Constructor
     * 
     * @param atom
     *            the linked {@link IAtom}
     * @param index
     *            the index in the {@link Graph}
     */
    public MoleculeNode(IAtom atom, int index) {
        super(atom instanceof IPseudoAtom ? ((IPseudoAtom) atom).getLabel() : atom.getSymbol(), index);
        this.atom = atom;
    }

    /**
     * Constructor for an null atom
     * 
     * @param atom
     *            the linked {@link IAtom}
     * @param index
     *            the index in the {@link Graph}
     */
    MoleculeNode(String label, int index) {
        super(label, index);
        this.atom = null;
    }

    /**
     * Returns the linked {@link IAtom}
     * 
     * @return the linked {@link IAtom}
     */
    public IAtom getAtom() {
        return atom;
    }

    /**
     * Removes the {@link IAtom} reference
     */
    public void stripIAtom() {
        atom = null;
    }
}
