package graph;

/**
 * Enumeration of the possible counting methods for a graphs size
 * 
 * @author Till Schäfer
 */
public enum GraphSize {
    /**
     * Count only nodes
     */
    nodes,
    /**
     * Count only edges
     */
    edges,
    /**
     * Count both nodes and edges
     */
    nodesAndEdges,
}
