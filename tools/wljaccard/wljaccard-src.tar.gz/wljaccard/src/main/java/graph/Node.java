package graph;

import java.util.List;

/**
 * A {@link Graph} node
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public interface Node<NL, EL> {

    /**
     * Get the index
     * 
     * @return the index
     */
    public int getIndex();

    /**
     * Set the index
     * 
     * Attention: Be careful! The Index must stay in sync with the graph data
     * structure
     * 
     * @param index
     *            the index
     */
    void setIndex(int index);

    /**
     * Get the label
     * 
     * @return the label
     */
    public NL getLabel();

    /**
     * Set the label
     * 
     * @param o
     *            the label
     */
    public void setLabel(NL o);

    /**
     * Get all {@link Edge}s that are adjacent to this node
     * 
     * @return adjacent {@link Edge}s
     */
    public List<? extends Edge<NL, EL>> getEdges();

    /**
     * Get the number of incident {@link Edge}s
     * 
     * @return the degree
     */
    public int getDegree();

    /**
     * Adds an adjacent edge to the node
     * 
     * @param e
     *            the edge
     */
    void addEdge(Edge<NL, EL> e);

    /**
     * Removes an adjacent edge from the node
     * 
     * @param e
     *            the edge
     * @return true if this node contained the specified element
     */
    boolean removeEdge(Edge<NL, EL> e);

}
