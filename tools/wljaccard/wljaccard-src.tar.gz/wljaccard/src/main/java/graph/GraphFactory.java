package graph;

/**
 * Interface for {@link Graph} factories
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface GraphFactory<NL, EL, G extends Graph<NL, EL>> {
    /**
     * Factory method
     * 
     * @return a new instance of G
     */
    public G create();

    /**
     * Factory method to clone a graph
     * 
     * @param source
     *            the source graph to clone
     * 
     * @return a clone of source
     */
    public G clone(G source);
}
