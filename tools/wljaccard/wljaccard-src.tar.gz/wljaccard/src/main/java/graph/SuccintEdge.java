package graph;

/**
 * This is a dummy {@link Edge} object for the {@link SuccintGraph}, that is
 * only used for external representation in order to conform with the
 * {@link Graph} interface.
 * 
 * @author Till Schäfer
 *
 */
public class SuccintEdge implements Edge<Integer, Integer> {

    private SuccintGraph graph;
    private int firstNodeIndex;
    private int secondNodeIndex;
    private Integer label;

    /**
     * Constructor
     * 
     * @param firstNodeIndex
     *            the index of the first node
     * @param secondNodeIndex
     *            the index of the second node
     * @param label
     *            the label of the node
     */
    SuccintEdge(SuccintGraph graph, int firstNodeIndex, int secondNodeIndex, Integer label) {
        this.graph = graph;
        this.firstNodeIndex = firstNodeIndex;
        this.secondNodeIndex = secondNodeIndex;
        this.label = label;
    }

    @Override
    public Integer getLabel() {
        return label;
    }

    @Override
    public void setLabel(Integer o) {
        throw new UnsupportedOperationException("SuccintGraph is unmodifyable");
    }

    @Override
    public Node<Integer, Integer> getFirstNode() {
        return graph.getNode(firstNodeIndex);
    }

    @Override
    public Node<Integer, Integer> getSecondNode() {
        return graph.getNode(secondNodeIndex);
    }

    @Override
    public Node<Integer, Integer> getOppositeNode(Node<Integer, Integer> v) {
        assert (v.getIndex() == firstNodeIndex || v.getIndex() == secondNodeIndex);

        if (v.getIndex() == firstNodeIndex) {
            return getSecondNode();
        } else {
            return getFirstNode();
        }
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + firstNodeIndex;
        result = prime * result + ((graph == null) ? 0 : graph.hashCode());
        result = prime * result + secondNodeIndex;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SuccintEdge other = (SuccintEdge) obj;
        if (firstNodeIndex != other.firstNodeIndex)
            return false;
        if (graph == null) {
            if (other.graph != null)
                return false;
        } else if (!graph.equals(other.graph))
            return false;
        if (secondNodeIndex != other.secondNodeIndex)
            return false;
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(getFirstNode().getIndex());
        sb.append(",");
        sb.append(getSecondNode().getIndex());
        sb.append(",");
        sb.append(getLabel());
        sb.append(") ");
        return sb.toString();
    }
}
