package graph;

import java.util.List;

/**
 * This is a dummy {@link Node} object for the {@link SuccintGraph}, that is
 * only used for external representation in order to conform with the
 * {@link Graph} interface.
 * 
 * @author Till Schäfer
 */
public class SuccintNode implements Node<Integer, Integer> {

    protected SuccintGraph graph;
    protected int index;
    protected Integer label;

    /**
     * Constructor
     * 
     * @param graph
     *            the source graph
     * @param index
     *            the index of the node
     * @param label
     *            the label of the node
     */
    SuccintNode(SuccintGraph graph, int index, Integer label) {
        this.graph = graph;
        this.index = index;
        this.label = label;
    }

    @Override
    public int getIndex() {
        return index;
    }

    @Override
    public void setIndex(int index) {
        this.index = index;
    }

    @Override
    public Integer getLabel() {
        return label;
    }

    @Override
    public void setLabel(Integer label) {
        throw new UnsupportedOperationException("SuccintGraph is unmodifyable");
    }

    @Override
    public List<? extends Edge<Integer, Integer>> getEdges() {
        return graph.edges(index);
    }

    @Override
    public int getDegree() {
        return graph.getNodeDegree(index);
    }

    @Override
    public void addEdge(Edge<Integer, Integer> e) {
        throw new UnsupportedOperationException("SuccintGraph is unmodifyable");
    }

    @Override
    public boolean removeEdge(Edge<Integer, Integer> e) {
        throw new UnsupportedOperationException("SuccintGraph is unmodifyable");
    }

    /**
     * @return the associated {@link SuccintGraph}
     */
    protected SuccintGraph getGraph() {
        return graph;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((graph == null) ? 0 : graph.hashCode());
        result = prime * result + index;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SuccintNode other = (SuccintNode) obj;
        if (graph == null) {
            if (other.graph != null)
                return false;
        } else if (!graph.equals(other.graph))
            return false;
        if (index != other.index)
            return false;
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(getIndex());
        sb.append(",");
        sb.append(getLabel());
        sb.append(") ");
        return sb.toString();
    }
    
}
