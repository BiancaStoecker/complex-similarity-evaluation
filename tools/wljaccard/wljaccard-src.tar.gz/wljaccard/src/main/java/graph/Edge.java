package graph;

/**
 * The edge of a {@link Graph}
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public interface Edge<NL, EL> {

    /**
     * Get the label
     * 
     * @return the label
     */
    public EL getLabel();

    /**
     * Set the label
     * 
     * @param o
     *            the label
     */
    public void setLabel(EL o);

    /**
     * @return the first {@link Node} incident to this edge
     */
    public Node<NL, EL> getFirstNode();

    /**
     * @return the second {@link Node} incident to this edge
     */
    public Node<NL, EL> getSecondNode();

    /**
     * Get the opposite {@link Node} incident to this edge, i.e. the fist node
     * if v is the second and vice versa.
     * 
     * @param v
     *            a {@link Node} incident to this edge
     * @return the opposite {@link Node}
     */
    public Node<NL, EL> getOppositeNode(Node<NL, EL> v);

}
