package graph;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Default implementation of the {@link Node} interface.
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public class DefaultNode<NL, EL> implements Node<NL, EL>,Serializable {
	
    private static final long serialVersionUID = 1L;
    private int index;
	protected NL label;
	private ArrayList<DefaultEdge<NL, EL>> edges;

    /**
     * Constructor
     * 
     * Attention: Only call this from the {@link Graph}
     * 
     * @param label
     *            the label
     * @param index
     *            the index in the {@link Graph}
     */
	protected DefaultNode(NL label, int index) {
		this.label = label;
		this.index = index;
		edges = new ArrayList<>();
	}

    @Override
	public List<DefaultEdge<NL, EL>> getEdges() {
		return edges;
	}
	
    @Override
	public int getDegree() {
		return edges.size();
	}

    @Override
	public int getIndex() {
		return index;
	}

    @Override
	public NL getLabel() {
		return label;
	}
	
    @Override
	public void setLabel(NL label) {
		this.label = label;
	}
	
    @Override
	public void addEdge(Edge<NL, EL> e) {
        assert e instanceof DefaultEdge;
        
		edges.add((DefaultEdge<NL, EL>)e);
	}
	
    @Override
	public boolean removeEdge(Edge<NL, EL> e) {
        assert e instanceof DefaultEdge;
        
		return edges.remove(e);
	}

    @Override
    public void setIndex(int index) {
        this.index = index;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(getIndex());
        sb.append(",");
        sb.append(getLabel());
        sb.append(") ");
        return sb.toString();
    }

}
