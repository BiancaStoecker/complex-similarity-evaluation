package graph;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * Simple Wrapper around an Edge, which reduces an edge to the labeling of the
 * edge itself and its end points. Reverse labeled edges are considered equal.
 * 
 * @author Till Schäfer
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public class LabelEdge<NL, EL> {
    private NL firstLabel;
    private NL secondLabel;
    private EL edgeLabel;

    /**
     * Constructor
     * 
     * @param edge
     *            the real edge that is wrapped by this instance
     */
    public LabelEdge(Edge<NL, EL> edge) {
        firstLabel = edge.getFirstNode().getLabel();
        secondLabel = edge.getSecondNode().getLabel();
        edgeLabel = edge.getLabel();
    }

    /**
     * Constructor
     * 
     * @param firstLabel
     *            the fist node label
     * @param secondLabel
     *            the second node label
     * @param edgeLabel
     *            the edge label
     */
    public LabelEdge(NL firstLabel, NL secondLabel, EL edgeLabel) {
        this.firstLabel = firstLabel;
        this.secondLabel = secondLabel;
        this.edgeLabel = edgeLabel;
    }

    /**
     * @return the label of the first {@link Node}
     */
    public NL getFirstNodeLabel() {
        return firstLabel;
    }

    /**
     * @return the label of the second {@link Node}
     */
    public NL getSecondNodeLabel() {
        return secondLabel;
    }

    /**
     * @return the label of the edge
     */
    public EL getEdgeLabel() {
        return edgeLabel;
    }

    /**
     * Is equal if the edges have the same end point labels and the same edge
     * label. Note that (A,B) is equal to its reverse edge (B,A)
     */
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!(o instanceof LabelEdge)) {
            return false;
        }
        @SuppressWarnings("rawtypes")
        LabelEdge other = (LabelEdge) o;

        boolean normalEqual = new EqualsBuilder().append(getFirstNodeLabel(), other.getFirstNodeLabel())
                .append(getSecondNodeLabel(), other.getSecondNodeLabel()).append(getEdgeLabel(), other.getEdgeLabel())
                .isEquals();
        boolean reverseEqual = new EqualsBuilder().append(getFirstNodeLabel(), other.getSecondNodeLabel())
                .append(getSecondNodeLabel(), other.getFirstNodeLabel()).append(getEdgeLabel(), other.getEdgeLabel())
                .isEquals();

        return normalEqual || reverseEqual;
    }

    /**
     * Hash code based on the first and second node label and edge label. Note
     * that the edge (A,B) has the same hash code as its reverse edge (B,A).
     */
    public int hashCode() {
        if (getFirstNodeLabel().hashCode() > getSecondNodeLabel().hashCode()) {
            return new HashCodeBuilder().append(getFirstNodeLabel()).append(getSecondNodeLabel()).hashCode();
        } else {
            return new HashCodeBuilder().append(getSecondNodeLabel()).append(getFirstNodeLabel()).hashCode();
        }

    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("(");
        builder.append("(");
        builder.append(getFirstNodeLabel());
        builder.append(",");
        builder.append(getSecondNodeLabel());
        builder.append(",");
        builder.append(")");
        builder.append(getEdgeLabel());
        builder.append(")");
        return builder.toString();
    }
}
