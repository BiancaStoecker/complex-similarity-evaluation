package graph;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class GraphUtil {

    /**
     * Returns the adjacency matrix of a graph.
     * 
     * @param g
     *            the graph
     * @return the adjacency matrix
     */
    public static <NL, EL> int[][] createAdjacencyMatrix(Graph<NL, EL> g) {
        int n = g.getNodeCount();
        int[][] res = new int[n][n];

        for (Edge<NL, EL> e : g.edges()) {
            int iU = e.getFirstNode().getIndex();
            int iV = e.getSecondNode().getIndex();
            res[iU][iV] = 1;
            res[iV][iU] = 1;
        }

        return res;
    }

    /**
     * Returns the line graph L(g) of g. The nodes of the line graph are labeled
     * with the corresponding edges of g. An edge (u,v) of the line graph is
     * labeled with the node of g that is incident to the two edges in g
     * represented by the two nodes u and v.
     * 
     * @param g
     *            the graph
     * @return the line graph
     */
    public static <NL, EL> DefaultGraph<Edge<NL, EL>, Node<NL, EL>> createLineGraph(Graph<NL, EL> g) {

        HashMap<Edge<NL, EL>, DefaultNode<Edge<NL, EL>, Node<NL, EL>>> edgeToNode = new HashMap<Edge<NL, EL>, DefaultNode<Edge<NL, EL>, Node<NL, EL>>>();

        DefaultGraph<Edge<NL, EL>, Node<NL, EL>> lg = new DefaultGraph<Edge<NL, EL>, Node<NL, EL>>();
        for (Edge<NL, EL> e : g.edges()) {
            DefaultNode<Edge<NL, EL>, Node<NL, EL>> n = lg.addNode(e);
            edgeToNode.put(e, n);
        }
        for (Node<NL, EL> v : g.nodes()) {
            for (Edge<NL, EL> e : v.getEdges()) {
                for (Edge<NL, EL> f : v.getEdges()) {
                    if (e.getOppositeNode(v).getIndex() < f.getOppositeNode(v).getIndex()) {
                        lg.addEdge(edgeToNode.get(e), edgeToNode.get(f), v);
                    }
                }
            }
        }
        return lg;
    }

    /**
     * Checks if a graph is connected.
     * 
     * @param g
     *            a graph
     * @return true iff g is connected
     */
    public static <NL, EL> boolean isConnected(Graph<NL, EL> g) {
        if (g.getEdgeCount() < g.getNodeCount() - 1)
            return false;

        if (g.getNodeCount() == 0)
            return true;

        int[] found = new int[g.getNodeCount()];
        doDFS(g.getNode(0), found, 1);
        for (int i = 0; i < g.getNodeCount(); i++) {
            if (found[i] != 1)
                return false;
        }

        return true;
    }

    private static <NL, EL> void doDFS(Node<NL, EL> v, int[] found, int ccId) {
        found[v.getIndex()] = ccId;
        for (Edge<NL, EL> e : v.getEdges()) {
            Node<NL, EL> w = e.getOppositeNode(v);
            if (found[w.getIndex()] == 0) {
                doDFS(w, found, ccId);
            }
        }
    }

    /**
     * Tests if a given edge is a bridge.
     * 
     * @param g
     *            a graph
     * @param e
     *            an edge of g
     * @return true iff e is a bridge of g
     */
    public static <NL, EL> boolean isBridge(Graph<NL, EL> g, Edge<NL, EL> e) {
        Node<NL, EL> s = e.getFirstNode();
        Node<NL, EL> t = e.getSecondNode();
        int[] found = new int[g.getNodeCount()];
        found[s.getIndex()] = 1;
        for (Edge<NL, EL> e2 : s.getEdges()) {
            if (e2 == e)
                continue;
            doDFS(e2.getOppositeNode(s), found, 1);
        }
        return found[t.getIndex()] == 0;
    }

    /**
     * Checks if a graph has parallel edges.
     * 
     * @param g
     * @return true iff g has parallel edges
     */
    public static <NL, EL> boolean hasParallelEdges(Graph<NL, EL> g) {
        // TODO implement more efficient parallel edge checking
        HashSet<Node<NL, EL>> adjNodes = new HashSet<Node<NL, EL>>();
        for (Node<NL, EL> u : g.nodes()) {
            for (Edge<NL, EL> e : u.getEdges()) {
                Node<NL, EL> v = e.getOppositeNode(u);
                if (adjNodes.contains(v)) {
                    return true;
                } else {
                    adjNodes.add(v);
                }
            }
            adjNodes.clear();
        }
        return false;
    }

    /**
     * Checks if a graph has at least one self-loop.
     * 
     * @param g
     * @return true iff g has at least one self-loop
     */
    public static <NL, EL> boolean hasSelfLoops(Graph<NL, EL> g) {
        for (Edge<NL, EL> e : g.edges()) {
            if (e.getFirstNode() == e.getSecondNode()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if a graph is simple, i.e. contains no self-loops nor parallel
     * edges.
     * 
     * @param g
     * @return true iff g is simple
     */
    public static <NL, EL> boolean isSimple(Graph<NL, EL> g) {
        return !hasSelfLoops(g) && !hasParallelEdges(g);
    }

    /**
     * Returns the degree distribution of the specified graph, i.e. an array d
     * where d[k]=j means, that the graph contains j vertices with degree k.
     * 
     * @return the degree distribution
     */
    public static <NL, EL> int[] getDegreeDistribution(Graph<NL, EL> g) {
        int[] d = new int[getMaximumDegree(g) + 1];
        for (Node<NL, EL> n : g.nodes()) {
            d[n.getDegree()]++;
        }
        return d;
    }

    /**
     * Returns the maximum vertex degree.
     * 
     * @param g
     * @return the maximum degree
     */
    public static <NL, EL> int getMaximumDegree(Graph<NL, EL> g) {
        int maxDegree = 0;
        for (Node<NL, EL> n : g.nodes()) {
            int degree = n.getDegree();
            if (degree > maxDegree) {
                maxDegree = degree;
            }
        }
        return maxDegree;
    }

    public static <NL, EL> Map<Object, Integer> getLabelDistribution(Graph<NL, EL> g) {
        Map<Object, Integer> dist = new HashMap<Object, Integer>();

        for (Node<NL, EL> n : g.nodes()) {
            Integer c = dist.get(n.getLabel());
            if (c == null)
                c = 0;
            c++;
            dist.put(n.getLabel(), c);
        }

        for (Edge<NL, EL> e : g.edges()) {
            Integer c = dist.get(e.getLabel());
            if (c == null)
                c = 0;
            c++;
            dist.put(e.getLabel(), c);
        }

        return dist;
    }

    public static <NL, EL> Graph<NL, EL>[] getConnectedComponents(Graph<NL, EL> g) {
        int[] found = new int[g.getNodeCount()];
        int ccId = 1;
        for (int i = 0; i < g.getNodeCount(); i++) {
            if (found[i] == 0) {
                doDFS(g.getNode(i), found, ccId);
                ccId++;
            }
        }

        DefaultGraph<NL, EL>[] ccs = new DefaultGraph[ccId - 1];
        for (int i = 0; i < ccId - 1; i++) {
            ccs[i] = new DefaultGraph<NL, EL>();
        }

        int[] newId = new int[g.getNodeCount()];
        for (Node<NL, EL> n : g.nodes()) {
            int nccId = found[n.getIndex()];
            Node<NL, EL> newNode = ccs[nccId - 1].addNode(n.getLabel());
            newId[n.getIndex()] = newNode.getIndex();
        }
        for (Edge<NL, EL> e : g.edges()) {
            int eccId = found[e.getFirstNode().getIndex()];
            if (eccId != found[e.getSecondNode().getIndex()]) {
                throw new RuntimeException("Error finding connected components.");
            }
            DefaultGraph<NL, EL> cc = ccs[eccId - 1];
            DefaultNode<NL, EL> u = cc.getNode(newId[e.getFirstNode().getIndex()]);
            DefaultNode<NL, EL> v = cc.getNode(newId[e.getSecondNode().getIndex()]);
            cc.addEdge(u, v, e.getLabel());
        }

        return ccs;
    }

    public static<NL, EL> Graph<NL, EL> getMaximumConnectedComponent(Graph<NL, EL> g) {
        Graph<NL, EL>[] ccs = getConnectedComponents(g);
        int maxEdgeCount = Integer.MIN_VALUE;
        Graph<NL, EL> maxEdgeGraph = null;
        for (Graph<NL, EL> cc : ccs) {
            if (cc.getEdgeCount() > maxEdgeCount) {
                maxEdgeCount = cc.getEdgeCount();
                maxEdgeGraph = cc;
            }
        }
        return maxEdgeGraph;
    }

}
