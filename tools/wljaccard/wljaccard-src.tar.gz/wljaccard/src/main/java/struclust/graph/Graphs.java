package struclust.graph;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;

import graph.DefaultGraph;
import graph.Edge;
import graph.Graph;
import graph.GraphFactory;
import graph.LabelEdge;
import graph.Node;
import match.MatcherFast;
import match.pattern.SearchPattern;

/**
 * Convenience methods for Graphs
 * 
 * @author Till Schäfer
 */
public class Graphs {
    private static final Logger logger = LoggerFactory.getLogger(Graphs.class);

    /**
     * tests two graphs on isomorphism
     * 
     * @param first
     *            the first graph
     * @param second
     *            the second graph
     * @return whether the two graphs are isomorphic
     */
    public static <NL, EL, G extends Graph<NL, EL>> boolean areIsomorphic(G first, G second) {
        return first.getNodeCount() == second.getNodeCount() && first.getEdgeCount() == second.getEdgeCount()
                && new MatcherFast<>(first, second).match();
    }

    /**
     * tests two graphs on isomorphism
     * 
     * @param sp
     *            the {@link SearchPattern} for the first graph
     * @param g
     *            the second graph
     * @return whether the two graphs are isomorphic
     */
    public static <NL, EL> boolean areIsomorphic(SearchPattern<NL, EL> sp, Graph<NL, EL> g) {
        return sp.getGraph().getNodeCount() == g.getNodeCount() && sp.getGraph().getEdgeCount() == g.getEdgeCount()
                && new MatcherFast<>(sp, g).match();
    }

    /**
     * Filters out isomorphic graphs.
     * 
     * Precondition: all graphs must be distinct objects
     * 
     * @param graphs
     *            the list to filter.
     * @throws ExecutionException
     * @throws InterruptedException
     */
    public static <NL, EL, G extends Graph<NL, EL>> void distinctGraphsParallel(ArrayList<G> graphs)
            throws InterruptedException, ExecutionException {
        logger.debug("Number of all graphs: {}", graphs.size());

        if (graphs.isEmpty()) {
            return;
        }

        for (int i = 0; i < graphs.size(); i++) {
            SearchPattern<NL, EL> sp = new SearchPattern<>(graphs.get(i), false);

            List<Integer> indices = IntStream.range(i + 1, graphs.size() - 1).parallel()
                    .filter(j -> areIsomorphic(sp, graphs.get(j))).boxed().collect(Collectors.toList());

            for (Integer index : Lists.reverse(indices)) {
                graphs.remove((int) index);
            }
        }

        logger.debug("Number of distinct graphs: {}", graphs.size());
    }

    /**
     * Filters out isomorphic graphs.
     * 
     * Precondition: all graphs must be distinct objects
     * 
     * @param graphs
     *            the list to filter.
     */
    public static <NL, EL, G extends Graph<NL, EL>> void distinctGraphs(List<G> graphs) {
        assert assertDistinctObjects(graphs);
        logger.debug("Number of all graphs: {}", graphs.size());

        if (graphs.isEmpty()) {
            return;
        }

        for (Iterator<? extends Graph<NL, EL>> it1 = graphs.iterator(); it1.hasNext();) {
            Graph<NL, EL> g1 = it1.next();

            SearchPattern<NL, EL> sp = new SearchPattern<>(g1, false);

            Iterator<? extends Graph<NL, EL>> it2 = graphs.iterator();
            Graph<NL, EL> g2 = it2.next();
            while (g1 != g2) {
                if (areIsomorphic(sp, g2)) {
                    it1.remove();
                    break;
                }
                g2 = it2.next();
            }
        }

        logger.debug("Number of distinct graphs: {}", graphs.size());
    }

    /**
     * Group by isomorphism.
     * 
     * @param graphs
     *            the list to filter.
     * @return a grouped list of graphs
     */
    public static <NL, EL, G extends Graph<NL, EL>> List<List<G>> groupByIsomorphism(List<G> graphs) {
        logger.debug("Number of all graphs: {}", graphs.size());
        List<List<G>> retVal = new ArrayList<>();
        ArrayDeque<G> copy = new ArrayDeque<>(graphs);

        while (!copy.isEmpty()) {
            ArrayList<G> group = new ArrayList<>();
            G reference = copy.poll();
            group.add(reference);
            SearchPattern<NL, EL> refSp = new SearchPattern<>(reference, false);
            for (Iterator<G> it = copy.iterator(); it.hasNext();) {
                G compare = it.next();
                if (areIsomorphic(refSp, compare)) {
                    group.add(compare);
                    it.remove();
                }
            }
            retVal.add(group);
        }

        logger.debug("Number of groups: {}", retVal.size());
        assert retVal.stream().flatMap(x -> x.stream()).count() == graphs.size();
        return retVal;
    }

    /**
     * Group by isomorphism.
     * 
     * <br><strong>Precondition:</strong> all graphs must be distinct objects
     * 
     * <br><strong>Note:</strong> The ordering of the graphs is not preserved!
     * 
     * @param graphs
     *            the list to filter.
     * @return a grouped list of graphs
     */
    public static <NL, EL, G extends Graph<NL, EL>> List<List<G>> groupByIsomorphismParallel(List<G> graphs) {
        logger.debug("Number of all graphs: {}", graphs.size());
        List<List<G>> retVal = new ArrayList<>();
        LinkedHashSet<G> copy = new LinkedHashSet<>(graphs);

        if (graphs.isEmpty()) {
            return retVal;
        }

        while (!copy.isEmpty()) {
            G reference = copy.iterator().next();
            SearchPattern<NL, EL> refSp = new SearchPattern<>(reference, false);
            ArrayList<G> group = copy.parallelStream().filter(g -> areIsomorphic(refSp, g))
                    .collect(Collectors.toCollection(ArrayList::new));
            copy.removeAll(group);
            retVal.add(group);
        }

        logger.debug("Number of groups: {}", retVal.size());
        assert retVal.stream().flatMap(x -> x.stream()).count() == graphs.size();
        return retVal;
    }

    /**
     * Filters out graphs that are subgraphisomorphisms of another graph.
     * 
     * Precondition: all graphs must be distinct objects
     * 
     * @param graphs
     *            all graphs
     */
    public static <NL, EL, G extends Graph<NL, EL>> void filterSubgraphs(List<GraphContainer<NL, EL, G>> graphs) {
        assert assertDistinctObjects(graphs);
        logger.debug("Number of all graphs: {}", graphs.size());

        if (graphs.isEmpty()) {
            return;
        }

        for (Iterator<GraphContainer<NL, EL, G>> it1 = graphs.iterator(); it1.hasNext();) {
            GraphContainer<NL, EL, G> gc1 = it1.next();

            /*
             * it is important to use the graph instead of the graph container
             * for SearchPattern, to ensure corrects graph type detection.
             */
            SearchPattern<NL, EL> sp1 = new SearchPattern<>(gc1.getGraph(), false);

            Iterator<GraphContainer<NL, EL, G>> it2 = graphs.iterator();
            GraphContainer<NL, EL, G> gc2;
            for (gc2 = it2.next(); it2.hasNext(); gc2 = it2.next()) {
                // gc1 is subgraph of gc2 -> remove gc1
                if (gc1 != gc2 && gc1.getNodeCount() <= gc2.getNodeCount() && gc1.getEdgeCount() <= gc2.getEdgeCount()
                        && new MatcherFast<>(sp1, gc2).match()) {
                    it1.remove();
                    break;
                }
            }
        }

        logger.debug("Number of distinct graphs: {}", graphs.size());
    }

    /**
     * @param graph
     *            the graph to test
     * @return if the graph contains no self loops (i.e. edged adjacent to a
     *         single node)
     */
    public static <NL, EL, G extends Graph<NL, EL>> boolean isSelfLoopFree(G graph) {
        for (Node<NL, EL> n : graph.nodes()) {
            for (Edge<NL, EL> e : n.getEdges()) {
                if (e.getFirstNode().getIndex() == e.getSecondNode().getIndex()) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Calculate an induced subgraph by a given list of node indices.
     * 
     * @param g
     *            the graph to compute the subgraph of
     * @param nodeIndices
     *            the node indices
     * @param gf
     *            a graph factory to create a new node
     * @return the subgraph
     */
    public static <NL, EL, G extends Graph<NL, EL>> G subgraph(G g, Collection<Integer> nodeIndices,
            GraphFactory<NL, EL, G> gf) {
        G subgraph = gf.clone(g);

        ArrayList<Node<NL, EL>> keepNodes = new ArrayList<>(nodeIndices.size());
        for (Integer i : nodeIndices) {
            keepNodes.add(subgraph.getNode(i));
        }

        ArrayList<Node<NL, EL>> removeNodes = new ArrayList<>(subgraph.nodes());
        removeNodes.removeAll(keepNodes);

        for (Node<NL, EL> node : removeNodes) {
            subgraph.removeNode(node);
        }

        return subgraph;
    }

    /**
     * construct a line graph. I.e.: create one node per edge with the combined
     * label of the edge and its end points
     * 
     * @param g
     *            the graph to transform
     * @return the line graph
     */
    public static <NL, EL, G extends Graph<NL, EL>> DefaultGraph<LabelEdge<NL, EL>, NL> lineGraph(G g) {
        DefaultGraph<LabelEdge<NL, EL>, NL> retVal = new DefaultGraph<>();

        HashMap<Edge<NL, EL>, Node<LabelEdge<NL, EL>, NL>> e2n = new HashMap<>();
        for (Edge<NL, EL> e : g.edges()) {
            Node<LabelEdge<NL, EL>, NL> lineNode = retVal
                    .addNode(new LabelEdge<>(e.getFirstNode().getLabel(), e.getSecondNode().getLabel(), e.getLabel()));
            e2n.put(e, lineNode);
        }

        for (Node<NL, EL> n : g.nodes()) {
            for (Edge<NL, EL> e1 : n.getEdges()) {
                for (Edge<NL, EL> e2 : n.getEdges()) {
                    if (e1 == e2) {
                        break;
                    }
                    retVal.addEdge(e2n.get(e1), e2n.get(e2), n.getLabel());
                }
            }
        }

        return retVal;
    }

    /**
     * Maps each edge label to a unique integer value. The integer values are
     * continuous, starting with startVal.
     * 
     * @param graphs
     *            graphs from which the labels are collected
     * @param startVal
     *            the starting value
     * @return the edge label to integer map
     */
    public static <NL, EL, G extends Graph<NL, EL>> HashMap<EL, Integer> getIntegerEdgeLabelMap(Collection<G> graphs,
            int startVal) {
        HashSet<EL> edgeLabels = new HashSet<>();
        for (G g : graphs) {
            for (Edge<NL, EL> e : g.edges()) {
                edgeLabels.add(e.getLabel());
            }
        }

        HashMap<EL, Integer> elMap = new HashMap<>(edgeLabels.size());
        for (EL el : edgeLabels) {
            elMap.put(el, startVal);
            startVal++;
        }
        return elMap;
    }

    /**
     * Returns the label sequence of a path.
     * 
     * @param graph
     *            the {@link Graph} to calculate the label sequence for. The
     *            {@link Graph} must be a single connected path.
     * @param includeEdgeLabels
     *            iff true edge labels are included in the label sequence
     * @return the label sequence
     */
    public static <NL, EL, G extends Graph<NL, EL>> String getPathLabelSequence(G graph, boolean includeEdgeLabels) {
        if (graph.getNodeCount() == 1) {
            return graph.getNode(0).getLabel().toString();
        }

        if (!isConnected(graph)) {
            throw new IllegalArgumentException("graph is not connected");
        }

        StringBuilder lSequence = new StringBuilder();

        Node<NL, EL> startNode = null;
        for (Node<NL, EL> node : graph.nodes()) {
            if (node.getDegree() == 1) {
                startNode = node;
                break;
            }
        }
        if (startNode == null) {
            throw new IllegalArgumentException("the graph is no path");
        }

        Node<NL, EL> node = startNode;
        Edge<NL, EL> edge = null;
        int visitedNodes = 0;
        do {
            lSequence.append(node.getLabel());
            visitedNodes++;
            edge = node.getEdges().get(0) == edge ? node.getEdges().get(1) : node.getEdges().get(0);
            if (includeEdgeLabels) {
                lSequence.append(edge.getLabel());
            }

            node = edge.getOppositeNode(node);
        } while (node.getDegree() == 2);
        lSequence.append(node.getLabel());
        visitedNodes++;

        if (visitedNodes != graph.getNodeCount()) {
            throw new IllegalArgumentException("the graph is no path");
        }

        return lSequence.toString();
    }

    /**
     * creates a {@link HashMap} that maps each graph of graphs1 to a graph in
     * graphs2 based on graph isomorphis. The returned map is an injection, i.e.
     * all graphs will be mapped or an exception is thrown. If there are more
     * than a single possible mapping (i.e. there exist isomorphic graphs in
     * graphs1), the mapping is constructed in a undefined order.
     * 
     * @param graphs1
     *            a {@link Collection} of {@link Graph}s
     * @param graphs2
     *            a {@link Collection} of {@link Graph}s
     * @return an injection from graphs1 to graphs2
     */
    public static <NL, EL, G extends Graph<NL, EL>> HashMap<G, G> getIsomorphicGraphMapping(Collection<G> graphs1,
            Collection<G> graphs2) {
        HashMap<G, G> retVal = new HashMap<>(graphs1.size());
        ArrayList<G> graph2Copy = new ArrayList<>(graphs2);

        // PARALLEL stream: isomorphism mapping
        for (G g : graphs1) {
            Optional<G> matched = graph2Copy.stream().parallel()
                    .filter(gCompare -> (g.getNodeCount() == gCompare.getNodeCount()
                            && g.getEdgeCount() == gCompare.getEdgeCount() && new MatcherFast<>(g, gCompare).match()))
                    .findAny();
            if (matched.isPresent()) {
                G match = matched.get();
                retVal.put(g, match);
                graph2Copy.remove(match);
            } else {
                throw new IllegalStateException(
                        "injective mapping inpossible: no isomorphic graph found for " + g.toString());
            }
        }

        return retVal;
    }

    /**
     * creates a {@link HashMap} that maps each graph of graphs1 to a graph in
     * graphs2 based on graph isomorphis. The returned map in not necessarily
     * and injection. If there are more than a single possible mapping (i.e.
     * there exist isomorphic graphs in graphs1), the mapping is constructed in
     * a undefined order.
     * 
     * @param graphs1
     *            a {@link Collection} of {@link Graph}s
     * @param graphs2
     *            a {@link Collection} of {@link Graph}s
     * @return an injection from graphs1 to graphs2
     */
    public static <NL, EL, G extends Graph<NL, EL>> HashMap<G, G> getIsomorphicMultiGraphMapping(Collection<G> graphs1,
            Collection<G> graphs2) {
        HashMap<G, G> retVal = new HashMap<>(graphs1.size());
        ArrayList<G> graph2Copy = new ArrayList<>(graphs2);

        // PARALLEL stream: isomorphism mapping
        for (G g : graphs1) {
            Optional<G> matched = graph2Copy.stream().parallel()
                    .filter(gCompare -> (g.getNodeCount() == gCompare.getNodeCount()
                            && g.getEdgeCount() == gCompare.getEdgeCount() && new MatcherFast<>(g, gCompare).match()))
                    .findAny();
            if (matched.isPresent()) {
                G match = matched.get();
                retVal.put(g, match);
            } else {
                throw new IllegalStateException("no isomorphic graph found for " + g.toString());
            }
        }

        return retVal;
    }

    private static <NL, EL, G extends Graph<NL, EL>> boolean assertDistinctObjects(
            List<? extends Graph<NL, EL>> graphs) {
        HashSet<Graph<NL, EL>> set = new HashSet<>(graphs);
        return set.size() == graphs.size();
    }

    /**
     * @param graph
     *            the graph to check the connectivity for
     * @return whether the graph is connected. Throws an
     *         {@link IllegalStateException} if {@link Graph#size} is 0.
     */
    public static boolean isConnected(Graph<?, ?> graph) {
        Preconditions.checkState(graph.getNodeCount() != 0, "Graph empty");

        boolean[] found = new boolean[graph.getNodeCount()];

        connected(graph, graph.getNode(0), found);

        for (boolean b : found) {
            if (!b) {
                return false;
            }
        }

        return true;
    }

    /**
     * DFS for connectivity check {@link DefaultGraph#isConnected()}
     * 
     * @param graph
     *            the graph to check the connectivity for
     * @param node
     *            the current node
     * @param found
     *            array containing the found indices of the nodes
     */
    private static void connected(Graph<?, ?> graph, Node<?, ?> node, boolean[] found) {
        found[node.getIndex()] = true;
        for (Edge<?, ?> e : node.getEdges()) {
            Node<?, ?> firstNode = e.getFirstNode();
            Node<?, ?> secondNode = e.getSecondNode();
            Node<?, ?> oppositeNode = firstNode == node ? secondNode : firstNode;
            if (!found[oppositeNode.getIndex()]) {
                connected(graph, oppositeNode, found);
            }
        }
    }
}
