package struclust.comparison;

/**
 * Same as {@link Distance}, but for two Objects of the same type.
 * 
 * @author Till Schäfer
 *
 * @param <T>
 *            the second object type
 */
public interface SameTypeDistance<T> extends Distance<T, T> {

}
