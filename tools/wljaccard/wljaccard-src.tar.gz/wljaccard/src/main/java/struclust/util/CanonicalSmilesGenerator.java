/*
 * Scaffold Hunter
 * Copyright (C) 2006-2008 PG504
 * Copyright (C) 2010-2011 PG552
 * See README.txt in the root directory of the Scaffold Hunter source tree
 * for details.
 *
 * Scaffold Hunter is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Scaffold Hunter is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package struclust.util;

import org.openscience.cdk.aromaticity.Aromaticity;
import org.openscience.cdk.aromaticity.ElectronDonation;
import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.graph.Cycles;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.smiles.SmilesGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Wrapper class for generating canonical SMILES strings. Should be used instead
 * of the inner CDK smiles generator, to ensure the same configuration is used
 * to generate the smiles strings.
 * 
 * @author Philipp Lewe
 * @author Sven Schrinner
 *
 */
public class CanonicalSmilesGenerator {
    private static final Logger logger = LoggerFactory.getLogger(CanonicalSmilesGenerator.class);
    private static SmilesGenerator smigen = SmilesGenerator.unique().aromatic();
    private static SmilesGenerator smigenChiral = SmilesGenerator.absolute().aromatic();
    private static SmilesGenerator smigenNonCanonical = SmilesGenerator.generic().aromatic();
    private static SmilesGenerator smigenChiralNonCanonical = SmilesGenerator.isomeric().aromatic();

    /**
     * An internal compatibility version for smiles generation. Should be
     * increased whenever the SMILES become incompatible with previous releases.
     * Current overview:
     * 
     * 0 - Release 2.5.1 and older, using CDK 1.4.x 1 - Release 2.6.0 and newer,
     * using CDK 1.5.13 (Snapshot)
     * 
     */
    private static final int SMILESVERSION = 1;

    /**
     * @param mol
     *            the molecule of type <code>IAtomContainer</code>
     * @param chiral
     *            whether the smiles should be chiral or not
     * @return the canonical smiles string
     * @throws Exception 
     */
    public static String createSMILES(IAtomContainer mol, boolean chiral) throws Exception {
        return createSMILES(mol, true, chiral);
    }

    /**
     * @param mol
     *            the molecule of type <code>IAtomContainer</code>
     * @param canonical
     *            whether the smiles should be canonical or not
     * @param chiral
     *            whether the smiles should be chiral or not
     * @return the canonical smiles string
     * @throws Exception 
     */
    public static String createSMILES(IAtomContainer mol, boolean canonical, boolean chiral) throws Exception {
        Aromaticity aromaticity = new Aromaticity(ElectronDonation.cdk(), Cycles.cdkAromaticSet());
        try {
            aromaticity.apply(mol);
        } catch (CDKException e1) {
            logger.error("applying aromaticity faile", e1);
            throw e1;
        }
        try {
            if (canonical) {
                if (chiral)
                    return smigenChiral.create(mol);
                else
                    return smigen.create(mol);
            } else {
                if (chiral)
                    return smigenChiralNonCanonical.create(mol);
                else
                    return smigenNonCanonical.create(mol);
            }
        } catch (Exception e) {
            logger.error("smiles generation failed", e);
            throw e;
        }
    }

    /**
     * Returns the current SMILES version to detect possible incompatibilities.
     * This version number is increased whenever the SMILES may have become
     * incompatible with earlier version. It only indicates an abstract number
     * for internal usage. So far the values are:
     * 
     * 0 - Release 2.5.1 and older, using CDK 1.4.x 1 - Release 2.6.0 and newer,
     * using CDK 1.5.13 (Snapshot)
     * 
     * @return the latest SMILES version for internal compatibility checks
     */
    public static int getSMILESVersion() {
        return SMILESVERSION;
    }
}
