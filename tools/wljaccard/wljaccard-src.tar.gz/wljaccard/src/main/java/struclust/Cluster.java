package struclust;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Objects;

import graph.Graph;
import graph.GraphSize;
import struclust.graph.GraphContainer;

/**
 * A Cluster represents a {@link Collection} of {@link Graph}s. A Cluster also
 * has a set of representative {@link Graph}s.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class Cluster<NL, EL, G extends Graph<NL, EL>> implements List<GraphContainer<NL, EL, G>> {

    private ArrayList<GraphContainer<NL, EL, G>> elements;
    private ArrayList<GraphContainer<NL, EL, G>> representatives;
    private int id;
    private long totalElementsSize;
    private GraphSize gSize;

    /**
     * Constructor
     * 
     * @param elements
     *            the elements
     * @param representatives
     *            the representatives
     * @param id
     *            a identifier for this cluster that may be used for distributed
     *            environments or if a cluster is copied
     * @param gSize
     *            way the graph size is counted
     */
    public Cluster(Collection<GraphContainer<NL, EL, G>> elements,
            Collection<GraphContainer<NL, EL, G>> representatives, int id, GraphSize gSize) {
        this.elements = new ArrayList<>(elements);
        this.representatives = representatives == null ? new ArrayList<>() : new ArrayList<>(representatives);
        this.id = id;
        this.gSize = gSize;

        totalElementsSize = elements.stream().mapToInt(x -> x.size(gSize)).sum();
    }

    /**
     * @return returns the representatives of this Cluster
     */
    public ArrayList<GraphContainer<NL, EL, G>> getRepresentatives() {
        return representatives;
    }

    /**
     * @param representatives
     *            the representatives of this Cluster
     */
    public void setRepresentatives(ArrayList<GraphContainer<NL, EL, G>> representatives) {
        this.representatives = representatives;
    }

    /**
     * @return the identifier of this cluster
     */
    public int getId() {
        return id;
    }

    /**
     * @return the average size of the members or 0 if there are no elements in this
     *         cluster.
     */
    public double getAvgMemberSize() {
        assert elements.isEmpty() ? true
                : elements.stream().mapToInt(x -> x.size(gSize)).average().getAsDouble() == (double) totalElementsSize
                        / elements.size() : "avgClusterSize was " + (double) totalElementsSize / elements.size()
                                + ", but should be "
                                + elements.stream().mapToInt(x -> x.size(gSize)).average().getAsDouble();
        return elements.isEmpty() ? 0 : (double) totalElementsSize / elements.size();
    }

    /**
     * @return the average size of the representatives or 0 if there are no
     *         representatives in this cluster.
     */
    public double getAvgRepSize() {
        return representatives.isEmpty() ? 0
                : getRepresentatives().stream().mapToInt(y -> y.size(gSize)).average().getAsDouble();
    }

    /**
     * @return the relative average representatives size in relation to the average
     *         member size. Will return {@link Double#POSITIVE_INFINITY} if there
     *         are no members.
     */
    public double getRepToMemberSize() {
        return getAvgRepSize() / getAvgMemberSize();
    }

    /**
     * Returns the way the graph size is counted
     * 
     * @return the {@link GraphSize} counting
     */
    public GraphSize getGSize() {
        return gSize;
    }

    /**
     * Create an empty (no elements) copy of this cluster
     * 
     * @return the empty copy
     */
    public Cluster<NL, EL, G> emptyCopy() {
        return new Cluster<>(Collections.<GraphContainer<NL, EL, G>> emptyList(), representatives, id, gSize);
    }

    @Override
    public int size() {
        return elements.size();
    }

    @Override
    public boolean isEmpty() {
        return elements.isEmpty();
    }

    @Override
    public boolean contains(Object o) {
        return elements.contains(o);
    }

    @Override
    public ListIterator<GraphContainer<NL, EL, G>> iterator() {
        return new GraphIterator(elements.listIterator());
    }

    @Override
    public Object[] toArray() {
        return elements.toArray();
    }

    @Override
    public <T> T[] toArray(T[] a) {
        return elements.toArray(a);
    }

    @Override
    public boolean add(GraphContainer<NL, EL, G> e) {
        totalElementsSize += e.size(gSize);

        return elements.add(e);
    }

    @Override
    public boolean remove(Object o) {
        assert o instanceof GraphContainer;
        @SuppressWarnings({ "rawtypes" })
        GraphContainer g = (GraphContainer) o;
        totalElementsSize -= g.size(gSize);

        return elements.remove(o);
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return elements.containsAll(c);
    }

    @Override
    public boolean addAll(Collection<? extends GraphContainer<NL, EL, G>> c) {
        totalElementsSize += c.size() == 0 ? 0 : c.stream().mapToInt(x -> x.size(gSize)).sum();

        return elements.addAll(c);
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        Objects.requireNonNull(c);
        boolean modified = false;
        ListIterator<?> it = iterator();
        while (it.hasNext()) {
            if (c.contains(it.next())) {
                it.remove();
                modified = true;
            }
        }
        return modified;
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        Objects.requireNonNull(c);
        boolean modified = false;
        Iterator<?> it = iterator();
        while (it.hasNext()) {
            if (!c.contains(it.next())) {
                it.remove();
                modified = true;
            }
        }
        return modified;
    }

    @Override
    public void clear() {
        elements.clear();
        totalElementsSize = 0;
    }

    @Override
    public boolean addAll(int index, Collection<? extends GraphContainer<NL, EL, G>> c) {
        totalElementsSize += c.size() == 0 ? 0 : c.stream().mapToInt(x -> x.size(gSize)).sum();

        return elements.addAll(index, c);
    }

    @Override
    public GraphContainer<NL, EL, G> get(int index) {
        return elements.get(index);
    }

    @Override
    public GraphContainer<NL, EL, G> set(int index, GraphContainer<NL, EL, G> element) {
        GraphIterator it = new GraphIterator(elements.listIterator(index));
        GraphContainer<NL, EL, G> prev = it.next();
        it.set(element);
        return prev;
    }

    @Override
    public void add(int index, GraphContainer<NL, EL, G> element) {
        totalElementsSize += elements.size();

        elements.add(index, element);
    }

    @Override
    public GraphContainer<NL, EL, G> remove(int index) {
        GraphContainer<NL, EL, G> remove = elements.remove(index);
        totalElementsSize -= remove.size(gSize);
        return remove;
    }

    @Override
    public int indexOf(Object o) {
        return elements.indexOf(o);
    }

    @Override
    public int lastIndexOf(Object o) {
        return elements.lastIndexOf(o);
    }

    @Override
    public GraphIterator listIterator() {
        return new GraphIterator(elements.listIterator());
    }

    @Override
    public GraphIterator listIterator(int index) {
        return new GraphIterator(elements.listIterator(index));
    }

    @Override
    public List<GraphContainer<NL, EL, G>> subList(int fromIndex, int toIndex) {
        return elements.subList(fromIndex, toIndex);
    }

    @Override
    public String toString() {
        final String eol = System.getProperty("line.separator");
        StringBuilder sb = new StringBuilder();

        sb.append("Cluster ");
        sb.append(id);
        sb.append(" with size: ");
        sb.append(elements.size());
        sb.append(eol);
        for (GraphContainer<NL, EL, G> rep : representatives) {
            sb.append(rep.toString());
            sb.append(eol);
            sb.append("---");
            sb.append(eol);
        }
        if (!representatives.isEmpty()) {
            sb.delete(sb.length() - 5, sb.length() - 1);
        }
        return sb.toString();
    }

    /**
     * Encapsules the {@link ListIterator} for updating the avgMemberSize
     * 
     * @author Till Schäfer
     *
     */
    private class GraphIterator implements ListIterator<GraphContainer<NL, EL, G>> {
        private ListIterator<GraphContainer<NL, EL, G>> it;
        private GraphContainer<NL, EL, G> lastReturned = null;

        public GraphIterator(ListIterator<GraphContainer<NL, EL, G>> it) {
            this.it = it;
        }

        @Override
        public boolean hasNext() {
            return it.hasNext();
        }

        @Override
        public GraphContainer<NL, EL, G> next() {
            lastReturned = it.next();
            return lastReturned;
        }

        @Override
        public boolean hasPrevious() {
            return it.hasPrevious();
        }

        @Override
        public GraphContainer<NL, EL, G> previous() {
            lastReturned = it.previous();
            return lastReturned;
        }

        @Override
        public int nextIndex() {
            return it.nextIndex();
        }

        @Override
        public int previousIndex() {
            return it.previousIndex();
        }

        @Override
        public void remove() {
            it.remove();

            totalElementsSize -= lastReturned.size(gSize);
            lastReturned = null;
        }

        @Override
        public void set(GraphContainer<NL, EL, G> e) {
            it.set(e);

            totalElementsSize -= lastReturned.size(gSize);
            totalElementsSize += e.size(gSize);
            lastReturned = e;
        }

        @Override
        public void add(GraphContainer<NL, EL, G> e) {
            it.add(e);

            totalElementsSize += e.size(gSize);
            lastReturned = null;
        }

    }

}
