package struclust;

/**
 * Interface for modules that can describe themself.
 * 
 * @author Till Schäfer
 *
 */
public interface Describable {
    /**
     * @return a short description of this module including configuration
     *         parameters (single line)
     */
    public String getDescription();
}
