package struclust.comparison.mss;

import graph.Graph;

/**
 * A bio-isoster replacement rule as defined in CM2 work package of
 * SPP1736#GraBaDrug
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class BioIsoster<NL, EL, G extends Graph<NL, EL>> {

    private int substitutionId;
    private G iso1;
    private G iso2;
    private int activityPreservingCount;
    private int nonActivityPreservingCount;

    /**
     * Constructor
     * 
     * @param substitutionId
     *            the identifier for this substitution.
     * @param iso1
     *            the first isoster
     * @param iso2
     *            the second isoster
     * @param activityPreservingCount
     *            he count of activity preserving substitutions in the
     *            generating source dataset
     * @param nonActivityPreservingCount
     *            the count of substitutions that are not activity preserving in
     *            the generating source dataset
     */
    public BioIsoster(int substitutionId, G iso1, G iso2, int activityPreservingCount, int nonActivityPreservingCount) {
        super();
        this.substitutionId = substitutionId;
        this.iso1 = iso1;
        this.iso2 = iso2;
        this.activityPreservingCount = activityPreservingCount;
        this.nonActivityPreservingCount = nonActivityPreservingCount;
    }

    /**
     * @return the identifier for this substitution
     */
    public int getSubstitutionId() {
        return substitutionId;
    }

    /**
     * @param substitutionId
     *            set the identifier for this substitution
     */
    public void setSubstitutionId(int substitutionId) {
        this.substitutionId = substitutionId;
    }

    /**
     * @return the first isoster
     */
    public G getIso1() {
        return iso1;
    }

    /**
     * @param iso1
     *            set the first isoster
     */
    public void setIso1(G iso1) {
        this.iso1 = iso1;
    }

    /**
     * @return the second isoster
     */
    public G getIso2() {
        return iso2;
    }

    /**
     * @param iso2
     *            set the first isoster
     */
    public void setIso2(G iso2) {
        this.iso2 = iso2;
    }

    /**
     * @return the count of activity preserving substitutions in the generating
     *         source dataset
     */
    public int getActivityPreservingCount() {
        return activityPreservingCount;
    }

    /**
     * @param activityPreservingCount
     *            set the count of activity preserving substitutions in the
     *            generating source dataset
     */
    public void setActivityPreservingCount(int activityPreservingCount) {
        this.activityPreservingCount = activityPreservingCount;
    }

    /**
     * @return the count of substitutions that are not activity preserving in
     *         the generating source dataset
     */
    public int getNonActivityPreservingCount() {
        return nonActivityPreservingCount;
    }

    /**
     * @param nonActivityPreservingCount
     *            set the count of substitutions that are not activity
     *            preserving in the generating source dataset
     */
    public void setNonActivityPreservingCount(int nonActivityPreservingCount) {
        this.nonActivityPreservingCount = nonActivityPreservingCount;
    }

    /**
     * @return the fraction of activity preserving substitutions wrt all
     *         substitutions.
     */
    public double getActivityPreservingFraction() {
        return (double) activityPreservingCount / (nonActivityPreservingCount + activityPreservingCount);
    }

}
