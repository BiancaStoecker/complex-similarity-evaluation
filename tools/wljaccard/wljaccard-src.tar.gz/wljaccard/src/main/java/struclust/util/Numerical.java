package struclust.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

import com.google.common.base.Preconditions;

/**
 * Convenience methods for numerical operations.
 * 
 * @author Till Schäfer
 */
public class Numerical {
    private static final BigDecimal SQRT_DIG = new BigDecimal(150);
    private static final BigDecimal SQRT_PRE = new BigDecimal(10).pow(SQRT_DIG.intValue());
    private static final int RIGHT16 = 0xFFFF;

    /**
     * Computes an incremental average
     * 
     * @param count
     *            the count of all values (<b>including</b> the value which
     *            should be added by this call)
     * @param prevAvg
     *            the average value (for the count-1 values)
     * @param addValue
     *            the value which should be added incrementally
     * @return the new average value
     */
    public static double incAvg(long count, double prevAvg, double addValue) {
        assert count >= 1;

        /**
         * second formula gives smaller rounding errors:
         * 
         * <pre>
         * newAvg = (prevAvg * (count - 1) + addValue) / count 
         *        = prevAvg + (addValue - prevAvg) / count
         * </pre>
         */
        return prevAvg + ((addValue - prevAvg) / count);
    }

    /**
     * Computes an incremental average for multiple elements
     * 
     * @param count
     *            the count of all values (<b>including</b> the values which
     *            should be added by this call)
     * @param prevAvg
     *            the average value (for the count-numAddValues values)
     * @param addValueSum
     *            the sum of all value which should be added incrementally
     * @param numAddValues
     *            the number of values to add
     * @return the new average value
     */
    public static double incAvg(long count, double prevAvg, double addValueSum, int numAddValues) {

        /**
         * second formula gives smaller rounding errors:
         * 
         * <pre>
         * newAvg = (prevAvg * (count - numAddValues) + addValue) / count 
         *        = prevAvg + (addValue - numAddValues * prevAvg) / count
         * </pre>
         */
        return prevAvg + ((addValueSum - numAddValues * prevAvg) / count);
    }

    /**
     * Computes an decremental average (i.e. the inverse of
     * {@link Numerical#incAvg(long, double, double)}
     * 
     * @param count
     *            the count of all values (<b>excluding</b> the value which
     *            should be subtracted by this call)
     * @param prevAvg
     *            the average value (for the count+1 values)
     * @param subValue
     *            the value which should be subtracted decrementally
     * @return the new average value. If count is 0, this will return 0.
     */
    public static double decAvg(long count, double prevAvg, double subValue) {
        assert count >= 0;
        /**
         * <pre>
         * newAvg = (prevAvg * (count + 1) - subValue) / count
         *        = prevAvg + (prevAvg - subValue) / count
         * </pre>
         */
        return count == 0 ? 0 : prevAvg + (prevAvg - subValue) / count;
    }

    /**
     * Computes an decremental average for multiple elements (i.e. the inverse
     * of {@link Numerical#incAvg(long, double, double, int)}
     * 
     * @param count
     *            the count of all values (<b>excluding</b> the values which
     *            should be subtracted by this call)
     * @param prevAvg
     *            the average value (for the count+numAddValues values)
     * @param subValueSum
     *            the sum of all value which should be subtracted decrementally
     * @param numSubValues
     *            the number of values to subtract
     * @return the new average value. If count is 0, this will return 0.
     */
    public static double decAvg(long count, double prevAvg, double subValueSum, int numSubValues) {
        assert count >= 0;
        /**
         * <pre>
         * newAvg = (prevAvg * (count + numSubValues) - subValue) / count
         *        = prevAvg + (numSubValues * prevAvg - subValue) / count
         * </pre>
         */
        return count == 0 ? 0 : prevAvg + (numSubValues * prevAvg - subValueSum) / count;
    }

    /**
     * Private utility method used to compute the square root of a BigDecimal.
     * 
     * @author Luciano Culacciatti
     * @url http://www.codeproject.com/Tips/257031/Implementing-SqrtRoot-in-
     *      BigDecimal
     */
    private static BigDecimal sqrtNewtonRaphson(BigDecimal c, BigDecimal xn, BigDecimal precision) {
        BigDecimal fx = xn.pow(2).add(c.negate());
        BigDecimal fpx = xn.multiply(new BigDecimal(2));
        BigDecimal xn1 = fx.divide(fpx, 2 * SQRT_DIG.intValue(), RoundingMode.HALF_DOWN);
        xn1 = xn.add(xn1.negate());
        BigDecimal currentSquare = xn1.pow(2);
        BigDecimal currentPrecision = currentSquare.subtract(c);
        currentPrecision = currentPrecision.abs();
        if (currentPrecision.compareTo(precision) <= -1) {
            return xn1;
        }
        return sqrtNewtonRaphson(c, xn1, precision);
    }

    /**
     * Uses Newton Raphson to compute the square root of a BigDecimal.
     * 
     * Precision is 150 digits.
     * 
     * @author Luciano Culacciatti
     * @param c
     *            the bib integer to divide.
     * @return a new BigDecimal containing the square root of c
     * 
     * @url http://www.codeproject.com/Tips/257031/Implementing-SqrtRoot-in-
     *      BigDecimal
     */
    public static BigDecimal bigSqrt(BigDecimal c) {
        Preconditions.checkArgument(c.signum() != -1);
        return sqrtNewtonRaphson(new BigDecimal(c.toString()), new BigDecimal(1), new BigDecimal(1).divide(SQRT_PRE));
    }

    /**
     * Packs two 16 bit integers into a single native int. If the values of left
     * or right are larger than 16 bit, the upper 16 bits are cut off.
     * 
     * @param left
     *            the left unsigned 16 bit value
     * @param right
     *            the right unsigned 16 bit value
     * @return a packed native int with both values encoded
     */
    public static int packUnsigned1616(int left, int right) {
        return (left << 16) | (right & RIGHT16);
    }

    /**
     * Inverse operation of {@link #packUnsigned1616(int, int)} for the right
     * value.
     * 
     * @param packed
     *            the packed unsigned 1616 integers
     * @return the right unsigned 16 bit value
     */
    public static int unpackUnsigned16Right(int packed) {
        return packed & RIGHT16;
    }

    /**
     * Inverse operation of {@link #packUnsigned1616(int, int)} for the left
     * value.
     * 
     * @param packed
     *            the packed unsigned 1616 integers
     * @return the left unsigned 16 bit value
     */
    public static int unpackUnsigned16Left(int packed) {
        return packed >>> 16;
    }
}
