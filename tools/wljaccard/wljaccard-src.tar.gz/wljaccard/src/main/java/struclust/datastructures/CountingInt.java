package struclust.datastructures;

import java.util.HashMap;

/**
 * This is a mutable integer for counting in Maps. Counting is faster if you do
 * not need to put the mutable {@link Integer} back into the map after
 * increment.
 * 
 * Attention: Defaults to 1 after creation
 * 
 * @author Till Schäfer
 */
public class CountingInt extends MutableInt {

    /**
     * Constructor
     * 
     * initial value is 1
     */
    public CountingInt() {
        value = 1;
    }

    /**
     * Constructor
     * 
     * @param value
     *            initial value
     */
    public CountingInt(int value) {
        this.value = value;
    }

    /**
     * Increment the value by 1
     */
    public void increment() {
        ++value;
    }

    /**
     * Decrement the value by 1
     */
    public void decrement() {
        --value;
    }

    /**
     * Increments the count inside a HashMap. If the map does not contain o, a
     * new entry is created with the value 1.
     * 
     * @param map
     *            the count map
     * @param o
     *            the map key to count
     */
    public static <E> void incrementCount(HashMap<E, CountingInt> map, E o) {
        CountingInt val = map.get(o);
        if (val != null) {
            val.increment();
        } else {
            map.put(o, new CountingInt());
        }
    }
}