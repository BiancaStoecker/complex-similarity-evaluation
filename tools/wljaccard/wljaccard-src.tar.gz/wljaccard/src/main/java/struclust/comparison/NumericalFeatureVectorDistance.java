package struclust.comparison;

import hsahn.datastructure.FeatureVector;

/**
 * Distance between to numerical FeatureVectors.
 * 
 * @author Till Schäfer
 *
 * @param <K>
 *            the feature key type
 */
public interface NumericalFeatureVectorDistance<K> extends SameTypeDistance<FeatureVector<K>> {

}
