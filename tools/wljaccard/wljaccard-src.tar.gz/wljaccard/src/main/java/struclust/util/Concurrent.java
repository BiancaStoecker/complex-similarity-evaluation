package struclust.util;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Class for convenient methods regarding concurrency
 * 
 * @author Till Schäfer
 */
public class Concurrent {
    /**
     * Returns the rawValue for each value above zero and the number of available
     * processors otherwise.
     * 
     * @param rawValue
     *            the raw value
     * @return the effective parallelism.
     */
    public static int getEffectiveParallelism(int rawValue) {
        if (rawValue < 1) {
            return Runtime.getRuntime().availableProcessors();
        } else {
            return rawValue;
        }
    }

    /**
     * Sets the common ForkJoinPool parallelism (used for parallel streams) to the
     * desired level.
     * 
     * <br>
     * <strong>Attention</strong>: You must call this method before any parallel
     * stream operation is executed. Calling this method afterwards will have no
     * effect.
     * 
     * @param maxThreads
     *            the maximum number of threads running in parallel. Note: this is
     *            different from the {@link ForkJoinPool} parallelism value, because
     *            the {@link ForkJoinPool} only considers additional threads
     *            additionally to the main thread. This value is an absolute value
     *            including the main thread.
     */
    public static void setCommonFJPParallelism(int maxThreads) {
        int additionalThreads = maxThreads - 1;
        System.setProperty("java.util.concurrent.ForkJoinPool.common.parallelism", String.valueOf(additionalThreads));
        assert ForkJoinPool.getCommonPoolParallelism() == additionalThreads;
    }

    /**
     * ExecutorService with BlockingQueue for Jobs, such that no more than queueSize
     * many jobs can be submitted without being processed.
     * 
     * @param nThreads
     *            number of threads
     * @param queueSize
     *            the maximum number of jobs in the queue before the submit call is
     *            blocking
     * @return the {@link ExecutorService} with BlockingQueue
     */
    public static ExecutorService newFixedThreadPoolWithQueueSize(int nThreads, int queueSize) {
        return new ThreadPoolExecutor(nThreads, nThreads, 5000L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<Runnable>(queueSize, true), new ThreadPoolExecutor.CallerRunsPolicy());
    }

    /**
     * Helper {@link Runnable} to apply a {@link Consumer} in parallel for
     * {@link Future}s.
     * 
     * @author Till Schäfer
     * @param <T>
     *            the type of the elements to consume
     */
    public static class AsyncFutureConsumer<T> implements Runnable {
        private boolean closed = false;
        private ArrayBlockingQueue<Future<T>> workQueue;
        private Consumer<? super T> consumer;
        private InterruptedException interruptedException;
        private ExecutionException executionException = null;

        /**
         * Constructor
         * 
         * @param consumer
         *            the {@link Consumer} to accept the {@link Future}s from
         * @param queueLength
         *            the length of the working queue
         */
        public AsyncFutureConsumer(Consumer<? super T> consumer, int queueLength) {
            this.consumer = consumer;
            this.workQueue = new ArrayBlockingQueue<>(queueLength);
        }

        @Override
        public void run() {
            while (!workQueue.isEmpty() || !closed) {
                Future<T> next = null;
                try {
                    next = workQueue.poll(1, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    // this is normal
                }
                if (next != null) {
                    try {
                        consumer.accept(next.get());
                    } catch (InterruptedException e) {
                        interruptedException = e;
                    } catch (ExecutionException e) {
                        executionException = e;
                        closed = true;
                    }
                }
            }
        }

        /**
         * Add a new job, i.e., a future to consume, to the work queue. This call is
         * blocking if queueLength is exceeded, waiting for space to become available.
         * 
         * @param future
         *            the future to consume
         * @throws InterruptedException
         */
        public void addJob(Future<T> future) throws InterruptedException {
            if (!closed) {
                workQueue.put(future);
            } else {
                throw new IllegalStateException("writer is closed");
            }
        }

        /**
         * Close the writer and do not accept new incoming jobs.
         */
        public void close() {
            closed = true;
        }

        /**
         * @return whether the writer is closed
         */
        public boolean isClosed() {
            return closed;
        }

        /**
         * @return a {@link ExecutionException} or null if no Exception was thrown
         */
        public ExecutionException getExecutionException() {
            return executionException;
        }

        /**
         * @return whether a write exception has occurred
         */
        public boolean isFailed() {
            return executionException != null;
        }

        /**
         * @return a {@link InterruptedException} or null if no Exception was thrown
         */
        public InterruptedException getInterruptedException() {
            return interruptedException;
        }

        /**
         * @return whether a write exception has occurred
         */
        public boolean isInteruppted() {
            return interruptedException != null;
        }

    }
}
