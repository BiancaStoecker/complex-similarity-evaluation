package struclust.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.exception.InvalidSmilesException;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.io.SDFWriter;
import org.openscience.cdk.io.iterator.IteratingSDFReader;
import org.openscience.cdk.silent.SilentChemObjectBuilder;
import org.openscience.cdk.smiles.SmilesParser;
import org.openscience.cdk.tools.manipulator.AtomContainerManipulator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;

import graph.DefaultGraph;
import graph.DefaultNode;
import graph.Edge;
import graph.Graph;
import graph.GraphSize;
import graph.MoleculeGraph;
import graph.Node;
import graph.SuccintGraph;
import struclust.Cluster;
import struclust.comparison.mss.BioIsoster;
import struclust.datastructures.CountingInt;
import struclust.graph.GraphContainer;
import struclust.graph.Graphs;
import struclust.util.Concurrent.AsyncFutureConsumer;

/**
 * Helper class to read / write graph databases.
 * 
 * @author Till Schäfer
 */
public class GraphIO {
    private static final String endl = System.getProperty("line.separator");
    private static final Logger logger = LoggerFactory.getLogger(GraphIO.class);

    /**
     * Reading in some molecules from SDF
     * 
     * @param path
     *            the path to the SDF
     * 
     * @return List of {@link IAtomContainer}s or null if the molecules cannot be
     *         read
     */
    public static List<IAtomContainer> sdfToIAtomcontainerList(String path) {
        File sdfFile = new File(path);
        List<IAtomContainer> molecules = new LinkedList<>();
        try (IteratingSDFReader reader = new IteratingSDFReader(new FileInputStream(sdfFile),
                SilentChemObjectBuilder.getInstance(), true);) {
            while (reader.hasNext()) {
                molecules.add(reader.next());
            }
        } catch (IOException e) {
            logger.error("Error while reading from " + path, e);
            return null;
        }
        return molecules;
    }

    /**
     * Filters an SDF file with a custom predicate
     * 
     * @param inPath
     *            the path to the input SDF
     * @param outPath
     *            the path to the output SDF
     * @param filter
     *            the filter predicate
     * @throws FileNotFoundException
     * @throws IOException
     * @throws CDKException
     * @throws InterruptedException
     */
    public static void filterSdf(String inPath, String outPath, Predicate<IAtomContainer> filter)
            throws FileNotFoundException, IOException, CDKException, InterruptedException {
        Preconditions.checkNotNull(inPath);
        Preconditions.checkNotNull(outPath);
        Preconditions.checkNotNull(filter);

        File inFile = new File(inPath);
        File outFile = new File(outPath);

        try (IteratingSDFReader reader = new IteratingSDFReader(new BufferedReader(new FileReader(inFile)),
                SilentChemObjectBuilder.getInstance(), true);
                SDFWriter writer = new SDFWriter(new BufferedWriter(new FileWriter(outFile)));) {
            AsyncSDFWriter writerRunnable = new AsyncSDFWriter(writer, 10);
            Thread writerThread = new Thread(writerRunnable);
            writerThread.start();
            while (reader.hasNext() && !writerRunnable.isFailed()) {
                IAtomContainer next = reader.next();
                if (filter.test(next)) {
                    writerRunnable.addJob(next);
                }
            }
            writerRunnable.close();
            writerThread.join();

            if (writerRunnable.isFailed()) {
                throw writerRunnable.getWriteException();
            }
        }
    }

    /**
     * Helper {@link Runnable} to write an SDF asynchronously with a size bounded
     * workQueue. The writer is closed if an write exception occurs.
     * 
     * @author Till Schäfer
     */
    public static class AsyncSDFWriter implements Runnable {
        private boolean closed = false;
        private ArrayBlockingQueue<IAtomContainer> workQueue;
        private SDFWriter writer;
        CDKException writeException = null;

        /**
         * Constructor
         * 
         * @param writer
         *            the {@link SDFWriter} to write the molecules.
         * @param queueLength
         *            the length of the working queue
         */
        public AsyncSDFWriter(SDFWriter writer, int queueLength) {
            this.workQueue = new ArrayBlockingQueue<>(queueLength);
            this.writer = writer;
        }

        @Override
        public void run() {
            while (!workQueue.isEmpty() || !closed) {
                IAtomContainer next = null;
                try {
                    next = workQueue.poll(1, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    // this is normal
                }
                if (next != null) {
                    try {
                        writer.write(next);
                    } catch (CDKException e) {
                        writeException = e;
                        closed = true;
                    }
                }
            }
        }

        /**
         * Add a new job, i.e., a molecule to write out, to the work queue. This call is
         * blocking if queueLength is exceeded, waiting for space to become available.
         * 
         * @param mol
         *            the molecule to write
         * @throws InterruptedException
         */
        public void addJob(IAtomContainer mol) throws InterruptedException {
            if (!closed) {
                workQueue.put(mol);
            } else {
                throw new IllegalStateException("writer is closed");
            }
        }

        /**
         * Close the writer and do not accept new incoming jobs.
         */
        public void close() {
            closed = true;
        }

        /**
         * @return whether the writer is closed
         */
        public boolean isClosed() {
            return closed;
        }

        /**
         * @return a {@link CDKException} or null if no Exception was thrown during
         *         writing.
         */
        public CDKException getWriteException() {
            return writeException;
        }

        /**
         * @return whether a write exception has occurred
         */
        public boolean isFailed() {
            return writeException != null;
        }

    }

    /**
     * Reading in some molecules from SDF
     * 
     * @param path
     *            the path to the SDF. If the extension of the file is ".gz", the
     *            data is automatically uncompressed.
     * @param configure
     *            configure the CDK molecule before the conversion to the
     *            {@link MoleculeGraph}. This will add informations, such as
     *            aromaticity.
     * @param stripCDKReference
     *            remove CDKs IAtomcontainer reference (saves Memory)
     * 
     * @return List of {@link MoleculeGraph}s or null if the graphs cannot be read
     */
    public static List<MoleculeGraph> sdfToMoleculeGraphs(String path, boolean configure, boolean stripCDKReference) {
        return sdfToMoleculeGraphs(path, configure, stripCDKReference, Integer.MAX_VALUE);
    }

    /**
     * Reading in some molecules from SDF
     * 
     * @param path
     *            the path to the SDF. If the extension of the file is ".gz", the
     *            data is automatically uncompressed.
     * @param configure
     *            configure the CDK molecule before the conversion to the
     *            {@link MoleculeGraph}. This will add informations, such as
     *            aromaticity.
     * @param stripCDKReference
     *            remove CDKs IAtomcontainer reference (saves Memory)
     * @param maxNum
     *            the maximal number of Graphs to load. If the limit is reached the
     *            first maxNum Graphs are returned and the reading process is
     *            aborted.
     * 
     * @return List of {@link MoleculeGraph}s or null if the graphs cannot be read
     */
    public static List<MoleculeGraph> sdfToMoleculeGraphs(String path, boolean configure, boolean stripCDKReference,
            int maxNum) {
        return sdfToMoleculeGraphs(path, configure, stripCDKReference, maxNum, null);
    }

    /**
     * Reading in some molecules from SDF
     * 
     * @param path
     *            the path to the SDF. If the extension of the file is ".gz", the
     *            data is automatically uncompressed.
     * @param configure
     *            configure the CDK molecule before the conversion to the
     *            {@link MoleculeGraph}. This will add informations, such as
     *            aromaticity.
     * @param stripCDKReference
     *            remove CDKs IAtomcontainer reference (saves Memory)
     * @param maxNum
     *            the maximal number of Graphs to load. If the limit is reached the
     *            first maxNum Graphs are returned and the reading process is
     *            aborted.
     * @param filter
     *            a filter that is applied while reading the graphs. e.g. one can
     *            specify to read only graphs of a size less than some threshold. If
     *            the parameter is null, the filter is deactivated.
     * 
     * @return List of {@link MoleculeGraph}s or null if the graphs cannot be read
     */
    public static List<MoleculeGraph> sdfToMoleculeGraphs(String path, boolean configure, boolean stripCDKReference,
            int maxNum, Predicate<IAtomContainer> filter) {
        List<MoleculeGraph> retVal = defaultSdfToCollectionStreamingImpl(path, configure, stripCDKReference, maxNum,
                filter, gc -> gc.getGraph());
        return retVal;
    }

    /**
     * Reading in some molecules from SDF. Additionally, specified properties are
     * also added as metadata to the Graphs.
     * 
     * @param path
     *            the path to the SDF. If the extension of the file is ".gz", the
     *            data is automatically uncompressed.
     * @param configure
     *            configure the CDK molecule before the conversion to the
     *            {@link MoleculeGraph}. This will add informations, such as
     *            aromaticity.
     * @param stripCDKReference
     *            remove CDKs IAtomcontainer reference (saves Memory)
     * @param maxNum
     *            the maximal number of Graphs to load. If the limit is reached the
     *            first maxNum Graphs are returned and the reading process is
     *            aborted. if null, the functionality is disabled.
     * @param propNames
     *            the property names that should be attaches as metadata.
     * @param filter
     *            a filter that is applied while reading the graphs. e.g. one can
     *            specify to read only graphs of a size less than some threshold. If
     *            the parameter is null, the filter is deactivated.
     * @return List of {@link MoleculeGraph}s or null if the graphs cannot be read
     */
    public static ArrayList<GraphContainer<String, String, MoleculeGraph>> sdfToMoleculeGraphContainersWithProperties(
            String path, boolean configure, boolean stripCDKReference, Integer maxNum, Set<String> propNames,
            Predicate<IAtomContainer> filter) {
        Preconditions.checkNotNull(path);
        Preconditions.checkNotNull(propNames);

        ArrayList<GraphContainer<String, String, MoleculeGraph>> retVal = defaultSdfToCollectionStreamingImpl(path,
                configure, stripCDKReference, maxNum, filter, gc -> gc);

        return retVal;
    }

    /**
     * Reading in some molecules from SDF. Additionally, specified properties are
     * also added as metadata to the Graphs.
     * 
     * @param path
     *            the path to the SDF. If the extension of the file is ".gz", the
     *            data is automatically uncompressed.
     * @param configure
     *            configure the CDK molecule before the conversion to the
     *            {@link MoleculeGraph}. This will add informations, such as
     *            aromaticity.
     * @param maxNum
     *            the maximal number of Graphs to load. If the limit is reached the
     *            first maxNum Graphs are returned and the reading process is
     *            aborted. if null, the functionality is disabled.
     * @param propNames
     *            the property names that should be attaches as metadata.
     * @param nodeLableMapping
     *            the mapping to convert the node labels to {@link Integer}s
     * @param edgeLabelMapping
     *            the mapping to convert the edge labels to {@link Integer}s
     * @param addNewLabels
     *            if true, missing label maps are automatically added (mapping to
     *            the lowest available integer value)
     * @param filter
     *            a filter that is applied while reading the graphs. e.g. one can
     *            specify to read only graphs of a size less than some threshold. If
     *            the parameter is null, the filter is deactivated.
     * @return List of {@link MoleculeGraph}s or null if the graphs cannot be read
     */
    public static ArrayList<GraphContainer<Integer, Integer, SuccintGraph>> sdfToSuccintGraphContainersWithProperties(
            String path, boolean configure, Integer maxNum, Set<String> propNames,
            Map<String, Integer> nodeLableMapping, Map<String, Integer> edgeLabelMapping, boolean addNewLabels,
            Predicate<IAtomContainer> filter) {
        Preconditions.checkNotNull(path);
        Preconditions.checkNotNull(propNames);
        Preconditions.checkNotNull(nodeLableMapping);
        Preconditions.checkNotNull(edgeLabelMapping);
        
        ArrayList<GraphContainer<Integer, Integer, SuccintGraph>> retVal = defaultSdfToCollectionStreamingImpl(path,
                configure, true, maxNum, filter, gc -> moleculeGraphContainer2SuccintGraphContianer(nodeLableMapping,
                        edgeLabelMapping, addNewLabels, gc));
        return retVal;
    }

    private static GraphContainer<Integer, Integer, SuccintGraph> moleculeGraphContainer2SuccintGraphContianer(
            Map<String, Integer> nodeLableMapping, Map<String, Integer> edgeLabelMapping, boolean addNewLabels,
            GraphContainer<String, String, MoleculeGraph> gc) {
        SuccintGraph sg = new SuccintGraph(gc.getGraph(), nodeLableMapping, edgeLabelMapping, addNewLabels);

        GraphContainer<Integer, Integer, SuccintGraph> sgc = new GraphContainer<>(sg);

        for (String propName : gc.getProperties().keySet()) {
            sgc.putProperty(propName, gc.getProperty(propName));
        }

        return sgc;
    }

    /**
     * Reading in some molecules from SDF and apply the resulting GraphContianers to
     * a Consumer in a streaming fashion. Additionally, specified properties are
     * also added as metadata to the Graphs.
     * 
     * @param path
     *            the path to the SDF. If the extension of the file is ".gz", the
     *            data is automatically uncompressed.
     * @param configure
     *            configure the CDK molecule before the conversion to the
     *            {@link MoleculeGraph}. This will add informations, such as
     *            aromaticity.
     * @param stripCDKReference
     *            remove CDKs IAtomcontainer reference (saves Memory)
     * @param maxNum
     *            the maximal number of Graphs to load. If the limit is reached the
     *            first maxNum Graphs are returned and the reading process is
     *            aborted. if null, the functionality is disabled.
     * @param propNames
     *            the property names that should be attaches as metadata.
     * @param filter
     *            a filter that is applied while reading the graphs. e.g. one can
     *            specify to read only graphs of a size less than some threshold. If
     *            the parameter is null, the filter is deactivated.
     * @param consumer
     *            this consumer will {@link Consumer#accept(Object)} the read
     *            GraphContainers
     * @throws InterruptedException
     * @throws ExecutionException
     *             if molecule conversion failed
     * @throws IOException
     */
    public static void sdfToMoleculeGraphContainersWithPropertiesStreaming(String path, boolean configure,
            boolean stripCDKReference, Integer maxNum, Set<String> propNames, Predicate<IAtomContainer> filter,
            Consumer<? super GraphContainer<String, String, MoleculeGraph>> consumer)
            throws InterruptedException, ExecutionException, IOException {
        Preconditions.checkNotNull(path);
        Preconditions.checkNotNull(propNames);

        File sdfFile = new File(path);
        boolean gzip = path.endsWith(FilenameUtils.EXTENSION_SEPARATOR + "gz");
        int count = 0;
        int filtered = 0;
        boolean filtering = filter != null;
        int numThreads = Runtime.getRuntime().availableProcessors();
        AsyncFutureConsumer<GraphContainer<String, String, MoleculeGraph>> asyncConsumer = new AsyncFutureConsumer<>(
                consumer, numThreads * 4);
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        Thread consumerThread = new Thread(asyncConsumer);
        consumerThread.start();
        try (IteratingSDFReader reader = new IteratingSDFReader(
                gzip ? new GZIPInputStream(new FileInputStream(sdfFile)) : new FileInputStream(sdfFile),
                SilentChemObjectBuilder.getInstance(), true);) {
            while (reader.hasNext() && !asyncConsumer.isFailed()) {
                IAtomContainer next = reader.next();
                if (!filtering || filter.test(next)) {

                    MoleculeGraphCreator job = new MoleculeGraphCreator(next, configure, stripCDKReference, propNames);
                    asyncConsumer.addJob(executor.submit(job));

                    count++;
                    if (count % 1000 == 0) {
                        logger.debug("Read {}{} graphs so far...", count, filtering ? " filtered" : "");
                    }
                    if (maxNum != null && count >= maxNum) {
                        break;
                    }
                } else {
                    filtered++;
                }
            }
            if (filtering) {
                logger.debug("filtered {} graphs", filtered);
            }
        }

        executor.shutdown();
        executor.awaitTermination(Long.MAX_VALUE, TimeUnit.DAYS);
        asyncConsumer.close();
        consumerThread.join();
        if (asyncConsumer.isFailed()) {
            throw asyncConsumer.getExecutionException();
        }
        if (asyncConsumer.isInteruppted()) {
            throw asyncConsumer.getInterruptedException();
        }
    }

    private static <T> ArrayList<T> defaultSdfToCollectionStreamingImpl(String path, boolean configure,
            boolean stripCDKReference, Integer maxNum, Predicate<IAtomContainer> filter,
            Function<GraphContainer<String, String, MoleculeGraph>, T> extractor) {
        ArrayList<T> retVal = new ArrayList<>();
        try {
            sdfToMoleculeGraphContainersWithPropertiesStreaming(path, configure, stripCDKReference, maxNum,
                    java.util.Collections.emptySet(), filter, gc -> retVal.add(extractor.apply(gc)));
        } catch (InterruptedException e) {
            logger.warn("converting molecules interrupted", e);
            return null;
        } catch (ExecutionException e) {
            logger.error("converting molecules failed", e);
            return null;
        } catch (IOException e) {
            logger.error("Error while reading from {}", path, e);
            return null;
        }
        return retVal;
    }

    /**
     * Reading in some molecules from SDF. Additionally, specified properties are
     * also added as metadata to the Graphs.
     * 
     * @param path
     *            the path to the SDF. If the extension of the file is ".gz", the
     *            data is automatically uncompressed.
     * @param maxNum
     *            the maximal number of Graphs to load. If the limit is reached the
     *            first maxNum Graphs are returned and the reading process is
     *            aborted. if null, the functionality is disabled.
     * @param filter
     *            a filter that is applied while reading the graphs. e.g. one can
     *            specify to read only graphs of a size less than some threshold. If
     *            the parameter is null, the filter is deactivated.
     * @return List of {@link MoleculeGraph}s or null if the graphs cannot be read
     */
    public static ArrayList<String> sdfToSmiles(String path, Integer maxNum, Predicate<IAtomContainer> filter) {
        Preconditions.checkNotNull(path);

        File sdfFile = new File(path);
        boolean gzip = path.endsWith(FilenameUtils.EXTENSION_SEPARATOR + "gz");
        ArrayList<String> retVal = new ArrayList<>();
        int count = 0;
        int filtered = 0;
        boolean filtering = filter != null;
        int numThreads = Runtime.getRuntime().availableProcessors();
        ExecutorService executor = Concurrent.newFixedThreadPoolWithQueueSize(numThreads, numThreads * 2);
        List<Future<String>> futures = new ArrayList<>();

        try (IteratingSDFReader reader = new IteratingSDFReader(
                gzip ? new GZIPInputStream(new FileInputStream(sdfFile)) : new FileInputStream(sdfFile),
                SilentChemObjectBuilder.getInstance(), true);) {
            while (reader.hasNext()) {
                IAtomContainer next = reader.next();
                if (!filtering || filter.test(next)) {

                    SmilesCreator job = new SmilesCreator(next);
                    futures.add(executor.submit(job));
                    count++;
                    if (count % 1000 == 0) {
                        logger.debug("Read {}{} graphs so far...", count, filtering ? " filtered" : "");
                    }
                    if (maxNum != null && count >= maxNum) {
                        break;
                    }
                } else {
                    filtered++;
                }
            }
            if (filtering) {
                logger.debug("filtered {} graphs", filtered);
            }
        } catch (IOException e) {
            logger.error("Error while reading from {}", path, e);
            return null;
        }

        try {
            executor.shutdown();
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.DAYS);
            for (Future<String> future : futures) {
                retVal.add(future.get());
            }
        } catch (InterruptedException e) {
            logger.warn("converting molecules interrupted", e);
            return null;
        } catch (ExecutionException e) {
            logger.error("converting molecules failed", e);
            return null;
        }

        return retVal;
    }

    /**
     * Read graphs from a GML file. If the extension of the file is ".gz", the data
     * is automatically uncompressed.
     * 
     * @param path
     *            the path to the gml file
     * @return the graphs
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static ArrayList<DefaultGraph<String, String>> gmlToDefaultGraphs(String path)
            throws FileNotFoundException, IOException {
        ArrayList<DefaultGraph<String, String>> retVal = new ArrayList<>();
        boolean gzip = path.endsWith(FilenameUtils.EXTENSION_SEPARATOR + "gz");

        try (InputStream is = gzip ? new GZIPInputStream(new FileInputStream(path)) : new FileInputStream(path);
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr)) {
            DefaultGraph<String, String> g = readSingleGmlGraph(br).getGraph();
            while (g != null) {
                retVal.add(g);
                GraphContainer<String, String, DefaultGraph<String, String>> gc = readSingleGmlGraph(br);
                g = gc != null ? gc.getGraph() : null;
            }
        }
        return retVal;
    }

    /**
     * Read {@link GraphContainer}s from a GML file. If the extension of the file is
     * ".gz", the data is automatically uncompressed.
     * 
     * The Graph Container contains properties of the gml graph. I.e. if the graph
     * contains a property label, GraphContainer#getProperty("label") will return
     * the value or null if not present.
     * 
     * @param path
     *            the path to the gml file
     * @return the graphs
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> gmlToPropertyGraphContainer(
            String path) throws FileNotFoundException, IOException {
        return gmlToPropertyGraphContainer(path, null);
    }

    /**
     * Read {@link GraphContainer}s from a GML file. If the extension of the file is
     * ".gz", the data is automatically uncompressed.
     * 
     * The Graph Container contains properties of the gml graph. I.e. if the graph
     * contains a property label, GraphContainer#getProperty("label") will return
     * the value or null if not present.
     * 
     * @param path
     *            the path to the gml file
     * @param filter
     *            a filter that is applied while reading the graphs. e.g. one can
     *            specify to read only graphs of a size less than some threshold. If
     *            the parameter is null, the filter is deactivated.
     * @return the graphs
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> gmlToPropertyGraphContainer(
            String path, Predicate<Graph<String, String>> filter) throws FileNotFoundException, IOException {
        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> retVal = new ArrayList<>();
        boolean gzip = path.endsWith(FilenameUtils.EXTENSION_SEPARATOR + "gz");
        boolean filtering = filter != null;

        try (InputStream is = gzip ? new GZIPInputStream(new FileInputStream(path)) : new FileInputStream(path);
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr)) {
            GraphContainer<String, String, DefaultGraph<String, String>> gc = readSingleGmlGraph(br);
            while (gc != null) {
                if (!filtering || filter.test(gc)) {
                    retVal.add(gc);
                }
                gc = readSingleGmlGraph(br);
            }
        }
        return retVal;
    }

    /**
     * Reads as single graph from a {@link BufferedReader} that is backed by some
     * GML data. The resulting {@link GraphContainer} contains the graphs label.
     * 
     * @param reader
     *            the {@link BufferedReader}
     * @return the read {@link GraphContainer}.
     * @throws IOException
     */
    private static GraphContainer<String, String, DefaultGraph<String, String>> readSingleGmlGraph(
            BufferedReader reader) throws IOException {
        ArrayList<Integer> idMapping = new ArrayList<>();
        String line = normalizedGmlLine(reader);
        while (line != null) {
            if (commentLine(line)) {
                line = normalizedGmlLine(reader);
                continue;
            } else if (emptyLine(line)) {
                line = normalizedGmlLine(reader);
                continue;
            } else if (blockEnd(line)) {
                // parent block ended
                return null;
            } else if (line.equals("graph [")) {
                GraphContainer<String, String, DefaultGraph<String, String>> retVal = new GraphContainer<>(
                        new DefaultGraph<>());

                while (!(line = normalizedGmlLine(reader)).equals("]")) {
                    String splittedLine[] = quotedSplit(line);
                    if (line.endsWith("[")) {
                        if (line.startsWith("node")) {
                            Node<String, String> v = retVal.addNode("");
                            boolean gmlIdPresent = false;
                            while (!(line = normalizedGmlLine(reader)).equals("]")) {
                                splittedLine = quotedSplit(line);
                                if (splittedLine.length != 2) {
                                    throw new IOException("Illegal file format: line length != 2" + " - line: " + line);
                                }
                                String key = splittedLine[0];
                                String value = splittedLine[1];
                                if (key.equals("id")) {
                                    Integer gmlId = Integer.valueOf(value);
                                    addIdMapping(gmlId, v.getIndex(), idMapping);
                                    gmlIdPresent = true;
                                } else if (key.equals("label")) {
                                    v.setLabel(unquotedString(value));
                                }
                            }
                            if (!gmlIdPresent) {
                                throw new IOException("Illegal file format: node has no id attribute");
                            }
                        } else if (line.startsWith("edge")) {
                            Node<String, String> source = null;
                            Node<String, String> target = null;
                            String label = "";
                            while (!(line = normalizedGmlLine(reader)).equals("]")) {
                                splittedLine = quotedSplit(line);
                                if (splittedLine.length != 2) {
                                    throw new IOException("Illegal file format: line length != 2" + " - line: " + line);
                                }
                                String key = splittedLine[0];
                                String value = splittedLine[1];
                                if (key.equals("label")) {
                                    label = unquotedString(value);
                                } else if (key.equals("source")) {
                                    source = getNodeByStringId(retVal, idMapping, value);
                                } else if (key.equals("target")) {
                                    target = getNodeByStringId(retVal, idMapping, value);
                                }
                            }
                            if (source == null || target == null) {
                                throw new IOException("Illegal file format: edge with no source or target attribute");
                            }
                            retVal.addEdge(source, target, label);
                        }
                    } else if (splittedLine.length == 2) {
                        retVal.putProperty(splittedLine[0], unquotedString(splittedLine[1]));
                    } else {
                        throw new IOException("Unknown Format" + " - line: " + line);
                    }
                }
                return retVal;
            } else {
                throw new IOException("Unknown Format" + " - line: " + line);
            }
        }

        return null;
    }

    /**
     * Read cluster from a custom GML file. GML File must be ordered, that its nodes
     * must be saved in increasing id order. Furthermore, the IDs must be
     * continuous.
     * 
     * @param path
     *            the path to the gml file
     * @param gSize
     *            the {@link GraphSize} for the {@link Cluster}s
     * @return the graphs
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static ArrayList<Cluster<String, String, DefaultGraph<String, String>>> clustersGmlToDefaultGraphs(
            String path, GraphSize gSize) throws FileNotFoundException, IOException {
        ArrayList<Cluster<String, String, DefaultGraph<String, String>>> retVal = new ArrayList<>();
        try (FileReader fr = new FileReader(path); BufferedReader br = new BufferedReader(fr)) {
            Cluster<String, String, DefaultGraph<String, String>> c = readSingleCluster(br, gSize);
            while (c != null) {
                retVal.add(c);
                c = readSingleCluster(br, gSize);
            }
        }
        return retVal;
    }

    private static Cluster<String, String, DefaultGraph<String, String>> readSingleCluster(BufferedReader br,
            GraphSize gSize) throws IOException {
        String line = normalizedGmlLine(br);

        while (line != null) {
            // handle comments
            if (commentLine(line)) {
                continue;
            } else if (emptyLine(line)) {
                continue;
            } else if (line.equals("cluster [")) {
                int id = Integer.MIN_VALUE;
                Collection<GraphContainer<String, String, DefaultGraph<String, String>>> members = new ArrayList<>();
                Collection<GraphContainer<String, String, DefaultGraph<String, String>>> representatives = new ArrayList<>();

                while (!(line = normalizedGmlLine(br)).equals("]")) {
                    String[] splittedLine = line.split(" ");
                    if (splittedLine[0].equals("id")) {
                        try {
                            id = Integer.parseInt(splittedLine[1]);
                        } catch (NumberFormatException e) {
                            throw new IOException("cluster id value cannot be parsed");
                        }
                    } else if (splittedLine[0].equals("size")) {
                        // ignore
                    } else if (splittedLine[0].equals("representatives")) {
                        GraphContainer<String, String, DefaultGraph<String, String>> g = readSingleGmlGraph(br);
                        while (g != null) {
                            representatives.add(g);
                            g = readSingleGmlGraph(br);
                        }
                    } else if (splittedLine[0].equals("members")) {
                        GraphContainer<String, String, DefaultGraph<String, String>> g = readSingleGmlGraph(br);
                        while (g != null) {
                            members.add(g);
                            g = readSingleGmlGraph(br);
                        }
                    } else {
                        throw new IOException("Unknown cluster attribute. Last read line: " + line);
                    }
                }
                if (id != Integer.MIN_VALUE) {
                    return new Cluster<>(members, representatives, id, gSize);
                } else {
                    throw new IOException("missing cluster id");
                }

            } else {
                throw new IOException("Unknown Format");
            }

        }

        return null;
    }

    /**
     * Reads a file of protein sequences and converts them to labeled graphs
     * (paths).
     * 
     * The file format is:
     * 
     * <pre>
     * > name 1 
     * seq1
     * seq1
     * seq1
     * ...
     * > name 2
     * seq2
     * seq2
     * seq2
     * ...
     * </pre>
     * 
     * @param path
     *            the path to the file
     * @param filterLowerCase
     *            iff true, all lowercase chards are discarded
     * @return List of {@link DefaultGraph}s or null if the graphs cannot be read
     * @throws IOException
     * @throws FileNotFoundException
     */
    public static List<GraphContainer<String, String, DefaultGraph<String, String>>> proteinSeqToDefaultGraphs(
            String path, boolean filterLowerCase) throws FileNotFoundException, IOException {
        List<GraphContainer<String, String, DefaultGraph<String, String>>> retVal = new ArrayList<>();
        try (FileReader fr = new FileReader(path); BufferedReader br = new BufferedReader(fr)) {
            String line;
            String sequence = "";
            while ((line = br.readLine()) != null) {
                if (line.isEmpty()) {
                    continue;
                }
                boolean nameLine = line.startsWith(">");
                if (nameLine) {
                    String name = line.substring(1).trim();
                    if (!sequence.isEmpty()) {
                        DefaultGraph<String, String> graph = new DefaultGraph<>();
                        DefaultNode<String, String> lastNode = null;

                        if (filterLowerCase) {
                            sequence = sequence.replaceAll("[a-z]", "");
                        }

                        for (char c : sequence.toCharArray()) {
                            DefaultNode<String, String> currentNode = graph.addNode(String.valueOf(c));
                            if (lastNode != null) {
                                graph.addEdge(lastNode, currentNode, "-");
                            }
                            lastNode = currentNode;
                        }

                        GraphContainer<String, String, DefaultGraph<String, String>> gc = new GraphContainer<>(graph);
                        gc.putProperty("name", name);
                        retVal.add(gc);

                        sequence = "";
                    }
                } else {
                    sequence += line.trim();
                }

            }
        }
        return retVal;
    }

    /**
     * Read a {@link BioIsoster} CSV file with the formaty<br>
     * <br>
     * <em>id,smiles_iso_1,smiles_iso_2,name_iso_1,name_iso_2,numActivityPreserving,
     * numNonActivityPreseving, [...]</em>
     * 
     * @param path
     *            the path to the file
     * @param stripCDKReference
     *            strip the reference to the {@link IAtomContainer} form the
     *            isosters
     * @return A {@link List} of {@link BioIsoster}
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static ArrayList<BioIsoster<String, String, MoleculeGraph>> csvToBioIsosters(String path,
            boolean stripCDKReference) throws FileNotFoundException, IOException {
        ArrayList<BioIsoster<String, String, MoleculeGraph>> retVal = new ArrayList<>();
        File csvFile = new File(path);
        boolean gzip = path.endsWith(FilenameUtils.EXTENSION_SEPARATOR + "gz");

        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                gzip ? new GZIPInputStream(new FileInputStream(csvFile)) : new FileInputStream(csvFile)))) {
            CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
            for (CSVRecord row : format.parse(br)) {
                if (row.size() < 5) {
                    throw new IOException("unknown format: csv row has not enough fields");
                }
                int substitutionId = Integer.parseInt(row.get(0));
                SmilesParser sp = new SmilesParser(SilentChemObjectBuilder.getInstance());
                MoleculeGraph iso1 = new MoleculeGraph(sp.parseSmiles(row.get(1)), false);
                MoleculeGraph iso2 = new MoleculeGraph(sp.parseSmiles(row.get(2)), false);
                if (stripCDKReference) {
                    iso1.stripCDKReference();
                    iso2.stripCDKReference();
                }
                int activityPreserving = Integer.parseInt(row.get(5));
                int nonActivityPreserving = Integer.parseInt(row.get(6));
                BioIsoster<String, String, MoleculeGraph> isoster = new BioIsoster<>(substitutionId, iso1, iso2,
                        activityPreserving, nonActivityPreserving);
                retVal.add(isoster);
            }
        } catch (InvalidSmilesException e) {
            throw new IOException("Cannot parse SMILES", e);
        }

        return retVal;
    }

    /**
     * Writes a single {@link Graph} in GML format.
     * 
     * @param w
     *            the {@link Writer}
     * @param g
     *            the {@link Graph} to write
     * @throws IOException
     */
    public static <NL, EL, G extends Graph<NL, EL>> void writeGMLGraph(Writer w, G g) throws IOException {
        writeGMLGraph(w, g, null, null);
    }

    /**
     * Writes a single {@link Graph} in GML format.
     * 
     * @param w
     *            the {@link Writer}
     * @param g
     *            the {@link Graph} to write
     * @param nodeLabelMap
     *            if not null, the node labels of the graph are replaced with the
     *            string values contained in this map. if a mapping is undefined for
     *            a label, the original label is written.
     * @param edgeLabelMap
     *            if not null, the edge labels of the graph are replaced with the
     *            string values contained in this map. if a mapping is undefined for
     *            a label, the original label is written.
     * @throws IOException
     */
    public static <NL, EL, G extends Graph<NL, EL>> void writeGMLGraph(Writer w, G g, Map<NL, String> nodeLabelMap,
            Map<EL, String> edgeLabelMap) throws IOException {
        w.write("graph [" + endl);
        w.write("directed 0" + endl);

        for (Node<NL, EL> v : g.nodes()) {
            w.write("node [" + endl);
            w.write("id " + v.getIndex() + endl);
            String mappedLabel;
            if (nodeLabelMap == null) {
                mappedLabel = v.getLabel().toString();
            } else {
                mappedLabel = nodeLabelMap.get(v.getLabel());
                if (mappedLabel == null) {
                    mappedLabel = v.getLabel().toString();
                }
            }
            w.write("label \"" + mappedLabel + "\"" + endl);
            w.write("]" + endl);
        }

        for (Edge<NL, EL> e : g.edges()) {
            w.write("edge [" + endl);
            w.write("source " + e.getFirstNode().getIndex() + endl);
            w.write("target " + e.getSecondNode().getIndex() + endl);
            String mappedLabel;
            if (edgeLabelMap == null) {
                mappedLabel = e.getLabel().toString();
            } else {
                mappedLabel = edgeLabelMap.get(e.getLabel());
                if (mappedLabel == null) {
                    mappedLabel = e.getLabel().toString();
                }
            }
            w.write("label \"" + mappedLabel + "\"" + endl);
            w.write("]" + endl);
        }

        w.write("]" + endl);
    }

    /**
     * Writes a single {@link Graph} in simplified SDF Format. Simplified means,
     * that only the graphs structure is covered, but no chemical informations are
     * given. The labels, etc must not match any chemical meaning.
     * 
     * @param w
     *            the {@link Writer}
     * @param g
     *            the {@link Graph} to write. Note that the toString of each node
     *            must return a string of length <=3.
     * @param name
     *            the name of the graph (no special characters are allowed;
     *            unchecked)
     * @param elMap
     *            only numerical bond types are supported in V2000. Therefore a map
     *            must be given, that maps each edge label to a unique number
     * @throws IOException
     */
    public static <NL, EL, G extends Graph<NL, EL>> void writeSDFGraph(Writer w, G g, String name,
            Map<EL, Integer> elMap) throws IOException {
        Preconditions.checkArgument(g.getNodeCount() <= 255, "V2000 SDF only supports 255 atoms/vertices max");
        Preconditions.checkArgument(g.getEdgeCount() <= 255, "V2000 SDF only supports 255 bonds/edges max");
        for (Node<NL, EL> node : g.nodes()) {
            Preconditions.checkArgument(node.getLabel().toString().length() <= 3, "to many node labels");
        }
        List<? extends Edge<NL, EL>> edges = g.edges();
        for (Edge<NL, EL> edge : edges) {
            Preconditions.checkArgument(elMap.containsKey(edge.getLabel()), "edge label mapping incommplete");
            Preconditions.checkArgument(elMap.get(edge.getLabel()).toString().length() <= 3, "to high edge label id");
        }
        Preconditions.checkArgument(StringUtils.isAlphanumeric(name), "name must be alphanumeric");

        w.write(name + endl);
        w.write(endl); // we give no information about the writer
        w.write(endl); // no comment

        // counts line
        w.write(String.format("% 3d", g.getNodeCount()));
        w.write(String.format("% 3d", g.getEdgeCount()));
        w.write(String.format("% 3d", 0)); // # atom lists
        w.write(String.format("% 3d", 0)); // obsolete
        w.write(String.format("% 3d", 0)); // chiral flag
        w.write(String.format("% 3d", 0)); // # stext entries
        w.write("   "); // obsolete
        w.write("   "); // obsolete
        w.write("   "); // obsolete
        w.write("   "); // obsolete
        w.write(String.format("% 3d", 0)); // # properties
        w.write(endl);

        // vertices
        List<? extends Node<NL, EL>> nodes = new LinkedList<>(g.nodes());
        java.util.Collections.sort(nodes,
                (Node<NL, EL> n1, Node<NL, EL> n2) -> Integer.compare(n1.getIndex(), n2.getIndex()));
        for (Node<NL, EL> node : nodes) {
            w.write("00000.0000"); // x coordinate
            w.write("00000.0000"); // y coordinate
            w.write("00000.0000"); // z coordinate
            w.write(" ");

            w.write(String.format(StringUtils.rightPad(node.getLabel().toString(), 3))); // Label
            w.write(" 0  0  0  0  0  0  0  0  0  0  0  0"); // no chemical
                                                            // properties
            w.write(endl);
        }

        // edges
        for (Edge<NL, EL> edge : edges) {
            // first node id
            w.write(String.format("% 3d", edge.getFirstNode().getIndex() + 1));
            // second node id
            w.write(String.format("% 3d", edge.getSecondNode().getIndex() + 1));
            // bond type / label
            w.write(String.format("% 3d", elMap.get(edge.getLabel())));
            w.write("  0  0  0  0"); // no chemical properties
            w.write(endl);
        }

        w.write("M  END" + endl); // end connection table
        w.write(endl);
        w.write("$$$$" + endl); // end sdf

    }

    /**
     * Writes a collection of {@link Graph}s in simplified SDF Format. Simplified
     * means, that only the graphs structure is covered, but no chemical
     * informations are given. The labels, etc must not match any chemical meaning.
     * 
     * @param w
     *            the {@link Writer}
     * @param graphs
     *            the {@link Graph}s to write. Note that the toString of each node
     *            and edge must return a string of length <=3.
     * @param nameMap
     *            maps each graph to a name
     * @param edgeLabelMap
     *            maps each edge label to a integer value
     * @throws IOException
     */
    public static <NL, EL, G extends Graph<NL, EL>> void writeSDFGraphs(Writer w, Collection<? extends G> graphs,
            Map<? extends G, String> nameMap, Map<EL, Integer> edgeLabelMap) throws IOException {
        for (G g : graphs) {
            writeSDFGraph(w, g, nameMap.get(g), edgeLabelMap);
        }
    }

    /**
     * Writes a collection of {@link Graph}s in simplified SDF Format. Simplified
     * means, that only the graphs structure is covered, but no chemical
     * informations are given. The labels, etc must not match any chemical meaning.
     * 
     * This methods automatically creates an edgeLabelMapping and a unique name for
     * each graph and calls {@link #writeSDFGraph(Writer, Graph, String, Map)}
     * 
     * @param w
     *            the {@link Writer}
     * @param graphs
     *            the {@link Graph}s to write. Note that the toString of each node
     *            and edge must return a string of length <=3.
     * @throws IOException
     */
    public static <NL, EL, G extends Graph<NL, EL>> void writeSDFGraphs(Writer w, Collection<? extends G> graphs)
            throws IOException {
        HashMap<EL, Integer> elMap = Graphs.getIntegerEdgeLabelMap(graphs, 1);
        HashMap<G, String> gnMap = new HashMap<>(graphs.size());

        int id = 0;
        for (G g : graphs) {
            gnMap.put(g, String.valueOf(id++));
        }

        writeSDFGraphs(w, graphs, gnMap, elMap);
    }

    /**
     * Writes a {@link Collection} of clusters in a custom GML format.
     * 
     * @param w
     *            the {@link Writer}
     * @param clusters
     *            the {@link Cluster}s to write
     * @throws IOException
     */
    public static <NL, EL, G extends Graph<NL, EL>> void writeClustersGML(Writer w,
            Collection<Cluster<NL, EL, G>> clusters) throws IOException {
        writeClustersGML(w, clusters, null, null);
    }

    /**
     * Writes a {@link Collection} of clusters in a custom GML format.
     * 
     * @param w
     *            the {@link Writer}
     * @param clusters
     *            the {@link Cluster}s to write
     * @param nodeLabelMap
     *            if not null, the node labels of the graph are replaced with the
     *            string values contained in this map. if a mapping is undefined for
     *            a label, the original label is written.
     * @param edgeLabelMap
     *            if not null, the edge labels of the graph are replaced with the
     *            string values contained in this map. if a mapping is undefined for
     *            a label, the original label is written.
     * @throws IOException
     */
    public static <NL, EL, G extends Graph<NL, EL>> void writeClustersGML(Writer w,
            Collection<Cluster<NL, EL, G>> clusters, Map<NL, String> nodeLabelMap, Map<EL, String> edgeLabelMap)
            throws IOException {
        // clusters
        for (Cluster<NL, EL, G> cluster : clusters) {
            w.write("cluster [" + endl);
            w.write("id " + cluster.getId() + endl);
            w.write("size " + cluster.size() + endl);

            // representatives
            w.write("representatives [" + endl);
            for (GraphContainer<NL, EL, G> g : cluster.getRepresentatives()) {
                writeGMLGraph(w, g, nodeLabelMap, edgeLabelMap);
            }
            w.write("]" + endl);

            // members
            w.write("members [" + endl);
            for (GraphContainer<NL, EL, G> g : cluster) {
                writeGMLGraph(w, g, nodeLabelMap, edgeLabelMap);
            }
            w.write("]" + endl);

            // closing cluster block
            w.write("]" + endl);
        }
    }

    /**
     * Writes a {@link Collection} of clusters in a custom protein sequence format.
     * 
     * Attention: the nodes need to have the name property set.
     * 
     * @param w
     *            the {@link Writer}
     * @param clusters
     *            the {@link Cluster}s to write
     * @throws IOException
     */
    public static <NL, EL, G extends Graph<NL, EL>> void writeClustersProteinSeq(Writer w,
            Collection<Cluster<NL, EL, G>> clusters) throws IOException {
        int clusterID = 0;
        for (Cluster<NL, EL, G> cluster : clusters) {
            HashMap<String, CountingInt> orgClusterIdCouting = new HashMap<>();
            for (GraphContainer<NL, EL, G> gc : cluster) {
                String orgClusterID = gc.getProperty("orgClusterID");
                if (orgClusterID == null) {
                    orgClusterID = "unset";
                }
                CountingInt.incrementCount(orgClusterIdCouting, orgClusterID);
            }

            w.write("---------------- ");
            w.write("Cluster " + Integer.toString(clusterID));
            w.write(" ----------------");
            w.write(endl);

            w.write(endl);
            w.write("--- Representatives: ---");
            w.write(endl);

            for (GraphContainer<NL, EL, G> rep : cluster.getRepresentatives()) {
                w.write(Graphs.getPathLabelSequence(rep, false) + endl);
            }

            w.write(endl);
            w.write("--- original cluster memberships (class : count): ---");
            w.write(endl);
            for (Entry<String, CountingInt> entry : orgClusterIdCouting.entrySet()) {
                w.write(entry.getKey() + " : " + entry.getValue() + endl);
            }

            w.write(endl);
            w.write("--- Members: ---");
            w.write(endl);

            for (GraphContainer<NL, EL, G> member : cluster) {
                String name = member.getProperty("name");
                if (name == null) {
                    throw new IllegalArgumentException("name property not present");
                }
                w.write(name);
                w.write(endl);
            }
            w.write(endl);

            clusterID++;
        }
    }

    /**
     * parses the an node id string value and returns the associated node from the
     * given graph.
     * 
     * @param graph
     *            graph to select the node from
     * @param idMapping
     *            the mapiing from gml id to node index in the graph
     * @param value
     *            the string value of the gml id
     * @return
     * @throws IOException
     *             if the node id is not parsable or the id is not contained in the
     *             id mapping
     */
    private static final Node<String, String> getNodeByStringId(
            GraphContainer<String, String, DefaultGraph<String, String>> graph, ArrayList<Integer> idMapping,
            String value) throws IOException {
        Integer intVal = Integer.valueOf(value);
        if (intVal >= idMapping.size()) {
            throw new IOException("File format inconsistency: node id out of range");
        }
        Integer nodeIndex = idMapping.get(intVal);
        if (nodeIndex == null) {
            throw new IOException("File format incosnsitency: node id not avaulable");
        }
        return graph.getNode(nodeIndex);
    }

    private static final void addIdMapping(Integer gmlId, int vertexIndex, ArrayList<Integer> idMapping) {
        while (idMapping.size() <= gmlId) {
            idMapping.add(null);
        }
        idMapping.set(gmlId, vertexIndex);

        assert noDuplicateIds(idMapping) : "Multiple nodes with the same ID detected";
    }

    private static final boolean noDuplicateIds(ArrayList<Integer> idMapping) {
        List<Integer> filteredUnsetValues = idMapping.stream().filter(i -> i != null).collect(Collectors.toList());
        long uniqIds = new HashSet<>(filteredUnsetValues).size();
        int idCount = filteredUnsetValues.size();
        return uniqIds == idCount;
    }

    /**
     * remove possible quoting chars \"
     * 
     * @param str
     *            possibly quoted input string
     * @return input without quotes
     */
    private static final String unquotedString(String str) {
        return str.replaceAll("^\"|\"$", "");
    }

    /**
     * Splits a {@link String} by spaces, but preserves quotes substrings.
     * 
     * @param str
     * @return the splitted {@link String}
     */
    private static final String[] quotedSplit(String str) {

        List<String> list = new ArrayList<>();
        Matcher m = Pattern.compile("([^\"]\\S*|\".+?\")\\s*").matcher(str);
        while (m.find())
            list.add(m.group(1));

        String[] retVal = new String[list.size()];
        return list.toArray(retVal);
    }

    private static final boolean blockEnd(String line) {
        return line.equals("]");
    }

    private static final boolean emptyLine(String line) {
        return line.equals("");
    }

    private static final boolean commentLine(String line) {
        return line.startsWith("#");
    }

    /**
     * Reads one line from a {@link BufferedReader}, trims it and replaces
     * successive blanks by a single blank, i.e. words a separated by single blanks.
     * 
     * @param r
     *            the {@link BufferedReader}
     * @return a trimmed line without double blanks
     * @throws IOException
     */
    private static String normalizedGmlLine(BufferedReader r) throws IOException {
        String s = r.readLine();
        return (s == null) ? s : s.trim().replaceAll("\\s+", " ");
    }

    /**
     * {@link Callable} to create a {@link GraphContainer} with a MoleculeGraph out
     * of a {@link IAtomContainer}
     * 
     * @author Till Schäfer
     */
    private static class MoleculeGraphCreator implements Callable<GraphContainer<String, String, MoleculeGraph>> {

        private IAtomContainer mol;
        private boolean configure;
        private boolean stripCDKRefs;
        private Set<String> propNames;

        /**
         * Constructor
         * 
         * @param mol
         *            the molecule in form of {@link IAtomContainer}
         * @param configure
         *            whether the molecule should be configured. e.g. adding of
         *            aromaticity information.
         * @param stripCDKRefs
         *            if true, the references to the {@link IAtomContainer} are removed
         *            for memory optimization.
         * @param propNames
         *            the property names that should be attaches as metadata
         */
        public MoleculeGraphCreator(IAtomContainer mol, boolean configure, boolean stripCDKRefs,
                Set<String> propNames) {
            this.mol = mol;
            this.configure = configure;
            this.stripCDKRefs = stripCDKRefs;
            this.propNames = propNames;
        }

        @Override
        public GraphContainer<String, String, MoleculeGraph> call() throws Exception {
            MoleculeGraph g = new MoleculeGraph(mol, configure);
            if (stripCDKRefs) {
                g.stripCDKReference();
            }

            GraphContainer<String, String, MoleculeGraph> gc = new GraphContainer<>(g);
            for (String propName : propNames) {
                String propVal = mol.getProperty(propName);
                if (propVal != null) {
                    gc.putProperty(propName, propVal);
                }
            }

            return gc;
        }
    }

    /**
     * {@link Callable} to create a SMILES String out of an {@link IAtomContainer}
     * 
     * @author Till Schäfer
     */
    private static class SmilesCreator implements Callable<String> {

        private IAtomContainer mol;

        /**
         * Constructor
         * 
         * @param mol
         *            the molecule in form of {@link IAtomContainer}
         */
        public SmilesCreator(IAtomContainer mol) {
            this.mol = mol;
        }

        @Override
        public String call() throws Exception {
            String smiles = "";
            try {
                AtomContainerManipulator.percieveAtomTypesAndConfigureAtoms(mol);
                smiles = CanonicalSmilesGenerator.createSMILES(mol, true, false);
            } catch (Exception e) {
                logger.warn("Smiles generateion failed. Returning empty string!", e);
            }
            return smiles;
        }
    }
}
