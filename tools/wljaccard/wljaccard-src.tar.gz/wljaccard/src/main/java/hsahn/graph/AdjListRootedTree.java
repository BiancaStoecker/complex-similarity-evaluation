package hsahn.graph;

import java.util.ArrayList;

/**
 * Note: Use createRoot()/createChild() instead of createVertex()/createEdge() to 
 * assure consistency!
 */
public class AdjListRootedTree extends AdjListGraph implements RootedTree {
	
	AdjListRTreeVertex root;
	
	public AdjListRootedTree() {
		super();
	}

	public AdjListRootedTree(int n) {
		super(n, n-1);
	}

	@Override
    public AdjListRTreeVertex getRoot() {
		return root;
	}
	
	public void setRoot(AdjListRTreeVertex root) {
		this.root = root;
	}

	@Override
    public AdjListRTreeVertex createVertex() {
		AdjListRTreeVertex v = new AdjListRTreeVertex(vertices.size());
		vertices.add(v);
		
		notifyVertexCreated(v);
		return v;
	}
	
	public AdjListRTreeVertex createRoot() {
		if (root != null) throw new RuntimeException("Root already exists");
		root = createVertex();
		return root;
	}
	
	public AdjListRTreeVertex createChild(AdjListRTreeVertex p) {
		AdjListRTreeVertex c = createVertex();
		c.setTreeParent(p);
		createEdge(p, c);
		return c;
	}
	
	// TODO make superclass generic and remove this
	@Override
    public AdjListRTreeVertex getVertex(int index) {
		return (AdjListRTreeVertex)vertices.get(index);
	}
	
	public class AdjListRTreeVertex extends AdjListVertex implements TreeVertex {
		
		AdjListRTreeVertex parent;
		ArrayList<AdjListRTreeVertex> children;
		
		public AdjListRTreeVertex(int index) {
			super(index);
		}
		
		public AdjListRTreeVertex(int index, AdjListRTreeVertex parent) {
			this(index);
			this.parent = parent;
		}

		@Override
        public AdjListRTreeVertex getTreeParent() {
			return parent;
		}
		
		public void setTreeParent(AdjListRTreeVertex parent) {
			this.parent = parent;
		}

		@Override
        public ArrayList<AdjListRTreeVertex> treeChildren() {
			return children;
		}
		
		// TODO make superclass generic and remove this
		@Override
        public Iterable<AdjListRTreeVertex> neighbors() {
			return ImplementationHelper.createNeighborIterator(this);
		}
		
	}

}
