package hsahn.datastructure;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;

/**
 * HashMap based implementation of a feature vector.
 * 
 * @author kriege
 *
 * @param <T>
 */
public class SparseFeatureVector<T> implements FeatureVector<T> {

    // TODO use mutable integer!
    protected Object2LongOpenHashMap<T> map;

    /**
     * Constructor
     */
    public SparseFeatureVector() {
        this.map = new Object2LongOpenHashMap<>();
    }

    /**
     * Constructor
     * 
     * @param featureMap
     *            map from features to counts. Counts must be whole numbers and must
     *            fit in a long.
     */
    public SparseFeatureVector(Map<T, ? extends Number> featureMap) {
        this.map = new Object2LongOpenHashMap<>(featureMap.size());

        for (Entry<T, ? extends Number> e : featureMap.entrySet()) {
            Number count = e.getValue();
            if (count.longValue() == count.doubleValue()) {
                map.put(e.getKey(), count.longValue());
            } else {
                throw new IllegalArgumentException("feature map contains non whole number");
            }
        }
    }

    // TODO it would be more efficient to use a mutable integer!
    @Override
    public void increaseCount(T feature, long p) {
        long i = getCount(feature);
        i += p;
        map.put(feature, i);
    }

    @Override
    public void increaseCount(T feature) {
        increaseCount(feature, 1);
    }

    @Override
    public void decreaseCount(T feature) {
        increaseCount(feature, -1);
    }

    @Override
    public long getCount(T feature) {
        return map.getLong(feature);
    }

    @Override
    public long innerProduct(FeatureVector<T> v) {
        FeatureVector<T> u = this;
        if (v.size() < this.size()) {
            // swap
            u = v;
            v = this;
        }

        long i = 0;

        for (Map.Entry<T, Long> e : u.positiveEntries()) {
            i += e.getValue() * v.getCount(e.getKey());
        }

        return i;
    }

    @Override
    public void add(FeatureVector<T> v) {
        for (Entry<T, Long> e : v.positiveEntries()) {
            increaseCount(e.getKey(), e.getValue());
        }
    }

    @Override
    public long size() {
        return map.size();
    }

    @Override
    public String toString() {
        return map.toString();
    }

    /**
     * {@inheritDoc}
     * 
     * Note: Do not modify this collection!
     */
    @Override
    public Collection<T> positiveFeatures() {
        return map.keySet();
    }

    /**
     * {@inheritDoc}
     * 
     * Note: Do not modify this collection!
     */
    @SuppressWarnings("deprecation")
    @Override
    public Set<Entry<T, Long>> positiveEntries() {
        return map.entrySet();
    }

    /**
     * Note: Do not modify this collection!
     * 
     * @return the feature map
     */
    public Map<T, Long> featureMap() {
        return map;
    }

    @Override
    public boolean allZero(Collection<T> features) {
        for (T f : features) {
            if (getCount(f) != 0)
                return false;
        }
        return true;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o instanceof SparseFeatureVector) {
            return positiveEntries().equals(((SparseFeatureVector) o).positiveEntries());
        }
        return false;
    }

    @Override
    public int hashCode() {
        return map.hashCode();
    }
}
