package hsahn.graph.properties;

import hsahn.graph.ExtendibleGraph;
import hsahn.graph.Graph;
import hsahn.graph.Graph.Edge;

public class EdgeArray<T> extends GraphArray<Edge, T> implements EdgeProperty<T> {
	
	public EdgeArray(Graph g) {
		super(g);
		assureAdjustment(g);
	}
	
	public EdgeArray(Graph g, int n) {
		super(g, n);
		assureAdjustment(g);
	}
	
	public EdgeArray(EdgeArray<T> ea) {
		super(ea);
		assureAdjustment(g);
	}

	@Override
    protected void assureCapacity() {
		assureCapacity(((ExtendibleGraph)g).getNextEdgeIndex());
	}
	
	private void assureAdjustment(Graph g) {
		if (g instanceof ExtendibleGraph) {
			((ExtendibleGraph)g).addEdgeObserver(this);
		}
	}
}
