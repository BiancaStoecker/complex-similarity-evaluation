package hsahn.algorithm.graph.vectorization;

import hsahn.concepts.Transformation;
import hsahn.datastructure.SparseFeatureVector;
import hsahn.graph.Graph;
import hsahn.graph.Graph.Vertex;
import hsahn.graph.LGraph;
import hsahn.graph.properties.VertexArray;

/**
 * Computes a feature vector for a given graph counting the occurrences of 
 * vertex labels.
 * 
 * @author kriege
 * @param <V> vertex label type
 */
public class VertexVectorizer<V> implements Transformation<LGraph<V,?>, SparseFeatureVector<V>> {

	@Override
    public SparseFeatureVector<V> transform(LGraph<V,?> in) {
		Graph g = in.getGraph();
		VertexArray<V> va = in.getVertexLabel();
		
		SparseFeatureVector<V> r = new SparseFeatureVector<V>();
		
		for (Vertex v : g.vertices()) {
			r.increaseCount(va.get(v));
		}
		
		return r;
	}
	
}

