package hsahn.graph.properties;

import hsahn.graph.ExtendibleGraph;
import hsahn.graph.Graph;
import hsahn.graph.Graph.Vertex;


public class VertexArray<T> extends GraphArray<Vertex, T> implements VertexProperty<T> {
	
	public VertexArray(Graph g, boolean grow) {
		super(g);
		if (grow) assureAdjustment(g);
	}

	public VertexArray(Graph g) {
		super(g);
		assureAdjustment(g);
	}
	
	public VertexArray(Graph g, int n) {
		super(g, n);
		assureAdjustment(g);
	}
	
	public VertexArray(VertexArray<T> va) {
		super(va);
		assureAdjustment(g);
	}
	
	@Override
    protected void assureCapacity() {
		if (g instanceof ExtendibleGraph)
			assureCapacity(((ExtendibleGraph)g).getNextVertexIndex());
		else
			assureCapacity(g.getVertexCount());
	}
	
	private void assureAdjustment(Graph g) {
		if (g instanceof ExtendibleGraph) {
			((ExtendibleGraph)g).addVertexObserver(this);
		}
	}
}
