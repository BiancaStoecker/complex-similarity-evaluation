package hsahn.datastructure;

import java.util.Collection;
import java.util.Map.Entry;
import java.util.Set;

public interface FeatureVector<T> {
	
	public long getCount(T feature);
	public void increaseCount(T feature, long p);
	public void increaseCount(T feature);
	public void decreaseCount(T feature);
	public long size();
	public long innerProduct(FeatureVector<T> v);
	
	/**
	 * Returns the set of features with a positive count.
	 */
	public Collection<T> positiveFeatures();
	
	/**
	 * Returns the set of entries with a positive count.
	 */
	public Set<Entry<T, Long>> positiveEntries();

	/**
	 * Adds the given vector.
	 */
	public void add(FeatureVector<T> v);
	
	public boolean allZero(Collection<T> features);

}
