package hsahn.graph;

import hsahn.graph.properties.EdgeArray;
import hsahn.graph.properties.VertexArray;

/**
 * Stores a graph together with its vertex and edge labels.
 * 
 * @author kriege
 *
 * @param <V> vertex label type
 * @param <E> edge label type
 */
// TODO use this class instead of ugly pairs!
// TODO remove ill-designed ElementArray & co
// TODO remove this class and Graph.getProperty("vertexLabel")?
public class LGraph<V,E> extends AbstractLGraph<Graph, V, E>{

	public LGraph(Graph graph, VertexArray<V> vertexLabel,EdgeArray<E> edgeLabel) {
		super(graph, vertexLabel, edgeLabel);
	}

}
