package hsahn.algorithm.graph.isomorphism.labelrefinement;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.math3.util.Pair;

import hsahn.graph.Graph;
import hsahn.graph.Graph.Vertex;
import hsahn.graph.LGraph;
import hsahn.graph.properties.VertexArray;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;

/**
 * Converts the vertex labels of a graph to integers in {0, ..., n}. An object
 * of this class can be used to subsequently process multiple graphs, internally
 * building a 1:1 mapping of vertex labels occurring in the set of graphs and
 * new integer labels. This map can be cleared manually if required.
 * 
 * @see #clearLabelMap()
 * 
 * @author kriege
 * @author Till Schäfer
 * 
 * @param <IE>
 *            edge label type of the input graph, which is preserved by the
 *            refinement step
 */
public class VertexLabelConverter<IE> extends VertexLabelRefiner<IE, LGraph<?, IE>, Integer> {

    private int offset;
    private HashMap<Pair<Integer, Object>, Integer> labelMap;
    private int iteration = 0;

    /**
     * Constructor
     */
    public VertexLabelConverter() {
        this(0);
    }

    /**
     * Constructor
     * 
     * Creates a new vertex label converter with an initial empty mapping.
     * 
     * @param offset
     *            the vertex label assign to the first unseen vertex.
     */
    public VertexLabelConverter(int offset) {
        labelMap = new HashMap<>();
        this.offset = offset;
    }

    @Override
    public VertexArray<Integer> vertexRefine(LGraph<?, IE> lg) {
        Graph g = lg.getGraph();
        VertexArray<?> va = lg.getVertexLabel();

        VertexArray<Integer> vaRefined = new VertexArray<>(g);
        for (Vertex v : g.vertices()) {
            Object label = va.get(v);
            Integer newLabel = labelMap.get(Pair.create(iteration, label));
            if (newLabel == null) {
                newLabel = getNextLabel();
                labelMap.put(Pair.create(iteration, label), newLabel);
            }
            vaRefined.set(v, newLabel);
        }

        return vaRefined;
    }

    /**
     * Return the label map. A map entry has the form: <br>
     * <tt>Entry&lt;Pair&lt;Iteration, Label&gt;, newLabel&gt;</tt>
     * 
     * @return the label map
     */
    public HashMap<Pair<Integer, Object>, Integer> getLabelMap() {
        return labelMap;
    }

    /**
     * Return all converted (i.e., the integers) labels
     * 
     * @return the labels
     */
    public Collection<Integer> getLabels() {
        return labelMap.values();
    }

    /**
     * Return all converted (i.e., the integers) labels of iteration iter
     * 
     * @param iter
     *            the iteration to return the labels for
     * 
     * @return the labels
     */
    public Set<Integer> getLabels(int iter) {
        Set<Integer> retVal = new IntOpenHashSet();
        
        for (Entry<Pair<Integer, Object>, Integer> e : labelMap.entrySet()) {
            if (e.getKey().getKey().equals(iter)) {
                retVal.add(e.getValue());
            }
        }
        
        return retVal;
    }

    /**
     * Clears the current vertex label mapping.
     */
    public void clearLabelMap() {
        offset = getNextLabel();
        labelMap.clear();
    }

    /**
     * @return the integer label that will be assigned to the next unseen vertex
     *         label.
     */
    public int getNextLabel() {
        return labelMap.size() + offset;
    }

    /**
     * @return the iteration
     */
    public int getIteration() {
        return iteration;
    }

    /**
     * @param iteration
     *            the iteration to set
     */
    public void setIteration(int iteration) {
        this.iteration = iteration;
    }

}
