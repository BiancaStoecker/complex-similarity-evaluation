package hsahn.concepts;

import java.util.ArrayList;
import java.util.Collection;


/**
 * Provides convenient methods to apply transformations to collections.
 * 
 * @author kriege
 *
 */
public class TransformationTools {
	
	/**
	 * Transforms the objects in the given set by the specified transformation.
	 * @param <I> input object type
	 * @param <O> output object type
	 * @param trans
	 * @param set
	 * @return
	 */
	public static <I,O> ArrayList<O> transformAll(Transformation<? super I,O> trans, Collection<I> set) {
		ArrayList<O> transformedSet = new ArrayList<O>(set.size());
		for (I element : set) {
			transformedSet.add(trans.transform(element));
		}
		return transformedSet;
	}
}
