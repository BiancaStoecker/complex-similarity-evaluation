package hsahn.comparison.kernel;

import java.util.ArrayList;
import java.util.List;

/**
 * Interface for kernels allowing explicit mapping into feature space.
 *  
 * @author kriege
 *
 * @param <I> type of objects under comparison
 * @param <O> type of the feature representation
 */
public interface ExplicitMappingKernel<I,O> {
	
	/**
	 * Computes the explicit mapping associated with a kernel for a set of graphs.
	 * @param o set of graphs
	 * @return a feature representation for each graph
	 * @throws IllegalStateException if explicit mapping is not allowed with current state of the kernel 
	 */
	public ArrayList<O> computeExplicitMapping(List<? extends I> o) throws IllegalStateException;

}
