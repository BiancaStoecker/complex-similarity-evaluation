package hsahn.comparison.kernel.graph;

import java.util.ArrayList;
import java.util.List;

import hsahn.algorithm.graph.vectorization.VertexVectorizer;
import hsahn.comparison.kernel.ExplicitMappingKernel;
import hsahn.comparison.kernel.Kernel;
import hsahn.comparison.kernel.basic.DiracKernel;
import hsahn.concepts.TransformationTools;
import hsahn.datastructure.SparseFeatureVector;
import hsahn.graph.Graph;
import hsahn.graph.Graph.Vertex;
import hsahn.graph.LGraph;
import hsahn.graph.properties.VertexArray;

/**
 * Compares two graphs by comparing their vertex labels.
 * 
 * @author kriege
 *
 * @param <V> vertex label type
 * @param <E> edge label type; note that edge labels are completely ignored by this kernel
 */
public class VertexKernel<V, E> implements 
	Kernel<LGraph<V, E>>, 
	ExplicitMappingKernel<LGraph<V, E>, SparseFeatureVector<V>>
{
	
	Kernel<? super V> vertexKernel;
	
	public VertexKernel(Kernel<? super V> vertexKernel) {
		this.vertexKernel = vertexKernel;
	}
	
	@Override
    public double compute(LGraph<V, E> lg1, LGraph<V, E> lg2) {
		Graph g1 = lg1.getGraph();
		VertexArray<V> va1 = lg1.getVertexLabel();
		Graph g2 = lg2.getGraph();
		VertexArray<V> va2 = lg2.getVertexLabel(); 

		double k = 0;
		
		for (Vertex v1 : g1.vertices()) {
			V l1 = va1.get(v1);
			for (Vertex v2 : g2.vertices()) {
				V l2 = va2.get(v2);
				k += vertexKernel.compute(l1, l2);
			}
		}

		return k;
	}

	@Override
    public ArrayList<SparseFeatureVector<V>> computeExplicitMapping(List<? extends LGraph<V, E>> graphs) {
		if (!(vertexKernel instanceof DiracKernel)) {
			throw new IllegalStateException("Explicit mapping requires the vertex kernel to be a dirac kernel!");
		}
		
		VertexVectorizer<V> vlv = new VertexVectorizer<>();
		
		return TransformationTools.transformAll(vlv, graphs);
	}
	
	@Override
    public String getID() {
		return "V_"+vertexKernel.getID();
	}

}
