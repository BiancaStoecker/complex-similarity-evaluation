package graph;

import java.util.HashMap;

import org.openscience.cdk.aromaticity.Aromaticity;
import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IBond;
import org.openscience.cdk.tools.manipulator.AtomContainerManipulator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A Graph that is constructed form an {@link IAtomContainer}. Using the atoms
 * as {@link Node}s and the bonds as edges. <br>
 * <br>
 * <strong>Attention:</strong> the cdk reference is not serialized!
 * 
 * @author Nils Kriege
 */
public class MoleculeGraph extends DefaultGraph<String, String> {
    private static final long serialVersionUID = 6850801220175285099L;
    private static final Logger logger = LoggerFactory.getLogger(MoleculeGraph.class);

    // FIXME: IAtomContainer can be out of sync with the graph structure
    transient IAtomContainer atomContainer;
    transient HashMap<IAtom, MoleculeNode> atomToNode;

    /**
     * Constructor
     */
    public MoleculeGraph() {

    }

    /**
     * Constructor.
     * 
     * @param atomContainer
     *            the {@link IAtomContainer} from which the {@link Graph} should
     *            be created.
     */
    public MoleculeGraph(IAtomContainer atomContainer) {
        this(atomContainer, false);
    }

    /**
     * Constructor.
     * 
     * @param atomContainer
     *            the {@link IAtomContainer} from which the {@link Graph} should
     *            be created.
     * @param detectAromaticity
     *            if true aromaticity is detected as preprocessing step
     */
    public MoleculeGraph(IAtomContainer atomContainer, boolean detectAromaticity) {
        super(atomContainer.getAtomCount());

        if (detectAromaticity) {
            try {
                AtomContainerManipulator.percieveAtomTypesAndConfigureAtoms(atomContainer);
                Aromaticity.cdkLegacy().apply(atomContainer);
            } catch (CDKException ex) {
                logger.error("aromaticity detection failed", ex);
                throw new IllegalStateException(ex);
            }
        }

        atomToNode = new HashMap<>();
        this.atomContainer = atomContainer;

        for (IAtom atom : atomContainer.atoms()) {
            MoleculeNode node = new MoleculeNode(atom, nodes.size());
            nodes.add(node);
            atomToNode.put(atom, node);
        }

        for (IBond bond : atomContainer.bonds()) {
            assert (bond.getAtomCount() == 2);
            MoleculeNode u = atomToNode.get(bond.getAtom(0));
            MoleculeNode v = atomToNode.get(bond.getAtom(1));

            addEdge(new MoleculeEdge(u, v, bond));
        }
    }

    /**
     * Constructor.
     * 
     * @param atomContainer
     *            the {@link IAtomContainer} from which the {@link Graph} should
     *            be created.
     * @param detectAromaticity
     *            if true aromaticity is detected as preprocessing step
     * @param stripCDKReference
     *            if true the reference to the {@link IAtomContainer} is not
     *            kept.
     */
    public MoleculeGraph(IAtomContainer atomContainer, boolean detectAromaticity, boolean stripCDKReference) {
        this(atomContainer, detectAromaticity);
        stripCDKReference();
    }

    @Override
    public MoleculeNode addNode(String label) {
        MoleculeNode node = new MoleculeNode(label, nodes.size());
        nodes.add(node);
        return node;
    }

    @Override
    public MoleculeGraph clone() {
        MoleculeGraph mg = new MoleculeGraph();
        HashMap<DefaultNode<String, String>, MoleculeNode> nodeMapping = new HashMap<>();

        if (getAtomContainer() != null) {
            try {
                mg.atomContainer = atomContainer.clone();
            } catch (CloneNotSupportedException e) {
                logger.error("Not Possible", e);
            }
        }

        // node cloning
        for (int i = 0; i < nodes.size(); i++) {
            MoleculeNode node = (MoleculeNode) nodes.get(i);
            MoleculeNode clone = mg.addNode(node.getLabel());
            clone.atom = node.atom;
            nodeMapping.put(node, clone);
        }

        // atom to node cloning
        if (getAtomContainer() != null) {
            for (int i = 0; i < getAtomContainer().getAtomCount(); i++) {
                IAtom atom = atomContainer.getAtom(i);
                MoleculeNode atomNode = atomToNode.get(atom);
                IAtom mgAtom = mg.atomContainer.getAtom(i);
                MoleculeNode mgAtomNode = nodeMapping.get(atomNode);
                mg.atomToNode.put(mgAtom, mgAtomNode);
            }
        }

        // edge cloning
        for (DefaultEdge<String, String> e : edges()) {
            DefaultNode<String, String> u = mg.getNode(e.getFirstNode().getIndex());
            DefaultNode<String, String> v = mg.getNode(e.getSecondNode().getIndex());
            MoleculeEdge clone = mg.addEdge(u, v, e.getLabel());
            clone.bond = ((MoleculeEdge) e).bond;
        }

        return mg;
    }

    @Override
    public MoleculeEdge addEdge(Node<String, String> u, Node<String, String> v, String label) {
        assertValidNodeParameter(u);
        assertValidNodeParameter(v);

        MoleculeEdge edge = new MoleculeEdge(u, v, label);
        u.addEdge(edge);
        v.addEdge(edge);
        edgeCount++;
        return edge;
    }

    @Override
    protected void assertValidNodeParameter(Node<String, String> u) {
        assert u instanceof MoleculeNode;
        assert nodes.get(u.getIndex()) == u;
    }

    /**
     * Returns the underlying {@link IAtomContainer} of this graph
     * 
     * @return the underlying {@link IAtomContainer}
     */
    public IAtomContainer getAtomContainer() {
        return atomContainer;
    }

    /**
     * Returns the node representing the given {@link IAtom}.
     * 
     * @param atom
     *            atom of the underlying {@link IAtomContainer}
     * @return the representing {@link MoleculeNode} or null if there is no such
     *         mapping.
     */
    public MoleculeNode getNode(IAtom atom) {
        return atomToNode == null ? null : atomToNode.get(atom);
    }

    @Override
    public String toString() {
        return super.toString();// +"\nM="+getAtomContainer();
    }

    /**
     * Removes the reference to the {@link IAtomContainer}.
     */
    public void stripCDKReference() {
        atomContainer = null;
        atomToNode = null;
        for (DefaultNode<String, String> node : nodes) {
            ((MoleculeNode) node).stripIAtom();
        }
        for (DefaultEdge<String, String> edge : edges()) {
            ((MoleculeEdge) edge).stripIBond();
        }
    }

    /**
     * @param mg
     */
    public static void encodeRingStructure(MoleculeGraph mg) {
        for (Edge<String, String> e : mg.edges()) {
            if (!GraphUtil.isBridge(mg, e)) {
                e.setLabel(e.getLabel() + "R");
            }
        }
    }

}
