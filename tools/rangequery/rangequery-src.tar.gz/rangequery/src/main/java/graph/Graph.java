package graph;

import java.util.List;

import org.apache.commons.math3.util.Pair;

/**
 * Interface for undirected graphs.
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * 
 */
public interface Graph<NL, EL> {

    /**
     * Get all {@link Node}s
     * 
     * @return all {@link Node}s
     */
    public List<? extends Node<NL, EL>> nodes();

    /**
     * Get all {@link Edge}s
     * 
     * @return all {@link Edge}s
     */
    public List<? extends Edge<NL, EL>> edges();

    /**
     * Get the {@link Node} of the {@link Graph} with a defined index
     * 
     * @param index
     *            the index of the {@link Node}
     * @return the {@link Node} for the index
     */
    public Node<NL, EL> getNode(int index);

    /**
     * Get the count of all {@link Node}s
     * 
     * @return count of all {@link Node}s
     */
    public int getNodeCount();

    /**
     * Get the count of all {@link Edge}s
     * 
     * @return count of all {@link Edge}s
     */
    public int getEdgeCount();

    /**
     * @return the node + edge count
     */
    @Deprecated
    default public int size() {
        return getNodeCount() + getEdgeCount();
    }

    /**
     * Calculate the size of this graph. Size may differ regarding the counting
     * method s.
     * 
     * @param s
     *            the counting method for the graph size
     * @return the graphs size regarding s
     */
    default public int size(GraphSize s) {
        switch (s) {
        case nodes:
            return getNodeCount();
        case edges:
            return getEdgeCount();
        case nodesAndEdges:
            return getNodeCount() + getEdgeCount();
        default:
            throw new UnsupportedOperationException("Unknown Enum Type");
        }
    }

    /**
     * Returns whether an {@link Edge} between {@link Node} u and {@link Node} v
     * exists.
     * 
     * @param u
     *            the fist {@link Node}
     * @param v
     *            the second {@link Node}
     * @return whether the {@link Edge} between {@link Node} v and u exists
     */
    public boolean hasEdge(Node<NL, EL> u, Node<NL, EL> v);

    /**
     * Return the {@link Edge} between {@link Node} u and {@link Node} v.
     * 
     * @param u
     *            the fist {@link Node}
     * @param v
     *            the second {@link Node}
     * @return the {@link Edge} between {@link Node} v and u OR null if the edge
     *         does not exist
     */
    public Edge<NL, EL> getEdge(Node<NL, EL> u, Node<NL, EL> v);

    /**
     * Add a new {@link Node} with label
     * 
     * @param label
     *            the label
     * @return the newly created node
     */
    public Node<NL, EL> addNode(NL label);

    /**
     * Removes the Node and all its adjacent Edges from the Graph.
     * 
     * Attention: This will change the node indices. The note indices will be
     * always continuously.
     * 
     * @param u
     *            the node to remove
     */
    public void removeNode(Node<NL, EL> u);

    /**
     * Add a new {@link Edge} with label
     * 
     * @param u
     *            first node
     * @param v
     *            second node
     * @param label
     *            the label
     * @return the newly created edge
     */
    public Edge<NL, EL> addEdge(Node<NL, EL> u, Node<NL, EL> v, EL label);

    /**
     * Add a new {@link Edge} with label.
     * 
     * Note: this will also add the edge to its endpoints. Ensure this is not
     * done previously!
     * 
     * @param e
     *            the edge
     */
    public void addEdge(Edge<NL, EL> e);

    /**
     * Remove the edge from the Graph
     * 
     * @param e
     *            the edge to remove
     */
    public void removeEdge(Edge<NL, EL> e);

    /**
     * Add a {@link Graph}
     * 
     * @param g
     *            the graph
     * @return the added nodes and edges
     */
    Pair<? extends List<? extends Node<NL, EL>>, ? extends List<? extends Edge<NL, EL>>> addGraph(Graph<NL, EL> g);

    /**
     * For debugging purpose
     * 
     * @return if the indexing of the nodes is consistent (i.e. the index of the
     *         nodes are the same as in the nodes array position)
     */
    public boolean isIndexConsistent();
}
