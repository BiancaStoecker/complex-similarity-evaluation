package graph;

import java.io.Serializable;

/**
 * Default implementation of the {@link Edge} interface.
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * 
 */
public class DefaultEdge<NL, EL> implements Edge<NL, EL>, Serializable {

    private static final long serialVersionUID = 1L;
    EL label;
    DefaultNode<NL, EL> u, v;

    /**
     * Constructor
     * 
     * @param u
     *            the fist {@link Node}
     * @param v
     *            the second {@link Node}
     * @param label
     *            the label
     */
    public DefaultEdge(Node<NL, EL> u, Node<NL, EL> v, EL label) {
        assert u instanceof DefaultNode;
        assert v instanceof DefaultNode;

        this.u = (DefaultNode<NL, EL>) u;
        this.v = (DefaultNode<NL, EL>) v;
        this.label = label;
    }

    @Override
    public EL getLabel() {
        return label;
    }

    @Override
    public void setLabel(EL label) {
        this.label = label;
    }

    @Override
    public DefaultNode<NL, EL> getFirstNode() {
        return u;
    }

    @Override
    public DefaultNode<NL, EL> getSecondNode() {
        return v;
    }

    @Override
    public DefaultNode<NL, EL> getOppositeNode(Node<NL, EL> v) {
        assert (v == this.u || v == this.v);

        if (v == this.u)
            return this.v;
        else
            return this.u;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(getFirstNode().getIndex());
        sb.append(",");
        sb.append(getSecondNode().getIndex());
        sb.append(",");
        sb.append(getLabel());
        sb.append(") ");
        return sb.toString();
    }

}
