package struclust.repselection;

import graph.Graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import struclust.Cluster;
import struclust.SharedMemorySCC;
import struclust.graph.GraphContainer;
import struclust.graph.Graphs;

/**
 * Selects the distinct representatives which have the highest product of
 * support and size (number of edges).
 * 
 * To allow
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class SupportSizeRSS<NL, EL, G extends Graph<NL, EL>> implements RepSelectionStrategy<NL, EL, G> {

    private SharedMemorySCC<NL, EL, G> conf;
    private boolean removeSubgraphs;

    /**
     * Constructor
     * 
     * @param conf
     *            the configuration
     * @param removeSubgraphs
     *            if true, all subgraphs are filtered out of the candidate set
     *            for representatives (i.e. only the supergraphs are considered
     *            as representatives)
     */
    public SupportSizeRSS(SharedMemorySCC<NL, EL, G> conf, boolean removeSubgraphs) {
        this.conf = conf;
        this.removeSubgraphs = removeSubgraphs;

    }

    @Override
    public ArrayList<GraphContainer<NL, EL, G>> select(Cluster<NL, EL, G> cluster,
            ArrayList<GraphContainer<NL, EL, G>> newReps, List<Cluster<NL, EL, G>> clustering) {
        List<GraphContainer<NL, EL, G>> reps = new ArrayList<>(newReps);
        reps.addAll(cluster.getRepresentatives());

        if (removeSubgraphs) {
            Graphs.filterSubgraphs(reps);
        } else {
            Graphs.distinctGraphs(reps);
        }

        // calculate the exact support for each representative
        final HashMap<GraphContainer<NL, EL, G>, Double> support = new HashMap<>(reps.size());
        for (GraphContainer<NL, EL, G> gc : reps) {
            support.put(gc, conf.supportCounting.support(cluster, gc.getGraph()));
        }

        // sort the representatives by support x size
        Collections.sort(reps, new Comparator<GraphContainer<NL, EL, G>>() {
            @Override
            public int compare(GraphContainer<NL, EL, G> o1, GraphContainer<NL, EL, G> o2) {
                return -1 * Double.compare(o1.getEdgeCount() * support.get(o1), o2.getEdgeCount() * support.get(o2));
            }
        });

        return new ArrayList<>(reps.subList(0, Math.min(conf.repCount, reps.size())));
    }

    @Override
    public String getDescription() {
        return "SupportSizeRSS (removeSubgraphs: " + removeSubgraphs + ")";
    }

}
