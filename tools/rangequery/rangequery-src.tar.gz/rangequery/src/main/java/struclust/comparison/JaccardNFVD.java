package struclust.comparison;

import hsahn.datastructure.FeatureVector;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;

/**
 * Jaccard distance : 1 - (|first &cup; second| / |first &cap; second|)
 * 
 * @author Till Schäfer
 *
 * @param <K>
 *            the type of the features keys
 */
public class JaccardNFVD<K> implements NumericalFeatureVectorDistance<K> {

    @Override
    public double calc(FeatureVector<K> first, FeatureVector<K> second) {

        if (first.size() == 0 && second.size() == 0) {
            return 0;
        }

        ObjectOpenHashSet<K> allPosFeatures = new ObjectOpenHashSet<>(first.positiveFeatures());
        allPosFeatures.addAll(second.positiveFeatures());

        long i = 0;
        long u = 0;
        for (K k : allPosFeatures) {
            long firstCount = first.getCount(k);
            long secondCount = second.getCount(k);
            /*
             * i = min(firstCount, secondCount)
             * u = max(firstCount, secondCount)
             */
            if (firstCount < secondCount) {
                i += firstCount;
                u += secondCount;
            }else {
                i += secondCount;
                u += firstCount;
            }
        }

        return 1 - ((double) i / u);
    }

    @Override
    public double maxDist() {
        return 1;
    }

    @Override
    public String getDescription() {
        return "JaccardNFVD";
    }

}
