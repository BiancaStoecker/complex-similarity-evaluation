package struclust.granularity;

import graph.Graph;

import java.util.List;

import struclust.Cluster;
import struclust.ClusterFactory;
import struclust.Describable;
import struclust.StructuralClustering;

/**
 * A split strategy splits a set of specified clusters.
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface SplitStrategy<NL, EL, G extends Graph<NL, EL>> extends Describable {
    /**
     * Split clusters in toSplit
     * 
     * @param toSplit
     *            the clusters to split.
     * @param allClusters
     *            all clusters in the current clustering (including the clusters
     *            form toSplit).
     * @param clusterFactory
     *            for the creation of clusters with unique id
     * @param parentClusterer
     *            the parent clustering algorithm (used for representative
     *            updates)
     * @return the split clustering (all clusters after splitting)
     */
    public List<Cluster<NL, EL, G>> split(List<Cluster<NL, EL, G>> toSplit, List<Cluster<NL, EL, G>> allClusters,
            ClusterFactory<NL, EL, G> clusterFactory, StructuralClustering<NL, EL, G> parentClusterer);
}
