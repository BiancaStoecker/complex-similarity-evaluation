package struclust.mining;

import graph.Graph;

import java.util.List;

import struclust.Cluster;
import struclust.Describable;

/**
 * Interface for a strategy to determine a minimal support value for
 * representative mining. This can be used as a balancing strategy for
 * clustering.
 * 
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface MinSupStrategy<NL, EL, G extends Graph<NL, EL>> extends Describable {

    /**
     * Calculate the minimal support value for representative mining for
     * {@link Cluster} current.
     * 
     * @param all
     *            all {@link Cluster}s in the current Clustering
     * @param current
     *            the {@link Cluster} to determine the minimal support value for
     * @return the minimal support value
     */
    double calc(List<Cluster<NL, EL, G>> all, Cluster<NL, EL, G> current);

}
