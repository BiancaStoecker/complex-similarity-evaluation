package struclust.comparison;

import graph.Graph;
import index.features.BitFingerprint;
import struclust.graph.GraphContainer;

/**
 * Implementation of the Tanimoto Distance, which is the same as 1 - Jaccard
 * Coefficient if treating a bit as the presence of an element in a set.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class TanimotoGGD<NL, EL, G extends Graph<NL, EL>> implements GraphGraphDistance<NL, EL, G> {
    @Override
    public double calc(GraphContainer<NL, EL, G> graph1, GraphContainer<NL, EL, G> graph2) {
        BitFingerprint bits1 = graph1.getFp();
        BitFingerprint bits2 = graph2.getFp();

        int cardinality1 = bits1.cardinality();
        int cardinality2 = bits2.cardinality();

        BitFingerprint intersection = (BitFingerprint) bits1.clone();
        intersection.and(bits2);

        int intersectionCardinality = intersection.cardinality();
        int unionCardinality = cardinality1 + cardinality2 - intersectionCardinality;

        if (unionCardinality == 0) {
            // avoid devision by zero
            return 1;
        } else {
            double val = 1.0 - (double) intersectionCardinality / unionCardinality;
            assert !Double.isNaN(val);
            return val;
        }
    }

    @Override
    public double maxDist() {
        return 1;
    }

    @Override
    public String getDescription() {
        return "Tanimoto GG-Distance";
    }

}
