package struclust.datastructures;

/**
 * This is a mutable integer.
 * 
 * Attention: Defaults to 1 after creation
 * 
 * @author Till Schäfer
 */
public class MutableInt {
    int value;

    /**
     * Constructor
     * 
     * initial value is 1
     */
    public MutableInt() {
        value = 0;
    }

    /**
     * Constructor
     * 
     * @param value
     *            initial value
     */
    public MutableInt(int value) {
        this.value = value;
    }

    /**
     * @return the value
     */
    public int get() {
        return value;
    }

    /**
     * Setter for the value
     * 
     * @param i
     *            the value to set
     */
    public void set(int i) {
        value = i;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}