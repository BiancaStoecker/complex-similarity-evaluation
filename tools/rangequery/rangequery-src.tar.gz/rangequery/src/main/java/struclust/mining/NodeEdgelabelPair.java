package struclust.mining;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * This a container Structure to store an edge and a node label together.
 * 
 * @author Till Schäfer
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public class NodeEdgelabelPair<NL, EL> {
    /**
     * The edge label
     */
    public EL edgeLabel;

    /**
     * The node label
     */
    public NL nodeLabel;

    /**
     * @param edgeLabel
     * @param nodeLabel
     */
    public NodeEdgelabelPair(NL nodeLabel, EL edgeLabel) {
        this.edgeLabel = edgeLabel;
        this.nodeLabel = nodeLabel;
    }

    /**
     * Is equal if the edge and the node label are equal. Return null if o is
     * null or an object of another type.
     */
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!(o instanceof NodeEdgelabelPair)) {
            return false;
        }
        @SuppressWarnings("rawtypes")
        NodeEdgelabelPair other = (NodeEdgelabelPair) o;
        return new EqualsBuilder().append(edgeLabel, other.edgeLabel).append(nodeLabel, other.nodeLabel).isEquals();
    }

    /**
     * Based on edgeLabels and nodeLabels hashCode
     */
    public int hashCode() {
        return new HashCodeBuilder().append(edgeLabel).append(nodeLabel).hashCode();

    }
}
