package struclust.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FilenameUtils;

/**
 * Helper class to to some convenient file system operations
 * 
 * @author Till Schäfer
 */
public class FsOperations {
    
    private static final int DEFAULT_MIN_DIGITS = 3;

    /**
     * Creates a unique folder inside of parentPath. The unique folder name will
     * be "baseNameNumber" where baseName is a configurable parameter and number
     * will be the lowest number available. Using
     * {@link #createUniqueFolder(String, String, int)} with minDigits = 2.
     * 
     * @param parentPath
     *            the parent folder path
     * @param baseName
     *            the baseName as described above
     * @return the created folder path
     * @throws IOException
     *             if the folder creation fails
     */
    public static String createUniqueFolder(String parentPath, String baseName) throws IOException {
        return createUniqueFolder(parentPath, baseName, DEFAULT_MIN_DIGITS);
    }

    /**
     * Creates a unique folder inside of parentPath. The unique folder name will
     * be "baseNameNumber" where baseName is a configurable parameter and number
     * will be the lowest number available.
     * 
     * @param parentPath
     *            the parent folder path
     * @param baseName
     *            the baseName as described above
     * @param minDigits
     *            the minimal number of digits for the folder name (filled with
     *            leading zeros)
     * @return the created folder path
     * @throws IOException
     *             if the folder creation fails
     */
    public static String createUniqueFolder(String parentPath, String baseName, int minDigits) throws IOException {
        int freeId = 0;
        File candidate = null;
        do {
            freeId++;
            candidate = new File(FilenameUtils.concat(parentPath,
                    baseName + String.format("%0" + minDigits + "d", freeId)));
        } while (candidate.exists());

        if (!candidate.mkdir()) {
            throw new IOException("folder creation failed for path: " + candidate);
        }
        return candidate.getPath();
    }

    /**
     * Calculates a unique file name (without creating it). The unique file name
     * will be "basenameNumber.Extension" where baseName and Extension are
     * configurable parameters and number will be the lowest number available.
     * 
     * @param parentPath
     *            the parent folder path
     * @param extension
     *            the desired extension of the file. if null, no extension is
     *            added.
     * @param baseName
     *            the baseName as described above
     * @return the unique file path
     */
    public static String getUniqueFileName(String parentPath, String baseName, String extension) {
        return getUniqueFileName(parentPath, baseName, extension, DEFAULT_MIN_DIGITS);
    }

    /**
     * Calculates a unique file name (without creating it). The unique file name
     * will be "basenameNumber.Extension" where baseName and Extension are
     * configurable parameters and number will be the lowest number available.
     * 
     * @param parentPath
     *            the parent folder path
     * @param baseName
     *            the baseName as described above
     * @param extension
     *            the desired extension of the file. if null, no extension is
     *            added.
     * @param minDigits
     *            the minimal number of digits for the folder name (filled with
     *            leading zeros)
     * @return the unique file path
     */
    public static String getUniqueFileName(String parentPath, String baseName, String extension, int minDigits) {
        int freeId = 0;
        File candidate = null;
        do {
            freeId++;
            String fullFilename = baseName + String.format("%0" + minDigits + "d", freeId);
            if (extension != null) {
                fullFilename += FilenameUtils.EXTENSION_SEPARATOR + extension;
            }
            candidate = new File(FilenameUtils.concat(parentPath, fullFilename));
        } while (candidate.exists());

        return candidate.getPath();
    }
}
