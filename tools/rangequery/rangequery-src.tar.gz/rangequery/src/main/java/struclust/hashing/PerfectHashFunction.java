package struclust.hashing;

/**
 * A perfect hash function is a {@link HashFunction} that guarantees distinct
 * values for distinct keys.
 * 
 * @author Till Schäfer
 *
 * @param <K>
 *            the key type
 * @param <V>
 *            the value type
 */
public interface PerfectHashFunction<K, V> extends HashFunction<K, V> {

}
