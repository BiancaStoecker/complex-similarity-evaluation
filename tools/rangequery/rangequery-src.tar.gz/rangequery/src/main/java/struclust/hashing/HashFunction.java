package struclust.hashing;

import struclust.Describable;

/**
 * A hash function maps a key to a value.
 * 
 * @author Till Schäfer
 *
 * @param <K>
 *            the key type
 * @param <V>
 *            the value type
 */
public interface HashFunction<K, V> extends Describable {
    /**
     * hash a key to a value
     * 
     * @param key
     *            the key
     * @return the value
     */
    public V hash(K key);
}
