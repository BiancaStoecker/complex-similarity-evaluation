package struclust.mining;

import graph.Graph;

import java.util.List;

import struclust.graph.GraphContainer;

import com.google.common.collect.HashMultimap;

/**
 * Fake estimator that always returns 1.
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class FakeSCE<NL, EL, G extends Graph<NL, EL>> implements SupportedCallsEstimator<NL, EL, G> {

    @Override
    public int estimate(List<GraphContainer<NL, EL, G>> graphs, double minSup,
            HashMultimap<NL, NodeEdgelabelPair<NL, EL>> edgeMap) {
        return 1;
    }

    @Override
    public String getDescription() {
        return "FakeSCE";
    }

}
