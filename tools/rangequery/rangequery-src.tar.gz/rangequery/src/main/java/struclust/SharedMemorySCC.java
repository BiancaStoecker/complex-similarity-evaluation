package struclust;

import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import graph.Graph;
import graph.GraphFactory;
import graph.GraphSize;
import index.features.FingerprintBuilder;
import struclust.comparison.AccCGD;
import struclust.comparison.AccFunction;
import struclust.comparison.ClusterGraphDistance;
import struclust.comparison.TanimotoGGD;
import struclust.convergence.ConvergenceCriteria;
import struclust.convergence.CoverageIncreasingCC;
import struclust.datastructures.MutableInt;
import struclust.eval.EvalResult;
import struclust.eval.modules.clustering.PrecompClustEM;
import struclust.granularity.MergeCriteria;
import struclust.granularity.MergeStrategy;
import struclust.granularity.SplitCriteria;
import struclust.granularity.SplitStrategy;
import struclust.mining.BinomialSC;
import struclust.mining.FrequentGraphMiner;
import struclust.mining.MinSupStrategy;
import struclust.mining.RandomGM;
import struclust.mining.RandomGM.RandomGMConf;
import struclust.mining.RelRepToMemberSizeMSS;
import struclust.mining.SupportCounting;
import struclust.preclustering.PreClustering;
import struclust.preclustering.RandRepPC;
import struclust.repselection.RepSelectionStrategy;
import struclust.repselection.SupportSizeRSS;
import struclust.util.Concurrent;

/**
 * Holds the configuration parameters of a structural clustering
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class SharedMemorySCC<NL, EL, G extends Graph<NL, EL>> implements StructuralClusteringConf<NL, EL, G> {
    private static final Logger logger = LoggerFactory.getLogger(SharedMemorySCC.class);

    /**
     * Constructor
     * 
     * @param gFactory
     *            the {@link GraphFactory} of G
     * @param parallelism
     *            the parallelism (see {@link SharedMemorySCC#parallelism}
     */
    public SharedMemorySCC(GraphFactory<NL, EL, G> gFactory, int parallelism) {
        this.gFactory = gFactory;
        this.parallelism = new MutableInt(parallelism);
    }

    /**
     * How many threads should be used in parallel? a value less than 1 means
     * that the parallelism is set to the number of (logical) cores on your
     * system.
     * 
     * Note: this only sets each thread pool the the maximum number of threads.
     * The real number of threads may be higher due to nested parallelism. If
     * you want to strictly set the number of threads, use your operating system
     * tools like taskset on linux/unix.
     */
    public MutableInt parallelism = new MutableInt(0);

    /**
     * @return the effective parallelism respecting values of parallelism less
     *         than one.
     */
    public int getParallelism() {
        return Concurrent.getEffectiveParallelism(parallelism.get());
    }

    /**
     * A {@link GraphFactory} for G
     */
    public GraphFactory<NL, EL, G> gFactory;

    /**
     * The way the graph size is counted
     */
    public GraphSize gSize = GraphSize.edges;

    /**
     * the pre clustering algorithm for initial partitioning of the graphs
     */
    public PreClustering<NL, EL, G> preClusterer = new RandRepPC<>(100, new TanimotoGGD<NL, EL, G>());

    /**
     * The {@link ConvergenceCriteria} for optimization loop termination
     */
    public ConvergenceCriteria convergence = new CoverageIncreasingCC(this, 3);

    /**
     * reset the convergence criteria whenever the number of clusters changed
     */
    public boolean convergenceResetOnNumClusterChange = false;

    /**
     * The maximal number of iterations. However, the algorithm will respect
     * {@link #splitCooldownRounds} with higher priority. Therefore the real
     * maximumm number of iterations is between {@link #maxIterations} and (
     * {@link #maxIterations} + {@link #splitCooldownRounds})
     */
    public int maxIterations = Integer.MAX_VALUE;

    /**
     * Whether to split generic clusters or not
     */
    public boolean clusterSplitting = false;

    /**
     * The criteria which defines the clusters to split
     */
    public SplitCriteria splitCriteria = null;

    /**
     * The strategy, that splits the clusters identified by the splitCriteria
     */
    public SplitStrategy<NL, EL, G> splitStrategy = null;

    /**
     * This number determines the minimal number of rounds between each split.
     * This makes the evaluation of the split criteria more fair for the new
     * clusters (which may need some rounds to become comparable to existing
     * clusters).
     */
    public int splitCooldownRounds = 3;

    /**
     * Whether to merge close clusters or not
     */
    public boolean clusterMerging = false;

    /**
     * The criteria which defines the clusters to merge
     */
    public MergeCriteria<NL, EL, G> mergeCriteria = null;

    /**
     * the strategy, that merges the cluster pairs identified by the
     * mergeCriteria
     */
    public MergeStrategy<NL, EL, G> mergeStrategy = null;

    /**
     * This number determines the number of rounds before the first time
     * splitting or merging is applied. This parameter allows to overcome the
     * very nervous starting phase of the algorithm.
     */
    public int startupRounds = 5;

    /**
     * If this is set to true, graphs are assigned to a newly created cluster if
     * their minimal distance to all clusters is equal to the maximum distance
     * of the distance measure.
     * 
     * Attention: this is only possible for {@link ClusterGraphDistance}s, that
     * support maxDist() (i.e. maxDist() does not return NaN)
     */
    public boolean assignToNewClusterOnMaxDissimilarity = false;

    /**
     * Every Cluster smaller than this threshold will be destroyed and the
     * members will be merged with the other clusters.<br>
     * 
     * <ul>
     * <li><b>If the value is below 1.0:</b> The concrete threshold is
     * calculated as percentage of the average cluster size</li>
     * <li><b>if the value is above or equal to 1.0:</b> This value represents
     * an absolute threshold</li>
     * <ul>
     */
    public double minimalClusterSize = 0.05;

    /**
     * distance for cluster membership assignment
     */
    public ClusterGraphDistance<NL, EL, G> cgDist = new AccCGD<>(new TanimotoGGD<NL, EL, G>(),
            AccFunction.AVG);

    /**
     * Stategy to select the minimal support value for the graphMiner
     */
    public MinSupStrategy<NL, EL, G> minSupStrategy = new RelRepToMemberSizeMSS<>(0.6, 0.6, 1.2, 0.95);

    /**
     * number of representatives for each cluster
     */
    public int repCount = 5;

    /**
     * the maximal size of a representative
     */
    public int maxRepSize = Integer.MAX_VALUE;

    /**
     * number of candidate representatives that are mined after each cluster
     * update
     */
    public int newRepCount = 25;

    /**
     * The {@link FrequentGraphMiner} for representative mining
     */
    public RandomGM<NL, EL, G> graphMiner = new RandomGM<>(new RandomGMConf<>(gFactory, this));
    
    /**
     * strategy to select the new representatives based in the candidate
     * representatives and the previous representatives
     */
    public RepSelectionStrategy<NL, EL, G> repSelectionStrategy = new SupportSizeRSS<>(this, false);

    /*
     * TODO: This are good default values (i.e. Path, Tree, Rings + sizes of
     * them ) from Nils experiments, we need to check if they still apply to our
     * conditions
     */
    /**
     * the builder for the bit fingerprints, which are used for subgraph
     * isomorphism filtering (e.g. in support counting) and the distance
     * calculations (e.g. TanimotoDistance)
     */
    public FingerprintBuilder defFpBuilder = new FingerprintBuilder(2048);

    /**
     * strategy to count the support of a pattern
     */
    public SupportCounting<NL, EL, G> supportCounting = new BinomialSC<>(0.01, parallelism);

    /**
     * Iff true, each evaluation module ({@link PrecompClustEM}) in
     * {@link #injectionModules} is executed at the beginning of each iteration.
     */
    public boolean evalModuleInjection = false;

    /**
     * The list of {@link PrecompClustEM}s that are executed if
     * {@link #evalModuleInjection} is true.
     */
    public List<PrecompClustEM<NL, EL, G>> injectionModules = new LinkedList<>();

    @Override
    public Object clone() {
        Object clone = null;
        try {
            clone = super.clone();
        } catch (CloneNotSupportedException e) {
            logger.error("This should be impossible", e);
        }
        return clone;
    }

    @Override
    public void addAsMetadata(EvalResult result) {
        result.addMetadata("parallelism", parallelism.get());
        result.addMetadata("graph size counting", gSize.name());
        result.addMetadata("pre clustering", preClusterer);
        result.addMetadata("convergence criteria", convergence);
        result.addMetadata("max iterations", maxIterations);
        result.addMetadata("cluster splitting", clusterSplitting);
        result.addMetadata("splitting criteria", splitCriteria == null ? "NA" : splitCriteria.getDescription());
        result.addMetadata("splitting strategy", splitStrategy == null ? "NA" : splitStrategy.getDescription());
        result.addMetadata("splitting cooldown rounds", splitCooldownRounds);
        result.addMetadata("cluster merging", clusterMerging);
        result.addMetadata("merging criteria", mergeCriteria == null ? "NA" : mergeCriteria.getDescription());
        result.addMetadata("merging strategy", mergeStrategy == null ? "NA" : mergeStrategy.getDescription());
        result.addMetadata("startup rounds", startupRounds);
        result.addMetadata("assign to new cluster on maximum dissimilarity", assignToNewClusterOnMaxDissimilarity);
        result.addMetadata("minimal cluster size", minimalClusterSize);
        result.addMetadata("cluster-graph distance", cgDist);
        result.addMetadata("minimum support strategy", minSupStrategy);
        result.addMetadata("maximum number of representatives per clusters", repCount);
        result.addMetadata("maximum size of the representatives", maxRepSize);
        result.addMetadata("number of representative candidates", newRepCount);
        graphMiner.getConf().addAsMetadata(result);
        result.addMetadata("graph miner", graphMiner);
        result.addMetadata("representative selection strategy", repSelectionStrategy);
        result.addMetadata("fingerprint settings", defFpBuilder.toString());
        result.addMetadata("support counting strategy", supportCounting);
        result.addMetadata("evaluation module injection", evalModuleInjection);
    }
}
