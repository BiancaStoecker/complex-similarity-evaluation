package struclust.hashing;

import java.util.Set;

/**
 * Same as {@link MinHashHF}, is limited to Integer keys and can therefore
 * fulfill the contract of {@link ContiuousIntHashFunction}. Is fixed to a
 * {@link LookupTableCPIHF} as permutation function.
 * 
 * @author Till Schäfer
 */
public class MinHashCIHF extends MinHashHF<Integer, Integer> implements ContiuousIntHashFunction<Set<Integer>> {

    private Integer maxValue;

    /**
     * Constructor
     * 
     * @param hf
     *            the underlying {@link PerfectHashFunction} for random
     *            permutation of the key element universe
     */
    public MinHashCIHF(ContinuousPerfectIntHashFunction<Integer> hf) {
        super(hf);
        maxValue = hf.maxValue();
    }

    @Override
    public Integer maxValue() {
        return maxValue;
    }

}
