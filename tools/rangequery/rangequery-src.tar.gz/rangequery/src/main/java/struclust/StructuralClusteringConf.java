package struclust;

import graph.Graph;
import struclust.graph.GraphContainer;

/**
 * Configuration object for {@link StructuralClustering}
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface StructuralClusteringConf<NL, EL, G extends Graph<NL, EL>>
        extends ClusteringConf<GraphContainer<NL, EL, G>> {

}
