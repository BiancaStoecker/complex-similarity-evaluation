package struclust.datastructures;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Implementation of the Queue interface that provides a random order queue.
 * 
 * The implementation targets against very fast thread independent random
 * operations. It is especially suited for large queues where you only want to
 * draw a few elements random elements from as the random operation is only done
 * while polling the queue. <br>
 * <br>
 * 
 * <b>Attention:</b> This also has the implication, that methods, which return
 * the complete internal state (such as {@link #toArray()}) will not return
 * randomized data.<br>
 * 
 * <b>Attention:</b> For the same reason {@link #iterator()}, {@link #element()}
 * and {@link #peek()} will throw an {@link UnsupportedOperationException}.
 * 
 * @author Till Schäfer
 *
 * @param <E>
 *            type of elements stored
 */
public class RandomQueue<E> implements Queue<E> {

    private SwappingArrayList<E> data;

    /**
     * Constructor
     */
    public RandomQueue() {
        data = new SwappingArrayList<>();
    }

    /**
     * Constructor
     * 
     * @param c
     *            the elements of c are copied to this queue
     */
    public RandomQueue(Collection<? extends E> c) {
        data = new SwappingArrayList<>(c);
    }

    @Override
    public int size() {
        return data.size();
    }

    @Override
    public boolean isEmpty() {
        return data.isEmpty();
    }

    @Override
    public boolean contains(Object o) {
        return data.contains(o);
    }

    @Override
    public Iterator<E> iterator() {
        throw new UnsupportedOperationException("Random iteration of the Queue is unsupported");
    }

    @Override
    public Object[] toArray() {
        return data.toArray();
    }

    @Override
    public <T> T[] toArray(T[] a) {
        return data.toArray(a);
    }

    @Override
    public boolean remove(Object o) {
        return data.remove(o);
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return data.containsAll(c);
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        return data.addAll(c);
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        return data.removeAll(c);
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        return data.retainAll(c);
    }

    @Override
    public void clear() {
        data.clear();
    }

    @Override
    public boolean add(E e) {
        return data.add(e);
    }

    @Override
    public boolean offer(E e) {
        return data.add(e);
    }

    @Override
    public E remove() {
        if (data.isEmpty())
            throw new NoSuchElementException();

        int randIndex = ThreadLocalRandom.current().nextInt(data.size());
        E retVal = data.get(randIndex);
        data.swapAndRemove(randIndex);
        return retVal;
    }

    @Override
    public E poll() {
        if (data.isEmpty())
            return null;

        int randIndex = ThreadLocalRandom.current().nextInt(data.size());
        E retVal = data.get(randIndex);
        data.swapAndRemove(randIndex);
        return retVal;
    }

    @Override
    public E element() {
        throw new UnsupportedOperationException();
    }

    @Override
    public E peek() {
        throw new UnsupportedOperationException();
    }

    /**
     * Retrieves n random elements from the queue and returns them as
     * {@link ArrayList}. If n is larger than size() only size elements will be
     * returned.
     * 
     * @param n
     *            the maximal number of elements to return.
     * @return max(n, size()) random elements
     */
    public ArrayList<E> multiPoll(int n) {
        ArrayList<E> retVal = new ArrayList<>();
        int realSize = Math.min(n, size());
        for (int i = 0; i < realSize; i++) {
            retVal.add(remove());
        }
        return retVal;
    }

}
