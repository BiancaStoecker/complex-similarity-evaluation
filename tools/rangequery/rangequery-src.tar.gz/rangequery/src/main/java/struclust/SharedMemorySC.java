package struclust;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;
import com.google.common.util.concurrent.ThreadFactoryBuilder;

import graph.Graph;
import struclust.comparison.ClusterGraphDistance;
import struclust.eval.EvalResult;
import struclust.eval.modules.clustering.PrecompClustEM;
import struclust.graph.GraphContainer;
import struclust.util.Clusters;
import struclust.util.Concurrent;

/**
 * A structural clustering implementation parallelized for shared memory
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class SharedMemorySC<NL, EL, G extends Graph<NL, EL>> implements StructuralClustering<NL, EL, G> {
    private static final Logger logger = LoggerFactory.getLogger(SharedMemorySC.class);

    private ArrayList<GraphContainer<NL, EL, G>> graphs;
    private SharedMemorySCC<NL, EL, G> conf;
    private ClusterFactory<NL, EL, G> clusterFactory;
    private Collection<EvalResult> injectionResults = null;
    private ExecutorService repMinePool;
    ExecutorService assignmentPool;

    /**
     * Constructor
     * 
     * @param graphs
     *            the {@link Graph}s to cluster
     * @param conf
     *            the parameters for the clustering
     */
    public SharedMemorySC(ArrayList<GraphContainer<NL, EL, G>> graphs, SharedMemorySCC<NL, EL, G> conf) {
        this.graphs = graphs;
        this.conf = conf;
        clusterFactory = new ClusterFactory<>(conf);
        repMinePool = Executors.newFixedThreadPool(Concurrent.getEffectiveParallelism(conf.getParallelism()),
                new ThreadFactoryBuilder().setNameFormat("CluserLevelRepMining-%d").setDaemon(true).build());
        assignmentPool = Executors.newFixedThreadPool(conf.getParallelism(),
                new ThreadFactoryBuilder().setNameFormat("Assignment-%d").setDaemon(true).build());
    }

    @Override
    public void calcFingerprints() {
        logger.info("calculating fingerprints");

        ForkJoinPool forkJoinPool = new ForkJoinPool(conf.getParallelism());
        try {
            /*
             * This is a workaround for Java stream api to not support a
             * ThreadPool specification
             * 
             * PARALLEL stream: fingerprint calculation
             */
            forkJoinPool.submit(
                    () -> graphs.stream().parallel().filter(x -> !x.hasFp())
                            .forEach(x -> x.setFp(conf.defFpBuilder.getFingerprint(x)))).get();
        } catch (InterruptedException e) {
            logger.warn("Interrupted: ", e);
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            logger.error("Error in fingerprint calculation: ", e);
            throw new RuntimeException(e);
        }
        forkJoinPool.shutdown();
    }

    @Override
    public SharedMemorySCC<NL, EL, G> getConf() {
        return conf;
    }

    @Override
    public List<Cluster<NL, EL, G>> calc() {
        logger.trace("Starting Serial Structural Clustering");
        logger.info("Clustering {} graphs", graphs.size());

        if (conf.evalModuleInjection) {
            injectionResults = new LinkedList<>();
            for (PrecompClustEM<NL, EL, G> module : conf.injectionModules) {
                module.reset();
            }
        }

        List<Cluster<NL, EL, G>> clusters = new ArrayList<>();

        calcFingerprints();

        applyPreClustering(clusters);

        /*
         * optimization loop
         */
        logger.info("starting optimization loop");
        int changes = Integer.MAX_VALUE;
        int numIt = 0;
        int lastSplit = Integer.MIN_VALUE / 2; // numIt - lastSplit may overflow
        conf.convergence.reset();
        while ((!conf.convergence.convergent(changes, graphs.size(), clusters) && numIt < conf.maxIterations)
                || numIt <= conf.startupRounds || numIt - lastSplit < conf.splitCooldownRounds) {
            numIt++;
            boolean startupRound = numIt <= conf.startupRounds;
            boolean splitCoolDownRound = numIt - lastSplit <= conf.splitCooldownRounds;

            int oldNumClusters = clusters.size();
            logger.debug("------------------------------ Iteration {} ------------------------------", numIt);

            if (conf.evalModuleInjection) {
                logger.debug("---part: evaluation module injection---");
                for (PrecompClustEM<NL, EL, G> module : conf.injectionModules) {
                    injectionResults.addAll(module.run(clusters));
                }
            }

            if (conf.clusterSplitting && !startupRound && !splitCoolDownRound) {
                logger.debug("---part: splitting clusters---");
                List<Cluster<NL, EL, G>> splitClusters = conf.splitCriteria.toSplit(clusters);
                logger.debug("---> selected {} / {} clusters with {} graphs for splitting", splitClusters.size(),
                        clusters.size(), splitClusters.stream().mapToInt(c -> c.size()).sum());
                if (!splitClusters.isEmpty()) {
                    clusters = conf.splitStrategy.split(splitClusters, clusters, clusterFactory, this);
                    lastSplit = numIt;
                }
            }

            if (conf.clusterMerging && !startupRound) {
                logger.debug("---part: merging clusters---");
                List<Pair<Cluster<NL, EL, G>, Cluster<NL, EL, G>>> mergePairs = conf.mergeCriteria.toMerge(clusters);
                logger.debug("---> selected {}/{} clusters with {} graphs for merge", mergePairs.size() * 2,
                        clusters.size(), mergePairs.stream().mapToInt(p -> p.getLeft().size() + p.getRight().size())
                                .sum());
                clusters = conf.mergeStrategy.merge(mergePairs, clusters, clusterFactory, this);
            }

            List<Cluster<NL, EL, G>> oldClusters = clusters;
            clusters = Clusters.cloneClusteringWithoutMembers(oldClusters);

            changes = assignGraphsToClusters(clusters, oldClusters);
            logger.debug("---> moved {} / {} graphs", changes, graphs.size());

            logger.debug("---part: destroy small or empty clusters---");
            removeEmtpyClusters(clusters);
            destroySmallClusters(clusters);

            updateReps(clusters);

            if (conf.convergenceResetOnNumClusterChange && oldNumClusters != clusters.size()) {
                conf.convergence.reset();
            }
            logger.info(">>> Finished round {} with {} clusters <<<", numIt, clusters.size());

            assert clusters.stream().mapToInt(c -> c.size()).sum() == graphs.size();
        }

        return clusters;
    }

    @Override
    public void updateReps(List<Cluster<NL, EL, G>> clusters) {
        logger.debug("---part: update representatives");

        logger.debug("---> mining candidates");
        ArrayList<UpdateRepJob> updateRepJobs = new ArrayList<>(clusters.size());
        List<Future<Pair<Cluster<NL, EL, G>, ArrayList<GraphContainer<NL, EL, G>>>>> updateRepFeatures = new ArrayList<>(
                clusters.size());
        for (Cluster<NL, EL, G> cluster : clusters) {
            double minSup = conf.minSupStrategy.calc(clusters, cluster);
            updateRepJobs.add(new UpdateRepJob(cluster, conf.newRepCount, minSup));
        }
        try {
            updateRepFeatures.addAll(repMinePool.invokeAll(updateRepJobs));
        } catch (InterruptedException e) {
            logger.warn("representative updating interrupted", e);
        }

        List<Future<Pair<Cluster<NL, EL, G>, ArrayList<GraphContainer<NL, EL, G>>>>> selectRepFeatures = new ArrayList<>(
                clusters.size());

        logger.debug("---> selecting candidates");
        for (Future<Pair<Cluster<NL, EL, G>, ArrayList<GraphContainer<NL, EL, G>>>> future : updateRepFeatures) {
            try {
                Pair<Cluster<NL, EL, G>, ArrayList<GraphContainer<NL, EL, G>>> candidatesResult = future.get();
                Cluster<NL, EL, G> cluster = candidatesResult.getKey();
                ArrayList<GraphContainer<NL, EL, G>> repCandidates = candidatesResult.getValue();

                selectRepFeatures.add(repMinePool.submit(new SelectRepJob(cluster, repCandidates, clusters)));
            } catch (InterruptedException e) {
                logger.warn("representative updating interrupted", e);
            } catch (ExecutionException e) {
                logger.error("Execution of parallel representative update failed", e);
                throw new RuntimeException(e.getCause());
            }
        }

        for (Future<Pair<Cluster<NL, EL, G>, ArrayList<GraphContainer<NL, EL, G>>>> future : selectRepFeatures) {
            try {
                Pair<Cluster<NL, EL, G>, ArrayList<GraphContainer<NL, EL, G>>> result = future.get();
                Cluster<NL, EL, G> cluster = result.getKey();
                ArrayList<GraphContainer<NL, EL, G>> newReps = result.getValue();

                cluster.setRepresentatives(newReps);
            } catch (InterruptedException e) {
                logger.warn("representative selection interrupted", e);
            } catch (ExecutionException e) {
                logger.error("Execution of parallel representative selection failed", e);
                throw new RuntimeException(e.getCause());
            }
        }
    }

    /**
     * parallelize representative mining on a cluster level
     * 
     * @author Till Schäfer
     *
     */
    private class UpdateRepJob implements Callable<Pair<Cluster<NL, EL, G>, ArrayList<GraphContainer<NL, EL, G>>>> {

        private Cluster<NL, EL, G> cluster;
        private int newRepCount;
        private double minSup;

        public UpdateRepJob(Cluster<NL, EL, G> cluster, int newRepCount, double minSup) {
            this.cluster = cluster;
            this.newRepCount = newRepCount;
            this.minSup = minSup;
        }

        @Override
        public Pair<Cluster<NL, EL, G>, ArrayList<GraphContainer<NL, EL, G>>> call() throws Exception {
            ArrayList<GraphContainer<NL, EL, G>> repCandidates = conf.graphMiner.mineGraphs(cluster, newRepCount,
                    minSup);
            return Pair.of(cluster, repCandidates);
        }

    }

    /**
     * parallelize representative selection on a cluster level
     * 
     * @author Till Schäfer
     *
     */
    private class SelectRepJob implements Callable<Pair<Cluster<NL, EL, G>, ArrayList<GraphContainer<NL, EL, G>>>> {

        private Cluster<NL, EL, G> cluster;
        private ArrayList<GraphContainer<NL, EL, G>> repCandidates;
        private List<Cluster<NL, EL, G>> clustering;

        public SelectRepJob(Cluster<NL, EL, G> cluster, ArrayList<GraphContainer<NL, EL, G>> repCandidates,
                List<Cluster<NL, EL, G>> clustering) {
            this.cluster = cluster;
            this.repCandidates = repCandidates;
            this.clustering = clustering;
        }

        @Override
        public Pair<Cluster<NL, EL, G>, ArrayList<GraphContainer<NL, EL, G>>> call() throws Exception {
            ArrayList<GraphContainer<NL, EL, G>> newReps = conf.repSelectionStrategy.select(cluster, repCandidates,
                    clustering);
            /*
             * PERF: is this necessary? cannot we reuse the fingerprint from the
             * search pattern in support counting?
             */
            // calculate a structural fingerprint for each representative
            for (GraphContainer<NL, EL, G> rep : newReps) {
                rep.setFp(conf.defFpBuilder.getFingerprint(rep));
            }
            return Pair.of(cluster, newReps);
        }

    }

    /**
     * Precondition: evalModuleInjection == true
     * 
     * @return the evaluation injection results or null if {@link #calc()} was
     *         not called in advance
     */
    public Collection<EvalResult> getInjectionResults() {
        Preconditions.checkState(conf.evalModuleInjection, "evalModuleInjection is not enabled");
        return injectionResults;
    }

    @Override
    public void addAsMetadata(EvalResult result) {
        result.addMetadata("clusterer", this.getClass().getName());
        result.addMetadata(conf);
    }

    /**
     * Destroys {@link Cluster}s that are to small and unites them in one common
     * cluster
     * 
     * @param clusters
     *            the clusters to process
     * @return if clusters where destroyed
     */
    private boolean destroySmallClusters(List<Cluster<NL, EL, G>> clusters) {
        double avgClusterSize = graphs.size() / clusters.size();
        int threshold = (conf.minimalClusterSize >= 1.0 ? (int) conf.minimalClusterSize
                : (int) (conf.minimalClusterSize * avgClusterSize + 0.5));
        int changes = 0;

        Cluster<NL, EL, G> targetCluster = clusterFactory.emptyCluster();

        for (Iterator<Cluster<NL, EL, G>> it = clusters.iterator(); it.hasNext();) {
            Cluster<NL, EL, G> cluster = it.next();
            if (cluster.size() < threshold) {
                targetCluster.addAll(cluster);
                it.remove();
                changes++;
            }
        }

        if (!targetCluster.isEmpty()) {
            clusters.add(targetCluster);
        }

        logger.debug("---> destroyed {} clusters using a threshold of {}", changes, threshold);

        return changes != 0;
    }

    /**
     * Apply the PreClustering on all graphs.
     * 
     * @param clusters
     *            all clusters will be added to this list
     */
    private void applyPreClustering(List<Cluster<NL, EL, G>> clusters) {
        logger.info("applying PreClustering");
        /*
         * run PreClustering
         */
        List<? extends List<GraphContainer<NL, EL, G>>> preClustering = conf.preClusterer.calc(graphs);

        /*
         * convert PreCluster into Cluster and mine some representatives
         */
        for (List<GraphContainer<NL, EL, G>> preCluster : preClustering) {
            Cluster<NL, EL, G> cluster = clusterFactory.newCluster(preCluster);
            clusters.add(cluster);
        }

        removeEmtpyClusters(clusters);
        updateReps(clusters);
    }

    /**
     * assign each graph into its closest cluster
     * 
     * @param clusters
     *            the graphs are assigned to this clusters
     * @param oldClusters
     *            the old clusters (the basically serve as a container for the
     *            graphs)
     * @return the number of cluster moves (i.e. a graph is assigned to a
     *         different cluster than before)
     */
    private int assignGraphsToClusters(List<Cluster<NL, EL, G>> clusters, List<Cluster<NL, EL, G>> oldClusters) {
        logger.debug("---part: assign graphs to clusters---");
        int changes = 0;
        ClusterGraphDistance<NL, EL, G> cDist = conf.cgDist;
        Cluster<NL, EL, G> unassignableCluster = null;

        boolean assignToNewClusterOnMaxDist = conf.assignToNewClusterOnMaxDissimilarity
                && !Double.isNaN(cDist.maxDist());
        if (assignToNewClusterOnMaxDist) {
            unassignableCluster = clusterFactory.emptyCluster();
            clusters.add(unassignableCluster);
        }

        List<Future<AssignmentResult>> futures = new LinkedList<>();

        for (Cluster<NL, EL, G> sourceCluster : oldClusters) {
            for (GraphContainer<NL, EL, G> graph : sourceCluster) {
                // PARALLEL: cluster assignment
                futures.add(assignmentPool.submit(new SingleAssigner(clusters, cDist, sourceCluster, graph)));
            }
        }

        for (Future<AssignmentResult> future : futures) {
            try {
                AssignmentResult result = future.get();

                if (assignToNewClusterOnMaxDist && result.minDist == cDist.maxDist()) {
                    unassignableCluster.add(result.graph);
                    changes++;
                } else {
                    result.minCluster.add(result.graph);
                    if (result.minCluster.getId() != result.sourceCluster.getId()) {
                        changes++;
                    }
                }

            } catch (InterruptedException | ExecutionException e) {
                logger.error("Error in parallel assignment execution", e);
                throw new RuntimeException(e);
            }
        }

        if (unassignableCluster != null) {
            logger.debug("---> created unassignableCluster with {} members", unassignableCluster.size());
        }

        return changes;
    }

    /**
     * remove empty clusters
     * 
     * @param clusters
     *            the set of clusters
     */
    private void removeEmtpyClusters(List<Cluster<NL, EL, G>> clusters) {
        int oldSize = clusters.size();

        for (Iterator<Cluster<NL, EL, G>> iterator = clusters.iterator(); iterator.hasNext();) {
            Cluster<NL, EL, G> cluster = iterator.next();
            if (cluster.isEmpty()) {
                iterator.remove();
            }
        }

        logger.debug("---> removed {} empty clusters", oldSize - clusters.size());
    }

    /**
     * Assigns a Graph to its closest {@link Cluster}. Callable for parallel
     * Assignment.
     * 
     * @author Till Schäfer
     */
    private class SingleAssigner implements Callable<AssignmentResult> {
        private List<Cluster<NL, EL, G>> clusters;
        private ClusterGraphDistance<NL, EL, G> cDist;
        private Cluster<NL, EL, G> sourceCluster;
        private GraphContainer<NL, EL, G> graph;

        public SingleAssigner(List<Cluster<NL, EL, G>> clusters, ClusterGraphDistance<NL, EL, G> cDist,
                Cluster<NL, EL, G> sourceCluster, GraphContainer<NL, EL, G> graph) {
            this.clusters = clusters;
            this.cDist = cDist;
            this.sourceCluster = sourceCluster;
            this.graph = graph;
        }

        @Override
        public AssignmentResult call() throws Exception {
            AssignmentResult result = new AssignmentResult();
            result.graph = graph;
            result.sourceCluster = sourceCluster;

            for (Cluster<NL, EL, G> destinationCluster : clusters) {
                if (!destinationCluster.getRepresentatives().isEmpty()) {
                    double dist = cDist.calc(destinationCluster, graph);
                    if (dist < result.minDist) {
                        result.minDist = dist;
                        result.minCluster = destinationCluster;
                    }
                }
            }

            assert result.minCluster != null;

            return result;
        }
    }

    /**
     * All information needed to assign a graph to its new cluster
     * 
     * @author Till Schäfer
     */
    private class AssignmentResult {
        public GraphContainer<NL, EL, G> graph;
        public double minDist = Double.POSITIVE_INFINITY;
        public Cluster<NL, EL, G> minCluster = null;
        public Cluster<NL, EL, G> sourceCluster;
    }

}
