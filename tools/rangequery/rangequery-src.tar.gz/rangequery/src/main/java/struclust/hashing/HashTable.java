package struclust.hashing;

import java.util.Collection;
import java.util.function.Function;

/**
 * Simple hash table that hashes some objects to some buckets w.r.t. a
 * HashFunction. Each object is first mapped to a key (similar to
 * {@link Object#hashCode()}). The key is then fed to the {@link HashFunction}.
 * Each hash value is then associated with a bucket by the HashTable.
 * 
 * @author Till Schäfer
 *
 * @param <O>
 *            the object type
 * @param <K>
 *            the key type of the {@link HashFunction}
 * @param <V>
 *            the value type of the {@link HashFunction}
 * @param <H>
 *            the type of the HashFunction
 */
public interface HashTable<O, K, V, H extends HashFunction<K, V>> {
    /**
     * Sets the {@link HashFunction}. This will <b>not</b> clear the hash table,
     * but some implementations may require a rehashing of the elements. If the
     * {@link HashTable} needs to be cleared as well, it is therefore
     * recommended to just create a new {@link HashTable}.
     * 
     * @param hf
     *            the {@link HashFunction} to use
     */
    public void setHashFunction(H hf);

    /**
     * Function that maps each object to a key, that can be applied to the
     * {@link HashFunction}. This will <b>not</b> clear the hash table, but will
     * require a rehashing of the elements. If the {@link HashTable} needs to be
     * cleared as well, it is therefore recommended to just create a new
     * {@link HashTable}.
     * 
     * @param okMapper
     */
    public void setObjectKeyMapper(Function<? super O, ? extends K> okMapper);

    /**
     * Add a set of objects to the {@link HashTable}
     * 
     * @param os
     *            the objects to add
     */
    public void addObjects(Collection<O> os);

    /**
     * Add an object to the {@link HashTable}
     * 
     * @param o
     *            the object to add
     */
    public void add(O o);

    /**
     * @return all objects stored in the {@link HashTable}
     */
    public Collection<O> getAllObjects();

    /**
     * Get the objects of the bucket of hash value v.
     * 
     * @param v
     *            the value
     * @return the elements of bucket associated with v
     */
    public Collection<O> elementsInBucket(V v);

    /**
     * Get the objects which are in the bucket in which the object o would have
     * been hashed. This will also return o, if the objects is contained in the
     * {@link HashTable}.
     * 
     * @param o
     *            the object to search the bucket for
     * @return the keys of the bucket of key
     */
    public Collection<O> elementsInBucketOf(O o);

    /**
     * Removes all objects from the {@link HashTable}
     */
    public void clearTable();

    /**
     * @return the number of objects in the {@link HashTable}
     */
    public int size();
}
