package struclust.convergence;

import java.util.Collection;

import struclust.Cluster;
import struclust.Describable;

/**
 * Calculates if a number of changes is convergent.
 * 
 * Attention: never reuse an object of this class. convergence may depend on the
 * development of changes over time. Therefore, it may store some kind of
 * history of previous changes.
 * 
 * @author Till Schäfer
 *
 */
public interface ConvergenceCriteria extends Describable {

    /**
     * @param changes
     *            the number of changes in the current run.
     * @param totalElements
     *            the total number of elements
     * @param clustering
     *            the current clustering state
     * 
     * @return whether the changes are convergent.
     */
    boolean convergent(int changes, int totalElements, Collection<? extends Cluster<?, ?, ?>> clustering);

    /**
     * Resets collected statistics from previous runs. This may be useful in
     * situations where the current measurement is not comparable to the
     * previous becuase of cluster splitting, merging or deletion.
     */
    public void reset();
}
