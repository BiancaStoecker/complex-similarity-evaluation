package struclust.comparison;

import java.util.Set;

import com.google.common.collect.Sets;

/**
 * Jaccard similary: |v1 &cup; v2| / |v1 &cap; v2|
 * 
 * @author Till Schäfer
 *
 * @param <T>
 *            the type of the features keys
 */
public class JaccardIndexSBFVS<T> implements SparseBinaryFeatureVectorSimilarity<T> {

    @Override
    public double calc(Set<T> v1, Set<T> v2) {

        if (v1.size() == 0 && v2.size() == 0) {
            return 1;
        }
        
        Set<T> maxSizeVec = v1.size() > v2.size() ? v1 : v2;
        Set<T> minSizeVec = v1.size() <= v2.size() ? v1 : v2;

        int i = 0;
        for (T e : minSizeVec) {
            if (maxSizeVec.contains(e)) {
                i++;
            }
        }

        int u = v1.size() + v2.size() - i;

        assert Sets.intersection(v1, v2).size() == i;
        assert Sets.union(v1, v2).size() == u;

        return (double) i / u;
    }

    @Override
    public double maxSim() {
        return 1;
    }

    @Override
    public String getDescription() {
        return "JaccardIndexSBFVS";
    }

}
