package struclust.hashing;

/**
 * Combined {@link PerfectHashFunction} and {@link ContiuousIntHashFunction}
 * contract.
 * 
 * @author Till Schäfer
 * 
 * @param <K>
 *            the key type
 */
public interface ContinuousPerfectIntHashFunction<K>
        extends PerfectHashFunction<K, Integer>, ContiuousIntHashFunction<K> {

}
