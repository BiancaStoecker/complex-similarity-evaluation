package struclust.comparison;

import graph.Graph;
import struclust.Cluster;
import struclust.graph.GraphContainer;

/**
 * Distance between a {@link Cluster} and a {@link Graph} based on
 * {@link GraphGraphDistance}s (plugable) between the {@link Cluster}
 * representatives and the {@link Graph}. How these single
 * {@link GraphGraphDistance}s are accumulated, is determined by a
 * {@link AccFunction}.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class AccCGD<NL, EL, G extends Graph<NL, EL>> implements ClusterGraphDistance<NL, EL, G> {

    private GraphGraphDistance<NL, EL, G> ggd;
    private AccFunction acc;

    /**
     * Constructor
     * 
     * @param ggDist
     *            the {@link GraphGraphDistance} to compare the representatives
     *            with the graph
     * @param acc
     *            the accumulation function to accumulate the single
     *            representative - graph comparisons
     */
    public AccCGD(GraphGraphDistance<NL, EL, G> ggDist, AccFunction acc) {
        this.ggd = ggDist;
        this.acc = acc;
    }

    @Override
    public double calc(Cluster<NL, EL, G> cluster, GraphContainer<NL, EL, G> graph) {
        double retVal;
        int repSize = cluster.getRepresentatives().size();

        if (cluster.getRepresentatives().isEmpty()) {
            return Double.POSITIVE_INFINITY;
        }

        /*
         * one big switch with duplicate code is faster than a switch in each
         * iteration
         */
        switch (acc) {
        case MIN:
            retVal = Double.POSITIVE_INFINITY;
            for (GraphContainer<NL, EL, G> rep : cluster.getRepresentatives()) {
                retVal = Math.min(retVal, ggd.calc(rep, graph));
            }
            break;
        case MAX:
            retVal = Double.NEGATIVE_INFINITY;
            for (GraphContainer<NL, EL, G> rep : cluster.getRepresentatives()) {
                retVal = Math.max(retVal, ggd.calc(rep, graph));
            }
            break;
        case AVG:
            retVal = 0;
            for (GraphContainer<NL, EL, G> rep : cluster.getRepresentatives()) {
                retVal += ggd.calc(rep, graph) / repSize;
            }
            break;
        case SUM:
            retVal = 0;
            for (GraphContainer<NL, EL, G> rep : cluster.getRepresentatives()) {
                retVal += ggd.calc(rep, graph);
            }
            break;
        default:
            throw new UnsupportedOperationException("This accumulation function is not supported");
        }

        return retVal;
    }

    @Override
    public double maxDist() {
        switch (acc) {
        case MIN:
            return ggd.maxDist();
        case MAX:
            return ggd.maxDist();
        case AVG:
            return ggd.maxDist();
        case SUM:
            return Double.NaN;
        default:
            throw new UnsupportedOperationException("This accumulation function is not supported");
        }
    }

    @Override
    public String getDescription() {
        return "Accumulated CG-Distance (" + ggd.getDescription() + ", " + acc.name() + ")";
    }

    @Override
    public GraphGraphDistance<NL, EL, G> getGGDist() {
        return ggd;
    }

}
