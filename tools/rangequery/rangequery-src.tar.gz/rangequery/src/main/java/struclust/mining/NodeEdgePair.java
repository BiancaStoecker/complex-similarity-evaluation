package struclust.mining;

import graph.Edge;
import graph.Node;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * Simple {@link Node} {@link Edge} Pair struct
 * 
 * @param <NL>
 * @param <EL>
 */
public class NodeEdgePair<NL, EL> {
    /**
     * The edge
     */
    public Edge<NL, EL> edge;

    /**
     * The node label
     */
    public Node<NL, EL> node;

    /**
     * @param edge
     * @param node
     */
    public NodeEdgePair(Node<NL, EL> node, Edge<NL, EL> edge) {
        this.edge = edge;
        this.node = node;
    }

    /**
     * Is equal if the edge and the node label are equal. Return null if o is
     * null or an object of another type.
     */
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!(o instanceof NodeEdgePair)) {
            return false;
        }
        @SuppressWarnings("rawtypes")
        NodeEdgelabelPair other = (NodeEdgelabelPair) o;
        return new EqualsBuilder().append(edge, other.edgeLabel).append(node, other.nodeLabel).isEquals();
    }

    /**
     * Based on edgeLabels and nodeLabels hashCode
     */
    public int hashCode() {
        return new HashCodeBuilder().append(edge).append(node).hashCode();

    }
}
