package struclust.repselection;

import graph.Graph;

import java.util.ArrayList;
import java.util.List;

import struclust.Cluster;
import struclust.Describable;
import struclust.graph.GraphContainer;

/**
 * A strategy to select a subset of representatives from a larger set of
 * representatives. The selected representatives should be good for the given
 * cluster.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface RepSelectionStrategy<NL, EL, G extends Graph<NL, EL>> extends Describable {

    /**
     * Select representatives for a cluster.
     * 
     * @param cluster
     *            The cluster with its old representatives. It is not modified
     *            by this strategy, i.e. the representatives are not replaced.
     * @param newReps
     *            The newly generated representatives. They should not be mixed
     *            with the old cluster representatives, so that the selection
     *            strategy can distinguish between them.
     * @param clustering
     *            the complete clustering (including the cluster to clalculate
     *            the representatives for).
     * 
     * @return a selection of representatives
     */
    public ArrayList<GraphContainer<NL, EL, G>> select(Cluster<NL, EL, G> cluster,
            ArrayList<GraphContainer<NL, EL, G>> newReps, List<Cluster<NL, EL, G>> clustering);

}
