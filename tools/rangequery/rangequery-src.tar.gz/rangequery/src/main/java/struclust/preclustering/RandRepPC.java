package struclust.preclustering;

import graph.Graph;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import struclust.comparison.GraphGraphDistance;
import struclust.graph.GraphContainer;

import com.google.common.base.Preconditions;

/**
 * This PreClustering draws a random sample from the graphs and uses each sample
 * graph as a cluster representative. Than each graph is put to the cluster with
 * the smallest distance to its representative.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class RandRepPC<NL, EL, G extends Graph<NL, EL>> implements PreClustering<NL, EL, G> {
    private static final Logger logger = LoggerFactory.getLogger(RandRepPC.class);

    private int quantity;
    private GraphGraphDistance<NL, EL, G> gDist;

    /**
     * Constructor
     * 
     * @param quantity
     *            the number of clusters to create
     * @param gDist
     *            the {@link GraphGraphDistance}
     */
    public RandRepPC(int quantity, GraphGraphDistance<NL, EL, G> gDist) {
        this.quantity = quantity;
        this.gDist = gDist;
    }

    @Override
    public List<? extends List<GraphContainer<NL, EL, G>>> calc(ArrayList<GraphContainer<NL, EL, G>> graphs) {
        return calc(graphs, quantity);
    }

    @Override
    public String getDescription() {
        return "Random Representative PreClustering";
    }

    @Override
    public List<? extends List<GraphContainer<NL, EL, G>>> calc(ArrayList<GraphContainer<NL, EL, G>> graphs,
            int numClusters) {
        Preconditions.checkArgument(graphs.size() >= numClusters,
                "The quantitiy cannot be less than the number of elements to cluster");

        HashSet<GraphContainer<NL, EL, G>> sample = new HashSet<>(numClusters);
        int n = graphs.size();
        for (int i = n - numClusters; i < n; i++) {
            // RAND: draw random representative
            int pos = ThreadLocalRandom.current().nextInt(i + 1);
            GraphContainer<NL, EL, G> item = graphs.get(pos);
            if (sample.contains(item))
                sample.add(graphs.get(i));
            else
                sample.add(item);
        }

        ArrayList<GraphContainer<NL, EL, G>> reps = new ArrayList<>(sample);
        ArrayList<LinkedList<GraphContainer<NL, EL, G>>> retVal = new ArrayList<>();
        for (int i = 0; i < numClusters; i++) {
            retVal.add(new LinkedList<GraphContainer<NL, EL, G>>());
        }

        int nonDistinct = 0;
        for (GraphContainer<NL, EL, G> graph : graphs) {
            double minDist = Double.POSITIVE_INFINITY;
            int minRep = -1;
            boolean distinct = true;
            for (int i = 0; i < numClusters; i++) {
                double dist = gDist.calc(reps.get(i), graph);
                if (dist < minDist) {
                    minDist = dist;
                    minRep = i;
                } else if (dist == minDist) {
                    distinct = false;
                }
            }
            if (!distinct) {
                nonDistinct++;
            }
            retVal.get(minRep).add(graph);
        }
        logger.debug("Non-distinct distances: {}", nonDistinct);

        return retVal;
    }

}
