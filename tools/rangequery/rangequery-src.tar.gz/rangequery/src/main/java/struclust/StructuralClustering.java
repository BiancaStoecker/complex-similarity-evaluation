package struclust;

import java.util.List;

import graph.Graph;
import struclust.graph.GraphContainer;

/**
 * This is the interface for a (flat) structural clustering algorithm.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public interface StructuralClustering<NL, EL, G extends Graph<NL, EL>> extends Clustering<GraphContainer<NL, EL, G>> {
    /**
     * Calculate the Clustering
     * 
     * @return the {@link Cluster}s
     */
    @Override
    public List<Cluster<NL, EL, G>> calc();

    /**
     * @return the configuration of the clustering
     */
    @Override
    public StructuralClusteringConf<NL, EL, G> getConf();

    /**
     * Ensure that a fingerprint is calculated for each graph. Only calculates a
     * fingerprint if it has not been calculated before. This is automatically
     * called by at each clustering process, so this needs to be called from
     * externally only if one is interested in performance measurements.
     */
    public void calcFingerprints();

    /**
     * Updates the representatives for each cluster in clusters.
     * 
     * @param clusters
     *            the clusters for which the representatives should be updated
     */
    public void updateReps(List<Cluster<NL, EL, G>> clusters);
}
