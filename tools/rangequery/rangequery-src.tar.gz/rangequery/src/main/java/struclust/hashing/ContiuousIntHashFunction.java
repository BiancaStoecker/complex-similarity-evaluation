package struclust.hashing;

/**
 * A {@link HashFunction} that maps to a continuous integer value range
 * [0,{@link #maxValue()}].
 * 
 * @author Till Schäfer
 *
 * @param <K>
 *            the key type
 */
public interface ContiuousIntHashFunction<K> extends HashFunction<K, Integer> {
    /**
     * @return the {@link Integer} associated with the maximal value
     */
    public Integer maxValue();
}
