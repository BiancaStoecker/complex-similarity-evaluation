package struclust.mining;

/**
 * Stores the counting of occurrences of substructures in graphs. It stores the
 * graph count, which is the number of graphs that contain the substructure and
 * the maxCountInGraph which is the maximum number of occurrences in a single
 * graph.
 * 
 * @author Till Schäfer
 */
public class GraphCount {
    private int graphCount = 1;
    private int maxCountInGraph;

    /**
     * Constructor
     */
    public GraphCount() {
        maxCountInGraph = 1;
    }

    /**
     * Constructor
     * 
     * @param maxCountInGraph
     *            the initial value of
     */
    public GraphCount(int maxCountInGraph) {
        this.maxCountInGraph = maxCountInGraph;
    }

    /**
     * @return the number of graphs which contain a substructure
     */
    public int getGraphCount() {
        return graphCount;
    }

    /**
     * @return the maximum count in a single graph
     */
    public int getMaxCountInGraph() {
        return maxCountInGraph;
    }

    /**
     * Increments the graph count.
     */
    public void incrementGraphCount() {
        ++graphCount;
    }

    /**
     * Calculated the new maximum occurances in a single graph based on the
     * current maximum and value
     * 
     * @param value
     *            the value
     */
    public void updateMaxCountInGraph(int value) {
        maxCountInGraph = Math.max(maxCountInGraph, value);
    }

    /**
     * Resets the counts
     */
    public void reset() {
        graphCount = 0;
        maxCountInGraph = 0;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("(");
        builder.append(graphCount);
        builder.append(",");
        builder.append(maxCountInGraph);
        builder.append(")");
        return builder.toString();
    }
}
