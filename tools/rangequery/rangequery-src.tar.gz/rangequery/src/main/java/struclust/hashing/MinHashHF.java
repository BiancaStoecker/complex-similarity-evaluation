package struclust.hashing;

import java.util.Set;

/**
 * A MinHash implementation. To determine the key form the key set with minimum
 * value an underlying {@link PerfectHashFunction} is used. For this reason, it
 * is required that the value type of the underlying {@link PerfectHashFunction}
 * is {@link Comparable}.
 * 
 * @author Till Schäfer
 * @param <K>
 *            the key element type
 * @param <V>
 *            the value type of the internal {@link PerfectHashFunction} for
 *            random permutation of the key element universe
 */
public class MinHashHF<K, V extends Comparable<V>> implements HashFunction<Set<K>, K> {

    protected PerfectHashFunction<K, V> hf;

    /**
     * constructor
     * 
     * @param hf
     *            the underlying {@link PerfectHashFunction} for random
     *            permutation of the key element universe
     */
    public MinHashHF(PerfectHashFunction<K, V> hf) {
        this.hf = hf;
    }

    @Override
    public K hash(Set<K> key) {
        assert key != null;
        assert !key.isEmpty() : "hash function is undefined for empty sets";

        K randElem = key.iterator().next();
        K minKey = randElem;
        V minHashVal = hf.hash(randElem);

        for (K k : key) {
            V hashValK = hf.hash(k);
            if (minHashVal.compareTo(hashValK) > 0) {
                minKey = k;
                minHashVal = hashValK;
            }
        }
        return minKey;
    }

    @Override
    public String getDescription() {
        return "MinHashHF (PerfectHashFunction: " + hf.getDescription() + ")";
    }

}
