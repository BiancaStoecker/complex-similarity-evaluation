package struclust.mining;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadLocalRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.HashMultimap;
import com.google.common.util.concurrent.ThreadFactoryBuilder;

import graph.Edge;
import graph.Graph;
import graph.GraphFactory;
import graph.GraphSize;
import graph.LabelEdge;
import graph.Node;
import struclust.SharedMemorySCC;
import struclust.datastructures.CountingInt;
import struclust.datastructures.MutableInt;
import struclust.datastructures.SwappingArrayList;
import struclust.eval.EvalResult;
import struclust.graph.GraphContainer;
import struclust.graph.Graphs;
import struclust.util.Concurrent;

/**
 * Mining of random maximal or optimal frequent subgraphs.
 * 
 * @author Till Schäfer
 * 
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
public class RandomGM<NL, EL, G extends Graph<NL, EL>> implements FrequentGraphMiner<NL, EL, G> {
    private final Logger logger = LoggerFactory.getLogger(RandomGM.class);

    private RandomGMConf<NL, EL, G> conf;
    private ExecutorService fixedPool;

    /**
     * Constructor
     * 
     * @param gmParameters
     *            the configuration
     */
    public RandomGM(GraphMinerConf<NL, EL, G> gmParameters) {
        setConf(gmParameters);
    }

    @Override
    public void setConf(GraphMinerConf<NL, EL, G> conf) {
        Preconditions.checkArgument(conf.getClass() == RandomGMConf.class, "invalid parameter type");
        this.conf = (RandomGMConf<NL, EL, G>) conf;
        final ThreadFactory threadFactory = new ThreadFactoryBuilder().setNameFormat("SingleMiner-%d").setDaemon(true)
                .build();
        this.fixedPool = Executors.newFixedThreadPool(this.conf.getParallelism(), threadFactory);
    }

    @Override
    public RandomGMConf<NL, EL, G> getConf() {
        return conf;
    }

    /**
     * Mines random frequent maximal subgraphs.
     * 
     * @param graphs
     *            the {@link Graph}s to mine
     * @param count
     *            the number of subgraphs that should be mined
     * 
     * @return the mined subgraphs or an empty list, if no frequent subgraph
     *         with size (number of edges) >= 1 exist
     */
    @Override
    public ArrayList<GraphContainer<NL, EL, G>> mineGraphs(List<GraphContainer<NL, EL, G>> graphs, int count,
            double minSup) {
        assert graphs.stream().filter(g -> g.size(GraphSize.nodes) == 0).count() == 0;

        Date startDate = new Date();

        ArrayList<GraphContainer<NL, EL, G>> retVal = new ArrayList<>(count);

        HashMap<LabelEdge<NL, EL>, GraphCount> edgeFrequency = calculateEdgeFreuqency(graphs);
        ArrayList<LabelEdge<NL, EL>> frequentEdges = frequentEdges(graphs, minSup, edgeFrequency);

        // There is no frequent Graph
        if (frequentEdges.isEmpty()) {
            logger.debug("no freuqent subgraph found");
            return retVal;
        }

        HashMultimap<NL, NodeEdgelabelPair<NL, EL>> edgeMap = calculateEdgeMap(frequentEdges);
        int supportedCallEstimation = conf.supCallsEstimator.estimate(graphs, minSup, edgeMap);

        if (conf.parallel) {
            // PARALLEL: mine single graph
            List<Future<G>> futures = new ArrayList<>(count);

            for (int i = 0; i < count; i++) {
                futures.add(fixedPool.submit(new SingleMiner(graphs, minSup, edgeFrequency, frequentEdges, edgeMap,
                        supportedCallEstimation)));
            }

            for (Future<G> future : futures) {
                try {
                    G structure = future.get();
                    retVal.add(new GraphContainer<>(structure));
                } catch (InterruptedException e) {
                    logger.warn("mineGraphs aborted");
                } catch (ExecutionException e) {
                    logger.error("Error while mining single graphs in parallel", e);
                    throw new RuntimeException("ExecutionException while mining single graphs in parallel", e);
                }
            }

        } else {
            for (int i = 0; i < count; i++) {
                G structure = mineSingleSubstructure(graphs, minSup, edgeFrequency, frequentEdges, edgeMap,
                        supportedCallEstimation);
                retVal.add(new GraphContainer<>(structure));
            }
        }

        Date endDate = new Date();
        long difference = endDate.getTime() - startDate.getTime();
        if (logger.isDebugEnabled()) {
            logger.debug("Number of Graphs: " + graphs.size());
            logger.debug("Number of distinct edges: " + edgeFrequency.size());
            logger.debug("Number of freuqent (" + minSup * 100 + "%) edges: " + frequentEdges.size());
            logger.debug("=> Overall Mining Time in msec: " + difference);
        }

        return retVal;
    }

    @Override
    public String getDescription() {
        return "Random Graph Miner";
    }

    private G mineSingleSubstructure(List<GraphContainer<NL, EL, G>> graphs, double minSup,
            HashMap<LabelEdge<NL, EL>, GraphCount> edgeFrequency, ArrayList<LabelEdge<NL, EL>> frequentEdges,
            HashMultimap<NL, NodeEdgelabelPair<NL, EL>> edgeMap, int supportedCallEstimation) {
        /*
         * The (maximal) frequent substructure to mine
         */
        G miningStructure = conf.gFactory.create();

        /*
         * The substructure with the highest score (support x size)
         */
        G maxScoreStructure = null;
        double maxScore = Double.NEGATIVE_INFINITY;

        /*
         * Contains all nodes that are not expired (there are still possible
         * extensions from this node). This list is unordered (i.e. the ordering
         * can change arbitrary)
         */
        SwappingArrayList<Node<NL, EL>> activeNodes = new SwappingArrayList<>();

        /*
         * Stores and manages the extensions per node
         */
        HashMap<Node<NL, EL>, NodeExtender<NL, EL>> extensions = new HashMap<>();

        /*
         * NL -> All Nodes with this label in retVal
         */
        ArrayListMultimap<NL, Node<NL, EL>> nodesWithLabel = ArrayListMultimap.create();

        /*
         * LabelEdge -> Count in current Subgraph
         */
        HashMap<LabelEdge<NL, EL>, CountingInt> labelEdgeCount = new HashMap<>();

        /*
         * RAND: create starting substructure (first node of previously selected
         * frequent edge)
         */
        LabelEdge<NL, EL> randEdge = frequentEdges.get(ThreadLocalRandom.current().nextInt(frequentEdges.size()));
        addNewNode(miningStructure, randEdge.getFirstNodeLabel(), activeNodes, nodesWithLabel);
        if (conf.useSupSizeProduct) {
            maxScoreStructure = conf.gFactory.clone(miningStructure);
        }

        /*
         * Main extension loop
         * 
         * Extend the substructure until it is maximal
         */
        SupportCounting<NL, EL, G> supportCounting = conf.supportCounting;
        while (!activeNodes.isEmpty() && miningStructure.size(conf.gSize) <= conf.maxSubGraphSize) {
            // RAND: draw random node for extension
            int extensionNodeIndex = ThreadLocalRandom.current().nextInt(activeNodes.size());
            Node<NL, EL> randActiveNode = activeNodes.get(extensionNodeIndex);

            /*
             * RAND: get the extension selector or create a new one if it does
             * not exist
             */
            NodeExtender<NL, EL> extender = getExtender(edgeFrequency, edgeMap, miningStructure, extensions,
                    nodesWithLabel, labelEdgeCount, randActiveNode, ThreadLocalRandom.current());

            // extend randActiveNode if possible
            NodeEdgePair<NL, EL> nextExtension = extender.nextExtension();
            assert Graphs.isSelfLoopFree(miningStructure) : "self loop detected";

            boolean noExtensionPossible = nextExtension.edge == null;
            if (noExtensionPossible) {
                activeNodes.swapAndRemove(extensionNodeIndex);
                continue;
            }

            // count the support
            if (!supportCounting.supported(graphs, miningStructure, minSup, supportedCallEstimation, false)) {
                extender.failLastExtension();
            } else {
                // inform the node extender, that the extension is successful
                extender.permanentlyApplyExtension();

                if (conf.useSupSizeProduct) {
                    double sup = supportCounting.support(graphs, miningStructure, false);
                    double score = sup * miningStructure.size(conf.gSize);
                    if (score > maxScore) {
                        maxScoreStructure = conf.gFactory.clone(miningStructure);
                        maxScore = score;
                    }
                }

                boolean wasForwardExtension = nextExtension.node != null;
                if (wasForwardExtension) {
                    activeNodes.add(nextExtension.node);
                }
            }
        }

        assert conf.useSupSizeProduct ? maxScoreStructure != null : miningStructure != null;
        return conf.useSupSizeProduct ? maxScoreStructure : miningStructure;
    }

    /**
     * Convenience method to get an extender for a node, if the extender does
     * not exist, it will be created.
     * 
     * @param edgeFrequency
     * @param edgeMap
     * @param graph
     * @param extensions
     * @param nodesWithLabel
     * @param labelEdgeCount
     * @param extNode
     *            the node to get the extender for
     * @param rand
     * @return
     */
    static <NL, EL, G extends Graph<NL, EL>> NodeExtender<NL, EL> getExtender(
            HashMap<LabelEdge<NL, EL>, GraphCount> edgeFrequency, HashMultimap<NL, NodeEdgelabelPair<NL, EL>> edgeMap,
            G graph, HashMap<Node<NL, EL>, NodeExtender<NL, EL>> extensions,
            ArrayListMultimap<NL, Node<NL, EL>> nodesWithLabel, HashMap<LabelEdge<NL, EL>, CountingInt> labelEdgeCount,
            Node<NL, EL> extNode, Random rand) {
        NodeExtender<NL, EL> extender = extensions.get(extNode);
        if (extender == null) {
            extender = new NodeExtender<>(graph, extNode, edgeFrequency, labelEdgeCount, edgeMap, nodesWithLabel,
                    rand, extensions);
            extensions.put(extNode, extender);
        }
        return extender;
    }

    /**
     * Convenience method: Adds a node to the list of active nodes and to the
     * map from its label the the node
     * 
     * @param graph
     *            the graph to add the new Node
     * @param nodeLabel
     *            the nodes Label
     * @param activeNodes
     *            the active Nodes
     * @param nodesWithLabel
     *            the map form label to node
     * @param node
     *            the node itself
     */
    private Node<NL, EL> addNewNode(G graph, NL nodeLabel, ArrayList<Node<NL, EL>> activeNodes,
            ArrayListMultimap<NL, Node<NL, EL>> nodesWithLabel) {
        Node<NL, EL> node = graph.addNode(nodeLabel);
        activeNodes.add(node);
        nodesWithLabel.put(node.getLabel(), node);
        return node;
    }

    /**
     * Calculates the frequency and maxCount for each edge which is a
     * substructure of graphs. Frequency is the number of graphs which contain
     * the edge and maxCount is the maximum number of occurrences in a single
     * graph.
     * 
     * @return a map from edge to (frequency,maxCount)
     */
    private HashMap<LabelEdge<NL, EL>, GraphCount> calculateEdgeFreuqency(List<GraphContainer<NL, EL, G>> graphs) {
        HashMap<LabelEdge<NL, EL>, GraphCount> retVal = new HashMap<>();
        for (GraphContainer<NL, EL, G> graph : graphs) {
            HashMap<LabelEdge<NL, EL>, CountingInt> perGraphCount = new HashMap<>();
            // count the egdes for a single graph
            for (Edge<NL, EL> edge : graph.edges()) {
                LabelEdge<NL, EL> le = new LabelEdge<>(edge);
                CountingInt count = perGraphCount.get(le);
                if (count == null) {
                    perGraphCount.put(le, new CountingInt());
                } else {
                    count.increment();
                }
            }
            /*
             * update global graph count based on single graph count (only a
             * single entry is counted per graph; update maxCountInGraph)
             */
            for (Entry<LabelEdge<NL, EL>, CountingInt> entry : perGraphCount.entrySet()) {
                GraphCount graphCount = retVal.get(entry.getKey());
                int currentGraphCount = entry.getValue().get();
                if (graphCount == null) {
                    retVal.put(entry.getKey(), new GraphCount(currentGraphCount));
                } else {
                    graphCount.incrementGraphCount();
                    graphCount.updateMaxCountInGraph(currentGraphCount);
                }
            }
        }
        return retVal;
    }

    /**
     * Filters a Map of (edge, counts) to a set of edges which have a support of
     * at least support.
     * 
     * @param counts
     *            the counts for each edge
     * @param size
     *            the total number of graphs
     * @param support
     *            the minimum support level
     * @return a set of frequent edges
     */
    private ArrayList<LabelEdge<NL, EL>> frequentEdges(List<GraphContainer<NL, EL, G>> graphs, double minSup,
            HashMap<LabelEdge<NL, EL>, GraphCount> counts) {
        ArrayList<LabelEdge<NL, EL>> retVal = new ArrayList<>();
        double absMinSup = graphs.size() * minSup;

        for (Entry<LabelEdge<NL, EL>, GraphCount> entry : counts.entrySet()) {
            if (entry.getValue().getGraphCount() >= absMinSup) {
                retVal.add(entry.getKey());
            }
        }

        return retVal;
    }

    /**
     * Calculates the edge map from ORIGAMI for a collection of edges (usually
     * frequent edges).
     * 
     * Edge Map: Node Label -> (Edge Label, Other Nodes Label)
     * 
     * @param frequentEdges
     *            the frequent edges
     * @return the edge map
     */
    private HashMultimap<NL, NodeEdgelabelPair<NL, EL>> calculateEdgeMap(Collection<LabelEdge<NL, EL>> frequentEdges) {
        HashMultimap<NL, NodeEdgelabelPair<NL, EL>> retVal = HashMultimap.create();
        for (LabelEdge<NL, EL> labelEdge : frequentEdges) {
            retVal.put(labelEdge.getFirstNodeLabel(), new NodeEdgelabelPair<>(labelEdge.getSecondNodeLabel(),
                    labelEdge.getEdgeLabel()));
            retVal.put(labelEdge.getSecondNodeLabel(), new NodeEdgelabelPair<>(labelEdge.getFirstNodeLabel(),
                    labelEdge.getEdgeLabel()));
        }

        return retVal;
    }

    /**
     * Calculates the EdgeMap from ORIGAMI for all edges in all graphs. This
     * means we calculate for each node label, to which (edge label, other node
     * label) pairs it is adjacent.
     * 
     * Edge Map: Node Label -> (Edge Label, Other Nodes Label)
     * 
     * Note: This implementation is slow in comparison with the implementation
     * for frequent edges only, but it does not require already calculated
     * frequent edges as a parameter
     * 
     * @return the edge map
     */
    @SuppressWarnings("unused")
    private HashMultimap<NL, NodeEdgelabelPair<NL, EL>> calculateEdgeMap(List<GraphContainer<NL, EL, G>> graphs) {
        HashMultimap<NL, NodeEdgelabelPair<NL, EL>> retVal = HashMultimap.create();
        for (Graph<NL, EL> graph : graphs) {
            for (Node<NL, EL> node : graph.nodes()) {
                NL sourceNodeLabel = node.getLabel();
                for (Edge<NL, EL> edge : node.getEdges()) {
                    retVal.put(sourceNodeLabel, new NodeEdgelabelPair<>(edge.getOppositeNode(node).getLabel(),
                            edge.getLabel()));
                }
            }
        }
        return retVal;
    }

    /**
     * The parameters (i.e. configuration / settings) for this miner.
     * 
     * @author Till Schäfer
     * 
     * @param <NL>
     *            the node label type
     * @param <EL>
     *            the edge label type
     * @param <G>
     *            the graph type
     */
    static public class RandomGMConf<NL, EL, G extends Graph<NL, EL>> extends GraphMinerConf<NL, EL, G> {
        private MutableInt parallelism;

        /**
         * Constructor.<br>
         * 
         * The support counting from struclustConf is used.
         * 
         * @param gFactory
         *            the {@link GraphFactory} of G
         * @param struclustConf
         *            the StruClust {@link SharedMemorySCC}.
         */
        public RandomGMConf(GraphFactory<NL, EL, G> gFactory, SharedMemorySCC<NL, EL, G> struclustConf) {
            this.gFactory = gFactory;
            this.parallelism = struclustConf.parallelism;
            this.supportCounting = struclustConf.supportCounting;
            this.maxSubGraphSize = struclustConf.maxRepSize;
            if (supportCounting != null && supportCounting.getClass() == CorrectedBinomialSC.class) {
                supCallsEstimator = new ConservativeSCE<>();
            }
            this.gSize = struclustConf.gSize;
        }

        /**
         * Constructor.<br>
         * 
         * The support counting from struclustConf is used.
         * 
         * @param gFactory
         *            the {@link GraphFactory} of G
         * @param parallelism
         *            the parallelism (how many threads are generated for each
         *            thread pool)
         */
        public RandomGMConf(GraphFactory<NL, EL, G> gFactory, MutableInt parallelism) {
            this.gFactory = gFactory;
            this.parallelism = parallelism;
            supportCounting = new BinomialSC<>(0.01, parallelism);
        }

        /**
         * @return the effective parallelism (see
         *         {@link Concurrent#getEffectiveParallelism(int)})
         */
        public int getParallelism() {
            return Concurrent.getEffectiveParallelism(parallelism.get());
        }

        /**
         * A {@link GraphFactory} for G
         */
        public GraphFactory<NL, EL, G> gFactory;

        /**
         * The way the graph size is counted. Only affects useSupSizeProduct so
         * far.
         */
        public GraphSize gSize = GraphSize.edges;
        
        /**
         * the maximal size of the mined subgraphs 
         */
        public int maxSubGraphSize = Integer.MAX_VALUE;

        /**
         * {@link SupportCounting} module
         */
        public SupportCounting<NL, EL, G> supportCounting;

        /**
         * Estimator for the number of calls of
         * {@link SupportCounting#supported(List, Graph, double, int, boolean)}
         */
        public SupportedCallsEstimator<NL, EL, G> supCallsEstimator = new FakeSCE<>();

        /**
         * if this is set to true, the miner will return the structure with the
         * highest size*support value instead of the maximal frequent
         * substructure. Attention: This will require an exact support value
         * calculation for each successful extension and therefore will lead to
         * a higher runtime.
         */
        public boolean useSupSizeProduct = false;

        /**
         * If set to true, each single subgraph will be mined in parallel
         */
        public boolean parallel = true;

        @Override
        public void addAsMetadata(EvalResult result) {
            result.addMetadata("RandGM: graph size counting", gSize.name());
            result.addMetadata("RandGM: maxSubGraphSize", maxSubGraphSize);
            result.addMetadata("RandGM: supportCounting", supportCounting.getDescription());
            result.addMetadata("RandGM: supCallsEstimator", supCallsEstimator.getDescription());
            result.addMetadata("RandGM: useSupSizeProduct", useSupSizeProduct);
            result.addMetadata("RandGM: parallel", parallel);
        }
    }

    /**
     * {@link Callable} to mine each single graph in parallel.
     * 
     * @author Till Schäfer
     */
    private class SingleMiner implements Callable<G> {
        private List<GraphContainer<NL, EL, G>> graphs;
        double minSup;
        private HashMap<LabelEdge<NL, EL>, GraphCount> edgeFrequency;
        private ArrayList<LabelEdge<NL, EL>> frequentEdges;
        private HashMultimap<NL, NodeEdgelabelPair<NL, EL>> edgeMap;
        private int supportedCallEstimation;

        /**
         * Constructor
         * 
         * see
         * {@link RandomGM#mineSingleSubstructure(List, double, HashMap, ArrayList, HashMultimap, int)}
         * for parameter description
         * 
         * @param graphs
         * @param minSup
         * @param edgeFrequency
         * @param frequentEdges
         * @param edgeMap
         * @param supportedCallEstimation
         */
        public SingleMiner(List<GraphContainer<NL, EL, G>> graphs, double minSup,
                HashMap<LabelEdge<NL, EL>, GraphCount> edgeFrequency, ArrayList<LabelEdge<NL, EL>> frequentEdges,
                HashMultimap<NL, NodeEdgelabelPair<NL, EL>> edgeMap, int supportedCallEstimation) {
            this.graphs = graphs;
            this.minSup = minSup;
            this.edgeFrequency = edgeFrequency;
            this.frequentEdges = frequentEdges;
            this.edgeMap = edgeMap;
            this.supportedCallEstimation = supportedCallEstimation;
        }

        @Override
        public G call() {
            return mineSingleSubstructure(graphs, minSup, edgeFrequency, frequentEdges, edgeMap,
                    supportedCallEstimation);
        }

    }

}
