package patterncover;

import graph.DefaultGraph;
import graph.Edge;
import graph.Graph;
import graph.Node;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import match.Matcher;
import match.MatcherVF2;
import match.NodePair;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Stores the distance metric function for a sequence of host graphs and a set of patterns
 * @author Markus Kloss
 *
 * @param <NL> The node label
 * @param <EL> The edge label
 */
public class GraphDistance<NL, EL> {
    
    private static final Logger logger = LoggerFactory.getLogger(GraphDistance.class);
    
    protected Map<Graph<NL, EL>, Matcher<NL, EL>> PatternMatchers;
    
    /** 
     * Initializes the class with empty input lists
     */
    public GraphDistance()
    {
        this.PatternMatchers = new HashMap<Graph<NL, EL>, Matcher<NL, EL>>();        
    }
    
    /**
     * Initializes the class with given sequences of host graphs and patterns
     * @param hostGraphList A list of host graphs
     * @param patternList A list of patterns
     */
    public GraphDistance(LinkedList<Graph<NL, EL>> hostGraphList, LinkedList<Graph<NL, EL>> patternList)
    {       
        this.PatternMatchers = new HashMap<Graph<NL, EL>, Matcher<NL, EL>>();
    }
    
    private void generatePatternMatcher(Graph<NL, EL> pattern) {
        this.PatternMatchers.put(pattern, new MatcherVF2(pattern, null));        
    }
    
    /**
     * Calculates the graph cover for each host graph given the patterns
     * 
     * % Deletes former calculated graph covers!
     */
    public List<GraphCoverPair<NL, EL>> calculateGraphCovers(List<? extends Graph<NL, EL>> hostGraphList, List<? extends Graph<NL, EL>> patternList)
    {
        LinkedList<GraphCoverPair<NL, EL>> graphCoverPairs = new LinkedList<GraphCoverPair<NL, EL>>();
        for(Graph<NL, EL> graph : hostGraphList)
        {
            LinkedList<GraphPatternCover<NL, EL>> patternCovers = new LinkedList<GraphPatternCover<NL, EL>>();
            
            // Collect all matches for the host graph
            for(Graph<NL, EL> pattern : patternList)
            {
                //TODO: Automorphismen-Berechnung wird fuer jeden Graphen neu gemacht -> Neue Struktur noetig (Klasse mit Conditions fuer jedes Pattern oder so, Moeglichkeit Conditions zu setzen)
                GraphPatternCover<NL, EL> gpc = new GraphPatternCover<NL, EL>(graph, pattern);
                gpc.generateMatches();
                //gpc.calculateCoverSubgraph();
                
                patternCovers.add(gpc);
            }
            
            Graph<NL, EL> hostGraphCover = this.calculateCover(graph, patternCovers);
            
            GraphCoverPair<NL, EL> coverPair = new GraphCoverPair<NL, EL>(graph, hostGraphCover);
            graphCoverPairs.add(coverPair);
        }
        
        return graphCoverPairs;
    }

    /**
     * Calculates the cover for each pair of graphs and its matches corresponding to the patterns
     * @param graph A host {@link Graph}
     * @param patternCovers The {@link PatternCoverGraph} objects of the host graph
     * @return The cover subgraph of the host {@link Graph}
     */
    private Graph<NL, EL> calculateCover(Graph<NL, EL> graph, LinkedList<GraphPatternCover<NL, EL>> patternCovers) 
    {
        LinkedList<Node<NL, EL>> coveredHostNodes = new LinkedList<Node<NL, EL>>();
        LinkedList<Edge<NL, EL>> coveredHostEdges = new LinkedList<Edge<NL, EL>>();
        
        // Generate lists of covered nodes and edges of the host graph:
        //logger.info("Found matches: "+matchesOfHostGraph.size() );
        for(GraphPatternCover<NL, EL> gpc : patternCovers)
        {
            logger.info("Found matches for pattern: "+gpc.getMatches().size() );
            for(LinkedList<NodePair<NL, EL>> match : gpc.getMatches())
            {
                // Necessary to copy call by reference node list
                List<Node<NL, EL>> hostGraphNodes = new LinkedList<Node<NL, EL>>();
                for(Node<NL,EL> node : graph.nodes())
                {
                    hostGraphNodes.add(node);
                }
                
                // Covered node list of each match necessary to fine covered edges of each match
                LinkedList<Node<NL, EL>> nonCoveredHostNodesOfMatch = new LinkedList<Node<NL, EL>>();
                for(NodePair<NL, EL> matchPair : match)
                {
                    if(hostGraphNodes.contains(matchPair.hostNode))
                    {
                        nonCoveredHostNodesOfMatch.add(matchPair.hostNode);
                        hostGraphNodes.remove(matchPair.hostNode);
                        
                        if(!coveredHostNodes.contains(matchPair.hostNode))
                        {
                            logger.info("New covered host node: "+matchPair.hostNode.toString() );
                            coveredHostNodes.add(matchPair.hostNode);
                        }
                    }
                }
                
                for(Edge<NL, EL> edge : graph.edges())
                {
                    if (!coveredHostEdges.contains(edge)) 
                    {
                        if (nonCoveredHostNodesOfMatch.contains(edge.getFirstNode()) && nonCoveredHostNodesOfMatch.contains(edge.getSecondNode())) 
                        {
                            // Checking if the edge has the same label as the edge in the pattern graph
                            Node<NL, EL> firstNodeOfPatternEdge = null;
                            Node<NL, EL> secondNodeOfPatternEdge = null;
                            for(NodePair<NL, EL> pair : match)
                            {
                                if(pair.hostNode.equals(edge.getFirstNode()))
                                {
                                    firstNodeOfPatternEdge = pair.patternNode;
                                }
                                if(pair.hostNode.equals(edge.getSecondNode()))
                                {
                                    secondNodeOfPatternEdge = pair.patternNode;
                                }
                            }
                            if (firstNodeOfPatternEdge != null && secondNodeOfPatternEdge != null) 
                            {
                                Edge<NL, EL> edgeInPatternGraph = gpc.getPattern().getEdge(firstNodeOfPatternEdge, secondNodeOfPatternEdge);
            
                                if (edgeInPatternGraph != null && edge.getLabel().equals(edgeInPatternGraph.getLabel())) 
                                {
                                    logger.info("New covered host edge: " + "(" + edge.getFirstNode() + ", "
                                            + edge.getSecondNode() + ")");
                                    coveredHostEdges.add(edge);
                                }
                            }
                        }
                    }
                }
            }
        }
              
        Map<Node<NL, EL>, Node<NL, EL>> nodeMap = new HashMap<Node<NL, EL>, Node<NL, EL>>();
        Graph<NL, EL> coverSubgraph = new DefaultGraph<NL, EL>();
        for(Node<NL, EL> hostNode : graph.nodes())
        {
            if(coveredHostNodes.contains(hostNode))
            {
                nodeMap.put(hostNode, coverSubgraph.addNode(hostNode.getLabel()));
            }
        }
        
        for(Edge<NL, EL> hostEdge : graph.edges())
        {
            if(coveredHostEdges.contains(hostEdge))
            {
                coverSubgraph.addEdge(nodeMap.get(hostEdge.getFirstNode()), nodeMap.get(hostEdge.getSecondNode()), hostEdge.getLabel());
            }
        }
        
        return coverSubgraph;
        
    }

//    /**
//     * Gets the cover of a given host {@link Graph}
//     * @param graph A host {@link Graph}
//     * @return The host {@link Graph} cover iff it has been calculated
//     */
//    public Graph<NL, EL> getCoverOfHostGraph(Graph<NL, EL> graph)
//    {
//        try
//        {
//            for(GraphCoverPair<NL, EL> pair : this.GraphCoverPairs)
//            {
//                if(pair.getGraph().equals(graph))
//                {
//                    return pair.getCover();
//                }
//                else
//                {
//                    throw new Exception();
//                }
//            }
//        }
//        catch(Exception e)
//        {
//            logger.error("The cover of the host graph has not yet been calculated or the host graph has not been added to the host graph list.");
//            return null;
//        }
//        return null;
//    }
}
