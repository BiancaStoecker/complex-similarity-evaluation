package match.pattern;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

/**
 * Labels used to represent the matching behavior of labels including wildcards.
 * 
 * @param <L>
 *            the label type
 * 
 */
public interface GraphQueryLabel<L> {

    /**
     * @param o
     *            a label
     * @return true iff this label matches the given label
     */
    public boolean matches(L o);

    /**
     * Represents the '*' wildcard label.
     */
    public class Wildcard implements GraphQueryLabel<String> {
        /**
         * Symbol of wildcard label.
         */
        public static final String WILDCARD_LABEL = "*";

        public boolean matches(String o) {
            return true;
        }

        @Override
        public String toString() {
            return WILDCARD_LABEL;
        }
    }

    /**
     * Represents a list of labels.
     * 
     * @param <L>
     *            the label type
     */
    public abstract class AbstractList<L> implements GraphQueryLabel<L> {

        HashSet<L> labelList;

        /**
         * Initializes a new instance with an empty list of labels.
         */
        public AbstractList() {
            labelList = new HashSet<>();
        }

        /**
         * Initializes a new instance with the given list of labels.
         * 
         * @param labelList
         *            list of labels
         */
        public AbstractList(Collection<L> labelList) {
            super();
            setLabelList(labelList);
        }

        /**
         * Initializes a new instance with the given list of labels.
         * 
         * @param labelList
         *            list of labels
         */
        public AbstractList(L[] labelList) {
            super();
            setLabelList(labelList);
        }

        /**
         * Changes the list of labels.
         * 
         * @param labelList
         *            the new list of labels
         */
        public void setLabelList(Collection<L> labelList) {
            this.labelList.clear();
            this.labelList.addAll(labelList);
        }

        /**
         * Changes the list of labels.
         * 
         * @param labelList
         *            the new list of labels
         */
        public void setLabelList(L[] labelList) {
            this.labelList.clear();
            for (L o : labelList) {
                this.labelList.add(o);
            }
        }

        /**
         * @return the collection of labels
         */
        public HashSet<L> getLabelList() {
            return labelList;
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append('[');
            if (!labelList.isEmpty()) {
                Iterator<L> i = labelList.iterator();
                sb.append(i.next());
                while (i.hasNext()) {
                    sb.append(",");
                    sb.append(i.next());
                }
            }
            sb.append(']');
            return sb.toString();
        }
    }

    /**
     * Matches all labels of the given list.
     * 
     * @param <L>
     *            the label type
     */
    public class List<L> extends AbstractList<L> {
        /**
         * Initializes a new instance with an empty list of allowed labels.
         */
        public List() {
            super();
        }

        /**
         * @param labelList
         *            allowed labels
         */
        public List(Collection<L> labelList) {
            super(labelList);
        }

        /**
         * @param labelList
         *            allowed labels
         */
        public List(L[] labelList) {
            super(labelList);
        }

        @Override
        public boolean matches(L o) {
            return labelList.contains(o);
        }
    }

    /**
     * Matches all labels except those in the list.
     * 
     * @param <L>
     *            the label type
     */
    public class NotList<L> extends AbstractList<L> {
        /**
         * Initializes a new instance with an empty list of forbidden labels.
         */
        public NotList() {
            super();
        }

        /**
         * @param labelList
         *            forbidden labels
         */
        public NotList(Collection<L> labelList) {
            super(labelList);
        }

        /**
         * @param labelList
         *            forbidden labels
         */
        public NotList(L[] labelList) {
            super(labelList);
        }

        @Override
        public boolean matches(L o) {
            return !labelList.contains(o);
        }

        @Override
        public String toString() {
            return "!" + super.toString();
        }
    }

}
