package match;

import java.util.LinkedList;

/**
 * Implementing classes specify how to process a found matching.
 * 
 * @see Matcher#setMatchDelegate(MatchDelegate)
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public interface MatchDelegate<NL, EL> {
	
	/**
     * This method specifies how to process a found mapping. If false is
     * returned the matching process will not abort when the first matching is
     * found. Note that in this case the function Matcher.match() will always
     * return false.
	 * 
     * @param pm
     *            the mapping found
     * @return true if the search should be aborted after the function call,
     *         return false for an exhaustive search
	 */
    public boolean handleMatch(PartialMapping<NL, EL> pm);
	
    /**
     * Prints all matches.
     * 
     * @param <NL>
     *            the node label type
     * @param <EL>
     *            the edge label type
     */
	public class PrintAll<NL, EL> implements MatchDelegate<NL, EL> {
		public boolean handleMatch(PartialMapping<NL, EL> pm) {
			for (NodePair<NL, EL> p : pm.getMapping())
                System.out.println(p.patternNode.getIndex() + " -> " + p.hostNode.getIndex());
			System.out.println("-----------------------");
			return false;
		}
	}
	
    /**
     * Stores a list of all matches.
     * 
     * @param <NL>
     *            the node label type
     * @param <EL>
     *            the edge label type
     */
	public class CollectAll<NL, EL> implements MatchDelegate<NL, EL> {
		private LinkedList<LinkedList<NodePair<NL, EL>>> matches;

        /**
         * Constructor.
         */
		public CollectAll() {
			matches = new LinkedList<>();
		}
		
		public boolean handleMatch(PartialMapping<NL, EL> pm) {
			matches.add(pm.getMapping());
			return false;
		}

        /**
         * Returns a list of all matching.
         * @return list of matchings
         */
		public LinkedList<LinkedList<NodePair<NL, EL>>> getMatches() {
			return matches;
		}
	}
	
    /**
     * Counts the number of matchings.
     * 
     * @param <NL>
     *            the node label type
     * @param <EL>
     *            the edge label type
     */
	public class CountAll<NL, EL> implements MatchDelegate<NL, EL> {
		private int count;

        /**
         * Constructor.
         */
		public CountAll() {
			count = 0;
		}
		
		public boolean handleMatch(PartialMapping<NL, EL> pm) {
			count++;
			return false;
		}

		/**
		 * @return the number of matchings
		 */
		public int getCount() {
			return count;
		}
	}
}

