package hsahn.comparison;

/**
 * Interface for the comparison of objects.
 * 
 * @author kriege
 *
 * @param <T> type of the objects that can be compared
 * by this implementation
 */
public interface DisSimilarity<T> {

	/**
	 * Computes the kernel for the given objects.
	 * @param g1 first object under comparison
	 * @param g2 second object under comparison
	 * @return the result of the kernel function
	 */
	public double compute(T g1, T g2);
		
}
