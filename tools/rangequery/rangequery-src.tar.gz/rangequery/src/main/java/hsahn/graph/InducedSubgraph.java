package hsahn.graph;

import java.util.BitSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

/**
 * Represents an induced subgraph G' of a graph G, i.e.
 * a graph containing a given subset of vertices of G and
 * all edges connecting vertices of the subset.
 * 
 * Note: This implementation does not copy the original graph
 * but provides another view on the original graph by
 * modifying methods "on-the-fly".
 * 
 * Warning: Vertices and Edges are the objects of the specified
 * graph and are not modified. Thus vertices and edges that are
 * not contained in the induced subgraph are still visible from 
 * these objects! 
 */
// TODO modify vertices and edges (see warning)!
// TODO create vertex and edge lists instead?
public class InducedSubgraph implements Graph {
	
	private Graph g;
	private BitSet vertices;
	
	public InducedSubgraph(Graph g, BitSet vertices) {
		this.g = g;
		this.vertices = vertices;
	}
	
	public InducedSubgraph(Graph g, Collection<Vertex> vertices) {
		this.g = g;
		this.vertices = new BitSet(g.getVertexCount());
		
		for (Vertex v : vertices) {
			this.vertices.set(v.getIndex());
		}
	}

	public Iterable<? extends Edge> edges() {
		return new Iterable<Edge>() {
			public Iterator<Edge> iterator() {
				return new Iterator<Edge>() {
					Iterator<? extends Edge> it = g.edges().iterator();
					Edge current;
					public boolean hasNext() {
						while (it.hasNext()) {
							current = it.next();
							if (vertices.get(current.getFirstVertex().getIndex()) &&
									vertices.get(current.getSecondVertex().getIndex()))
								return true;
						}
						return false;
					}
					public Edge next() {
						return current;
					}
					public void remove() {
						throw new UnsupportedOperationException();	
					}
				};
			}
		};
	}

	public Edge getEdge(int index) {
		Edge e = g.getEdge(index);
		if (e != null && vertices.get(e.getFirstVertex().getIndex()) &&
				vertices.get(e.getSecondVertex().getIndex()))
			return e;
		
		return null;
	}

	public Edge getEdge(Vertex u, Vertex v) {
		if (vertices.get(u.getIndex()) &&
				vertices.get(v.getIndex()))
			return g.getEdge(u, v);
		
		return null;
	}

	public int getEdgeCount() {
		return g.getEdgeCount();
		//throw new UnsupportedOperationException();
	}

	public Vertex getVertex(int index) {
		if (vertices.get(index))
			return g.getVertex(index);
		else
			return null;
	}

	//TODO
	public int getVertexCount() {
		// TODO required to allow VertexArrays
		// this is very ugly, the whole class is broken by design (may be the whole concept)
		return g.getVertexCount();
		//throw new UnsupportedOperationException();
		//return vertices.cardinality();
	}

	public boolean hasEdge(Vertex u, Vertex v) {
		return getEdge(u, v) != null;
	}

	public Iterable<? extends Vertex> vertices() {
		return new Iterable<Vertex>() {
			public Iterator<Vertex> iterator() {
				return new Iterator<Vertex>() {
					Iterator<? extends Vertex> it = g.vertices().iterator();
					Vertex current;
					public boolean hasNext() {
						while (it.hasNext()) {
							current = it.next();
							if (vertices.get(current.getIndex()))
								return true;
						}
						return false;
					}
					public Vertex next() {
						return current;
					}
					public void remove() {
						throw new UnsupportedOperationException();	
					}
				};
			}
		};
	}

	public String[] getProperties() {
		return g.getProperties();
	}
	
	public Object getProperty(String key) {
		return g.getProperty(key);
	}

	public void setProperty(String key, Object value) {
		g.setProperty(key, value);
	}

}
