package hsahn.comparison.kernel.graph;

import hsahn.comparison.kernel.basic.DiracKernel;

import java.util.Collection;

/**
 * Implementation of the Weisfeiler-Lehman Subtree Kernel (Shervashidze, 2011)
 * supporting 1:1 kernel evaluation as well as explicit mapping into feature
 * space for fast n:n computation.
 * 
 * @author kriege
 */
public class WeisfeilerLehmanSubtreeKernel<V, E> extends WeisfeilerLehmanKernel<V, E, Integer> {

    /**
     * Creates a new instance of the Weisfeiler-Lehmann subtree kernel.
     * 
     * @param sequenceSize
     *            the number of graphs in the computed WL sequence
     */
    public WeisfeilerLehmanSubtreeKernel(int sequenceSize) {
        super(sequenceSize, new VertexKernel<Integer, E>(new DiracKernel()), false);
    }

    /**
     * Creates a new instance of the Weisfeiler-Lehmann subtree kernel.
     * 
     * @param sequenceSize
     *            the number of graphs in the computed WL sequence
     * @param stableLabelConverter
     *            iff true {@link #computeExplicitMapping(Collection)} can be
     *            called multiple times without loosing the label mapping. i.e.
     *            the generated explicit mappings of different runs can be
     *            compared to each other. Be aware, that this can lead to many
     *            unused attributes in the feature vectors if the same kernel
     *            object is used for muiltiple datasets that should not be
     *            compared to each other.
     */
    public WeisfeilerLehmanSubtreeKernel(int sequenceSize, boolean stableLabelConverter) {
        super(sequenceSize, new VertexKernel<Integer, E>(new DiracKernel()), stableLabelConverter);
    }

    @Override
    public String toString() {
        return "Weisfeiler-Lehman subtree kernel:\n" + super.toString();
    }

    @Override
    public String getID() {
        return "WLS_" + sequenceSize;
    }
}
