package hsahn.graph;

import graph.Node;
import hsahn.graph.AdjListRootedTree.AdjListRTreeVertex;
import hsahn.graph.Graph.Edge;
import hsahn.graph.Graph.Vertex;
import hsahn.graph.properties.EdgeArray;
import hsahn.graph.properties.VertexArray;
import hsahn.graph.properties.VertexProperty;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Stack;

public class GraphTools {
	
	private static final long seed = 88686765;
	private static final 	Random rand = new Random(seed);
	

	/**
	 * Copies all vertices and edges from targetGraph into sourceGraph.
	 * The implementation of both graphs may differ.
	 * @param sourceGraph
	 * @param targetGraph
	 * @return a mapping of vertices from source to target
	 */
	// TODO preserve edge oder for each vertex!?
	// TODO more efficient implementation using indices? targetGraph must be empty? or use offsets!?
	public static Map<Vertex, Vertex> copyGraph(Graph sourceGraph, ExtendibleGraph targetGraph) {
		HashMap<Vertex, Vertex> sourceToTargetMap = new HashMap<Vertex, Vertex>();

		for (Vertex sv : sourceGraph.vertices()) {
			Vertex tv = targetGraph.createVertex();
			sourceToTargetMap.put(sv, tv);
		}
		
		for (Edge se : sourceGraph.edges()) {
			Vertex su = se.getFirstVertex();
			Vertex sv = se.getSecondVertex();
			Vertex tu = sourceToTargetMap.get(su);
			Vertex tv = sourceToTargetMap.get(sv);
			targetGraph.createEdge(tu, tv);
		}
		
		return sourceToTargetMap;
	}
	
	public static void addRandomGraph(int vertexCount, int edgeCount, ExtendibleGraph graph) {
		ArrayList<Vertex> vertices = new ArrayList<Vertex>(vertexCount);

		for (int i=0; i < vertexCount; i++) {
			Vertex v = graph.createVertex();
			vertices.add(v);
		}
		
		Vertex u, v;
		for (int i=0; i < edgeCount; i++) {
			do {
				u = vertices.get(rand.nextInt(vertexCount));
				v = vertices.get(rand.nextInt(vertexCount));
			} while (u == v || graph.hasEdge(u,v));

			graph.createEdge(u, v);
		}
	}
	
	public static void addGridGraph(int n, int m, ExtendibleGraph graph) {
		Vertex[][] vertices= new Vertex[n][m];

		for (int i=0; i<n; i++) {
			for (int j=0; j<m; j++) {
				vertices[i][j] = graph.createVertex();
			}
		}
		
		for (int i=0; i<n; i++) {
			for (int j=0; j<m-1; j++) {
				Vertex u = vertices[i][j];
				Vertex v = vertices[i][j+1];
				graph.createEdge(u, v);
			}
		}
		
		for (int i=0; i<n-1; i++) {
			for (int j=0; j<m; j++) {
				Vertex u = vertices[i][j];
				Vertex v = vertices[i+1][j];
				graph.createEdge(u, v);
			}
		}
	}
	
	public static void addRandomBinaryTree(int vertexCount, ExtendibleGraph graph) {
		Stack<Vertex> vertices = new Stack<Vertex>();
		
		for (int i=0; i < vertexCount; i++) {
			Vertex v = graph.createVertex();
			vertices.push(v);
		}
		
		ArrayList<Vertex> selectableParants = new ArrayList<Vertex>(vertexCount);
		Vertex root = vertices.pop();
		selectableParants.add(root);
		while (!vertices.isEmpty()) {
			Vertex v = vertices.pop();
			Vertex u = selectableParants.get(rand.nextInt(selectableParants.size()));
			graph.createEdge(u, v);
			selectableParants.add(v);
			if ((u == root && u.getDegree() == 2) || u.getDegree() == 3) {
				selectableParants.remove(u);
			}
		}
	}
	
	/**
	 * Creates a binary tree that is hard to layout with a transformed RT algorithm.
	 * 
	 * Note: Requires graph to be empty!
	 * @param vertexCount
	 * @param graph
	 */
	public static void addDegeneratedBinaryTree(ExtendibleGraph graph) {
		int vertexCount = 20;
		
		Vertex root = graph.createVertex();
		for (int i=0; i<=vertexCount; i++) {
			graph.createEdge(root, graph.createVertex());
		}
		
		Stack<Vertex> branches = new Stack<Vertex>();
		Stack<Vertex> ends = new Stack<Vertex>();
		Random r = new Random(1);
		for (int i=0; i<vertexCount/4; i++) {
			branches.add(graph.getVertex(r.nextInt(vertexCount/2)+1));
		}
		for (Vertex b : branches) {
			int i=0;
			Vertex end = b;
			ends.push(end);
			while (r.nextDouble()>i*0.01d) {
				Vertex newEnd = graph.createVertex();
				graph.createEdge(end, newEnd);
				end = newEnd;
				ends.pop();
				ends.push(end);
				i++;
			}
		}
		for (Vertex end : ends) {
			for (int i=0; i<8; i++) {
				graph.createEdge(end, graph.createVertex());
			}
		}
	}
	
	/**
	 * Adds the graph depicted on page 301 of
	 * "Algorithms on Trees and Graphs", Gabriel Valiente
	 */
	public static void addValienteCliqueGraph(ExtendibleGraph g) {
		int offset = g.getVertexCount();
		
		for (int i=0; i<7; i++)
			g.createVertex();
		
		g.createEdge(g.getVertex(offset+0), g.getVertex(offset+1));
		g.createEdge(g.getVertex(offset+0), g.getVertex(offset+2));
		g.createEdge(g.getVertex(offset+0), g.getVertex(offset+3));
		g.createEdge(g.getVertex(offset+0), g.getVertex(offset+5));
		g.createEdge(g.getVertex(offset+0), g.getVertex(offset+6));
		
		g.createEdge(g.getVertex(offset+1), g.getVertex(offset+3));
		g.createEdge(g.getVertex(offset+1), g.getVertex(offset+4));
		g.createEdge(g.getVertex(offset+1), g.getVertex(offset+6));
		
		g.createEdge(g.getVertex(offset+2), g.getVertex(offset+3));
		g.createEdge(g.getVertex(offset+2), g.getVertex(offset+5));
		g.createEdge(g.getVertex(offset+2), g.getVertex(offset+6));
		
		g.createEdge(g.getVertex(offset+3), g.getVertex(offset+4));
		g.createEdge(g.getVertex(offset+3), g.getVertex(offset+5));
		g.createEdge(g.getVertex(offset+3), g.getVertex(offset+6));
		
		g.createEdge(g.getVertex(offset+4), g.getVertex(offset+6));

		g.createEdge(g.getVertex(offset+5), g.getVertex(offset+6));
	}
	
	public static void addCompleteGraph(int vertexCount, ExtendibleGraph g) {
		int offset = g.getNextVertexIndex();
		
		for (int i=0; i<vertexCount; i++) {
			g.createVertex();
		}
		for (int i=0; i<vertexCount; i++) {
			Vertex u = g.getVertex(offset+i);
			for (int j=i+1; j<vertexCount; j++) {
				Vertex v = g.getVertex(offset+j);
				g.createEdge(u, v);
			}
		}
	}
	

	public static LGraph<String, String> createLineGraph(LGraph<?, ?> lg) {
		Graph g = lg.getGraph();
		VertexArray<?> va = lg.getVertexLabel();
		EdgeArray<?> ea = lg.getEdgeLabel();
		
		// the correct edge size should be 1/2 * \sum_v deg(v)*(deg(v)-1)
		ExtendibleGraph rg = new AdjListGraph(g.getEdgeCount(), 0);
		VertexArray<String> rva = new VertexArray<String>(rg);
		EdgeArray<String> rea = new EdgeArray<String>(rg);
		
		for (Edge e : g.edges()) {
			Vertex v = rg.createVertex();
			assert (e.getIndex() == v.getIndex());
			String lu = String.valueOf(va.get(e.getFirstVertex()));
			String lv = String.valueOf(va.get(e.getSecondVertex()));
			String label = lu.compareTo(lv) < 0 ? lu+String.valueOf(ea.get(e))+lv : lv+String.valueOf(ea.get(e))+lu;
			rva.set(v, label);
		}
		// TODO use indices and start most inner loop from i
		for (Vertex v : g.vertices()) {
			for (Edge e : v.edges()) {
				for (Edge f : v.edges()) {
					if (e.getOppositeVertex(v).getIndex() < f.getOppositeVertex(v).getIndex()) {
						Edge rge = rg.createEdge(rg.getVertex(e.getIndex()), rg.getVertex(f.getIndex()));
						rea.set(rge, String.valueOf(va.get(v)));
					}
				}				
			}
		}
		return new LGraph<String, String>(rg, rva, rea);
	}
	
	/**
	 * Generates vertex and edge labels which are uniformly distributed in
	 * {0, ..., edgeLabelCount-1} and {0, ..., vertexLabelCount-1}.
	 * @param g the graph to generate labels for
	 * @param edgeLabelCount the number of different edge labels
	 * @param vertexLabelCount the number of different vertex labels
	 * @return a labeled graph containing g together with the generated labels
	 */
	public static LGraph<Integer, Integer> createRandomLabeling(Graph g, int edgeLabelCount, int vertexLabelCount) {
		VertexArray<Integer> va = new VertexArray<Integer>(g);
		EdgeArray<Integer> ea = new EdgeArray<Integer>(g);

		for (Vertex v : g.vertices()) {
			va.set(v, rand.nextInt(vertexLabelCount));
		}
		for (Edge e : g.edges()) {
			ea.set(e, rand.nextInt(edgeLabelCount));
		}

		return new LGraph<Integer, Integer>(g, va, ea);
	}
	
	/**
	 * @see GraphTools#createRandomLabeling(Graph, int, int)
	 */
	public static LGraph<String, String> createRandomStringLabeling(Graph g, int edgeLabelCount, int vertexLabelCount) {
		VertexArray<String> va = new VertexArray<String>(g);
		EdgeArray<String> ea = new EdgeArray<String>(g);

		for (Vertex v : g.vertices()) {
			va.set(v, String.valueOf(rand.nextInt(vertexLabelCount)));
		}
		for (Edge e : g.edges()) {
			ea.set(e, String.valueOf(rand.nextInt(edgeLabelCount)));
		}

		return new LGraph<String, String>(g, va, ea);
	}
	
	public static AdjListGraph createInducedSubgraph(Graph g, Collection<Vertex> vertices) {
		// TODO 0 is not a good default value for the number of edges
		AdjListGraph r = new AdjListGraph(vertices.size(),0);
		copyGraph(new InducedSubgraph(g, vertices), r);
		return r;
	}
	
	public static AdjListGraph createInducedSubgraph2(Graph g, Collection<Vertex> vertices) {
		Subgraph sg = new Subgraph(g);
		for (Vertex v : vertices) {
			sg.createVertex(v);
		}
		for (Edge e : g.edges()) {
			Vertex u = e.getFirstVertex();
			Vertex v = e.getSecondVertex();
			if (vertices.contains(u) && vertices.contains(v)) {
				sg.createEdge(e);
			}
		}
		return sg;
	}
	
	public static LGraph<String, String> createInducedLabeledSubgraph(LGraph<?, ?> lg, Collection<Vertex> vertices) {
		Graph g = lg.getGraph();
		VertexArray<?> va = lg.getVertexLabel();
		EdgeArray<?> ea = lg.getEdgeLabel();
		
		AdjListGraph g2 = new AdjListGraph();
		VertexArray<String> va2 = new VertexArray<String>(g2);
		EdgeArray<String> ea2 = new EdgeArray<String>(g2);
		
		HashMap<Vertex, Vertex> sourceToTargetMap = new HashMap<Vertex, Vertex>();
		for (Vertex v : vertices) {
			Vertex v2 = g2.createVertex();
			va2.set(v2, va.get(v).toString());
			sourceToTargetMap.put(v, v2);
		}
		for (Edge e : g.edges()) {
			Vertex u = e.getFirstVertex();
			Vertex v = e.getSecondVertex();
			// TODO use hashset?
			if (vertices.contains(u) && vertices.contains(v)) {
				Vertex u2 = sourceToTargetMap.get(u);
				Vertex v2 = sourceToTargetMap.get(v);
				Edge e2 = g2.createEdge(u2, v2);
				ea2.set(e2, ea.get(e).toString());
			}
		}
		return new LGraph<String, String>(g2, va2, ea2);
	}
	
	/**
	 * Checks if a graph is connected.
	 * @param g a graph
	 * @return true iff g is connected
	 */
	public static boolean isConnected(Graph g) {
		if (g.getEdgeCount() < g.getVertexCount()-1)
			return false;
		
		if (g.getVertexCount() == 0)
			return true;
		
		VertexProperty<Integer> found = new VertexArray<Integer>(g);
		doDFS(g.getVertex(0), found, 1);
		for (Vertex v : g.vertices()) {
			if (found.get(v) != 1) return false;
		}
		
		return true;
	}
	
	public static LGraph<Integer, Integer> getIndexLabeledGraph(Graph g) {
		VertexArray<Integer> va = new VertexArray<Integer>(g);
		EdgeArray<Integer> ea = new EdgeArray<Integer>(g);
		for (Vertex v : g.vertices()) {
			va.set(v, v.getIndex());
		}
		for (Edge e : g.edges()) {
			ea.set(e, e.getIndex());
		}
		return new LGraph<Integer, Integer>(g, va, ea);
	}
	
	private static void doDFS(Vertex v, VertexProperty<Integer> found, int ccId) {
		found.set(v, ccId);
		for (Vertex w : v.neighbors()) {
			if (found.get(w)==null) {
				doDFS(w, found, ccId);
			}
		}
	}

	/**
	 * Creates a rooted tree (vertices have corresponding indices).
	 * @param g
	 * @param root
	 * @return
	 */
	public static RootedTree createInducedRootedTree(Graph g, Vertex root) {
		AdjListRootedTree rt = new AdjListRootedTree(g.getVertexCount());
		copyGraph(g, rt);
		rt.setRoot(rt.getVertex(root.getIndex()));
		createTreeChildren(null, rt.getRoot(), rt);		
		
		return rt;
	}

	private static void createTreeChildren(AdjListRTreeVertex p, AdjListRTreeVertex v, AdjListRootedTree rt) {
		for (AdjListRTreeVertex c : v.neighbors()) {
			if (c != p) {
				if (c.getTreeParent() != null) throw new IllegalArgumentException("Not a tree structure");
				c.setTreeParent(v);
				createTreeChildren(v, c, rt);
			}
		}
	}
	
	public static <V,E> HashMap<Vertex, Vertex> copyLGraph(LGraph<V,E> source, LGraph<V, E> target) {
		Graph sg = source.getGraph();
		VertexArray<V> sva = source.getVertexLabel();
		EdgeArray<E> sea = source.getEdgeLabel();
		ExtendibleGraph tg = (ExtendibleGraph)target.getGraph();
		VertexArray<V> tva = target.getVertexLabel();
		EdgeArray<E> tea = target.getEdgeLabel();
		
		HashMap<Vertex, Vertex> sourceToTargetMap = new HashMap<Vertex, Vertex>();
		for (Vertex sv : sg.vertices()) {
			Vertex tv = tg.createVertex();
			sourceToTargetMap.put(sv, tv);
			tva.set(tv, sva.get(sv));
		}
		for (Edge se : sg.edges()) {
			Vertex su = se.getFirstVertex();
			Vertex sv = se.getSecondVertex();
			Vertex tu = sourceToTargetMap.get(su);
			Vertex tv = sourceToTargetMap.get(sv);
			Edge te = tg.createEdge(tu, tv);
			tea.set(te, sea.get(se));
		}
		
		return sourceToTargetMap;
	}
	
	public static <V,E> LGraph<V, E> copyLGraph(LGraph<V,E> source) {
		Graph g = new AdjListGraph();
		VertexArray<V> va = new VertexArray<V>(g);
		EdgeArray<E> ea = new EdgeArray<E>(g);
		LGraph<V, E> target = new LGraph<V, E>(g, va, ea);
		copyLGraph(source, target);
		return target;
	}
	
	public static <V,E> LGraph<V, E> convert (graph.Graph<V, E> source) {
        ExtendibleGraph g = new AdjListGraph(source.getNodeCount() ,source.getEdgeCount());
        
        VertexArray<V> tva = new VertexArray<>(g);
        EdgeArray<E> tea = new EdgeArray<>(g);
        
        HashMap<graph.Node<V, E>, Vertex> sourceToTargetMap = new HashMap<>();
        for (Node<V, E> sv : source.nodes()) {
            Vertex tv = g.createVertex();
            sourceToTargetMap.put(sv, tv);
            tva.set(tv, sv.getLabel());
        }
        for (graph.Edge<V, E> se : source.edges()) {
            Vertex tu = sourceToTargetMap.get(se.getFirstNode());
            Vertex tv = sourceToTargetMap.get(se.getSecondNode());
            Edge te = g.createEdge(tu, tv);
            tea.set(te, se.getLabel());
        }
        
        LGraph<V, E> target = new LGraph<V, E>(g, tva, tea);
        return target;
	}
	
	
}
