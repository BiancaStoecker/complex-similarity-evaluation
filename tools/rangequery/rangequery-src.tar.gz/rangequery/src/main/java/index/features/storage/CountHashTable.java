package index.features.storage;

import java.util.HashMap;
import java.util.Map.Entry;

/**
 * Stores all features found in a hash map and counts the number of occurrences.
 * 
 * @author Nils Kriege
 * 
 * @param <F>
 *            the type of the feature
 */
public class CountHashTable<F> implements FeatureStorage<F, HashMap<F, Integer>> {

	private HashMap<F, Integer> features;
	
    /**
     * Constructor
     */
	public CountHashTable() {
		features = new HashMap<F, Integer>();
	}
	
	/**
     * Note: The given object must have a reasonable implementation of
     * {@link Object#hashCode()} and {@link Object#equals(Object)}.
     * 
     * @see FeatureStorage#processFeature(Object)
	 */
    @Override
	public void processFeature(F feature) {
		Integer value = features.get(feature);
		if (value == null)
			features.put(feature, 1);
		else
			features.put(feature, value+1);
	}
	
    @Override
	public int getFeatureCount() {
		return features.size();
	}
	
    @Override
	public HashMap<F, Integer> getResult() {
		return features;
	}
	
    @Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (Entry<F,Integer> e : features.entrySet()) {
			sb.append(e.getKey());
			sb.append(" ");
			sb.append(e.getValue());
			sb.append("\n");
		}
		
		return sb.toString();
	}
}
