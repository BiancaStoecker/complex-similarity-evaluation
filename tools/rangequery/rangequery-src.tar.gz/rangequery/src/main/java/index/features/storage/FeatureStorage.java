package index.features.storage;

public interface FeatureStorage<I,O> {
	
	public void processFeature(I feature);
	public O getResult();
	public int getFeatureCount();

}