package index.features.extractor;

import graph.Edge;
import graph.Graph;
import graph.Node;
import index.features.storage.FeatureStorage;

/**
 * Calculates the features of a graph
 * 
 * @author Nils Kriege
 * 
 * @param <I>
 *            the type of feature description
 */
public abstract class FeatureExtractor<I> {

	protected FeatureStorage<? super I,?> featureStorage;
	protected Graph<?extends Object, ? extends Object> graph;
	
    /**
     * Constructor
     */
	public FeatureExtractor() {
	}
	
    /**
     * Constructor
     * 
     * @param graph
     *            the {@link Graph} to extract the features from
     * @param featureStorage
     */
    public FeatureExtractor(Graph graph, FeatureStorage<? super I, ?> featureStorage) {
		this.graph = graph;
		this.featureStorage = featureStorage;
	}
	
    /**
     * Get the {@link FeatureStorage}
     * 
     * @return the {@link FeatureStorage}
     */
	public FeatureStorage<? super I,?> getFeatureStorage() {
		return featureStorage;
	}
	
    /**
     * The actual calculation of the features
     */
	public abstract void extractFeatures();

    /**
     * Returns the label of the {@link Node} as {@link String}
     * 
     * @param n
     *            the {@link Node}
     * @return the label as {@link String}
     */
	public static String getLabel(Node n) {
		/*
		if (n instanceof MoleculeNode) {
			return ((MoleculeNode)n).getAtom().getSymbol();
		} else {
			// labels must not conatain "!"
			return "!"+n.getLabel()+"!";
		}
		*/
		return n.getLabel().toString();
	}

    /**
     * Returns the label of the {@link Edge} as {@link String}
     * 
     * @param e
     *            the {@link Edge}
     * @return the label as {@link String}
     */
	public static String getLabel(Edge e) {
		/*
		if (e instanceof MoleculeEdge) {
			IBond bond = ((MoleculeEdge)e).getBond();;
			if (bond.getFlag(CDKConstants.ISAROMATIC)) {
				return ":";
			} else if (bond.getOrder() == IBond.Order.SINGLE) {
				return "-";
			} else if (bond.getOrder() == IBond.Order.DOUBLE) {
				return "=";
			} else if (bond.getOrder() == IBond.Order.TRIPLE) {
				return "#";
			}
		}
		// labels must not conatain "!"
		return "!"+e.getLabel()+"!";
		*/
		return e.getLabel().toString();
	}
	
}
