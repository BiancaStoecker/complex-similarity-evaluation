package index.features.extractor;

import graph.Graph;
import graph.Node;
import index.features.extractor.Subtree.IndexEdge;
import index.features.storage.FeatureStorage;

import java.util.List;

/**
 * Finds all subtrees of a graph.
 */
public class SubtreeExtractor extends FeatureExtractor<String> {
	
	int maxSize;
	
	public int features=0;
	
	/**
	 * @param graph
	 * @param featureStorage
	 * @param maxSize the number of edges a subtree may contain
	 */
	public SubtreeExtractor(Graph graph, FeatureStorage<? super String, ?> featureStorage, int maxSize) {
		super(graph, featureStorage);
		this.maxSize = maxSize;
	}

	public void extractFeatures() {
		Subtree<?extends Object, ? extends Object> t = new Subtree(graph, maxSize);
		for (Node v : t.nodes()) {
			t.addActiveNode(v);
			featureStorage.processFeature(t.getCanonicalLabeling());
			features++;
			
			for (IndexEdge e : t.getExtensions()) {
				if (v.getIndex() > e.getOppositeNode(v).getIndex()) {
					extendSubtreeByEdge(t,e);
				}
			}
			t.removeLastActiveNode();
		}
	}
	
	private void extendSubtreeByEdge(Subtree t, IndexEdge e) {
		t.addActiveEdge(e);
		featureStorage.processFeature(t.getCanonicalLabeling());
		features++;
		
		List<IndexEdge> selectableEdges = t.getExtensions();
		for (IndexEdge f : selectableEdges) {
			extendSubtreeByEdge(t, f);
		}
		
		t.allowEdges(selectableEdges);
		
		t.removeLastActiveEdge();
		t.forbidEdge(e);
	}

}
