package index.features.extractor;

import graph.DefaultEdge;
import graph.DefaultGraph;
import graph.DefaultNode;
import graph.Edge;
import graph.Graph;
import graph.Node;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Represents a subtree of a graph and allows to add and remove vertices and
 * edge of the underlying graph to the subtree. This class is used in the
 * subtree enumeration process implemented by {@link SubtreeExtractor} and
 * provides tree canonicalization by the method {@link #getCanonicalLabeling()}.
 * 
 * @author Nils Kriege
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 */
public class Subtree<NL, EL> extends DefaultGraph<NL, EL> {

    private int maxSize = 5;
    private int n;
    private int m;

    private ArrayList<IndexEdge<NL, EL>> edges;

    private LinkedList<Node<NL, EL>> activeNodes;
    private BitSet iActiveNodes;

    private LinkedList<IndexEdge<NL, EL>> activeEdges;
    private BitSet iActiveEdges;

    private int[] activeDegree;
    private final String[] canonicalLabelings;
    private final Comparator<Node<NL, EL>> nodeLabelingComparator;

    private ArrayList<ArrayList<Node<NL, EL>>> children;
    private ArrayList<Node<NL, EL>> level;
    private ArrayList<Node<NL, EL>> nextLevel;

    private boolean[] forbid;

    /**
     * Constructor
     * 
     * @param g
     *            the underlying {@link Graph}
     * @param maxSize
     *            the number of edges a subtree may contain
     */
    public Subtree(Graph<NL, EL> g, int maxSize) {
        this.maxSize = maxSize;

        List<? extends Node<NL, EL>> gNodes = g.nodes();
        List<? extends Edge<NL, EL>> gEdges = g.edges();

        this.n = gNodes.size();
        this.m = gEdges.size();

        // construct graph copy
        edges = new ArrayList<IndexEdge<NL, EL>>(gEdges.size());

        for (Node<NL, EL> u : gNodes)
            this.addNode(u.getLabel());

        for (Edge<NL, EL> e : gEdges) {
            DefaultNode<NL, EL> u = getNode(e.getFirstNode().getIndex());
            DefaultNode<NL, EL> v = getNode(e.getSecondNode().getIndex());
            this.addEdge(u, v, e.getLabel());
        }

        // init activation data structure
        activeNodes = new LinkedList<Node<NL, EL>>();
        iActiveNodes = new BitSet(n);

        activeEdges = new LinkedList<IndexEdge<NL, EL>>();
        iActiveEdges = new BitSet(m);

        activeDegree = new int[n];
        forbid = new boolean[m];

        canonicalLabelings = new String[n];
        nodeLabelingComparator = new Comparator<Node<NL, EL>>() {
            @Override
            public int compare(Node<NL, EL> o1, Node<NL, EL> o2) {
                return canonicalLabelings[o1.getIndex()].compareTo(canonicalLabelings[o2.getIndex()]);
            }
        };
        children = new ArrayList<ArrayList<Node<NL, EL>>>(n);
        for (int i = 0; i < n; i++) {
            children.add(new ArrayList<Node<NL, EL>>());
        }
        level = new ArrayList<Node<NL, EL>>();
        nextLevel = new ArrayList<Node<NL, EL>>();

        clearLists();
    }

    @Override
    public IndexEdge<NL, EL> addEdge(Node<NL, EL> u, Node<NL, EL> v, EL label) {
        IndexEdge<NL, EL> edge = new IndexEdge<NL, EL>(u, v, label, edges.size());
        u.addEdge(edge);
        v.addEdge(edge);
        edges.add(edge);
        super.edgeCount++;

        return edge;
    }

    /**
     * Extends the default edge by an index.
     * 
     * @param <NL>
     *            the node label type
     * @param <EL>
     *            the edge label type
     */
    @SuppressWarnings("hiding")
    public class IndexEdge<NL, EL> extends DefaultEdge<NL, EL> {
        private int index;

        protected IndexEdge(Node<NL, EL> u, Node<NL, EL> v, EL label, int index) {
            super(u, v, label);
            this.index = index;
        }

        /**
         * Return the index of the {@link Edge}
         * 
         * @return the index
         */
        public int getIndex() {
            return index;
        }
    }

    /**
     * Adds a {@link Node} of the underlying graph to the subtree.
     * 
     * @param v
     *            the {@link Node} to activate
     */
    public void addActiveNode(Node<NL, EL> v) {
        iActiveNodes.set(v.getIndex());
        activeNodes.push(v);
    }

    /**
     * Removes the {@link Node} from the subtree that was added last.
     */
    public void removeLastActiveNode() {
        Node<NL, EL> v = activeNodes.pop();
        iActiveNodes.clear(v.getIndex());
    }

    /**
     * Adds an {@link Edge} of the underlying graph to the subtree. Note that
     * exactly one node of the edge must already be contained in the subtree;
     * the other node is added automatically.
     * 
     * @param e
     *            the {@link Edge} to activate
     */
    public void addActiveEdge(IndexEdge<NL, EL> e) {
        iActiveEdges.set(e.getIndex());
        activeEdges.push(e);
        Node<NL, EL> u = e.getFirstNode();
        Node<NL, EL> v = e.getSecondNode();
        if (iActiveNodes.get(u.getIndex())) {
            addActiveNode(v);
        } else {
            addActiveNode(u);
        }
        activeDegree[u.getIndex()]++;
        activeDegree[v.getIndex()]++;
    }

    /**
     * Removes the {@link Edge} from the subtree that was added last. This will
     * also remove the vertex that is no longer connected to the tree.
     */
    public void removeLastActiveEdge() {
        IndexEdge<NL, EL> e = activeEdges.pop();
        iActiveEdges.clear(e.getIndex());
        removeLastActiveNode();
        activeDegree[e.getFirstNode().getIndex()]--;
        activeDegree[e.getSecondNode().getIndex()]--;
    }

    /**
     * Blocks an edge for extension.
     * 
     * @param e
     *            the edge that should be blocked
     * @see #getExtensions()
     */
    public void forbidEdge(IndexEdge<NL, EL> e) {
        forbid[e.getIndex()] = true;
    }

    /**
     * Unblocks edges for extension.
     * 
     * @param edges
     *            the edges that should be unblocked
     * @see #getExtensions()
     */
    public void allowEdges(Collection<IndexEdge<NL, EL>> edges) {
        for (IndexEdge<NL, EL> e : edges) {
            forbid[e.getIndex()] = false;
        }
    }

    /**
     * Returns all edges of the underlying graph that can be used to extend the
     * current subtree. This is an empty set if the maximum subtree size is
     * reached. The set only contains edges that are not blocked and do not form
     * a cycle when added to the subtree.
     * 
     * @return list of edges allowed for extension
     * @see #forbidEdge(IndexEdge)
     * @see #allowEdges(Collection)
     */
    public List<IndexEdge<NL, EL>> getExtensions() {
        LinkedList<IndexEdge<NL, EL>> result = new LinkedList<IndexEdge<NL, EL>>();

        if (activeNodes.size() > maxSize)
            return result;

        for (Node<NL, EL> v : activeNodes) {
            for (Edge<NL, EL> e : v.getEdges()) {
                int edgeIndex = ((IndexEdge<NL, EL>) e).getIndex();
                if (!iActiveEdges.get(edgeIndex) && !iActiveNodes.get(e.getOppositeNode(v).getIndex())
                        && !forbid[edgeIndex]) {
                    result.add((IndexEdge<NL, EL>) e);
                }
            }
        }

        return result;
    }

    private Iterable<IndexEdge<NL, EL>> getActiveEdges(final Node<NL, EL> u) {
        return new Iterable<IndexEdge<NL, EL>>() {
            @Override
            public Iterator<IndexEdge<NL, EL>> iterator() {
                return new Iterator<IndexEdge<NL, EL>>() {
                    Iterator<? extends Edge<NL, EL>> i = u.getEdges().iterator();
                    IndexEdge<NL, EL> current;

                    @Override
                    public boolean hasNext() {
                        while (i.hasNext()) {
                            if (iActiveEdges.get((current = (IndexEdge<NL, EL>) i.next()).getIndex()))
                                return true;
                        }
                        return false;
                    }

                    @Override
                    public IndexEdge<NL, EL> next() {
                        return current;
                    }

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }
        };
    }

    /*
     * private boolean testTree() { if (activeNodeCount <= 0) return true;
     * 
     * if (activeNodeCount != activeEdges.size()+1) return false;
     * 
     * // test connectivity Node[] parent = new Node[n]; Queue<Node> q = new
     * LinkedList<Node>(); Node root = activeNodes.getFirst(); q.add(root);
     * parent[root.getIndex()] = root; while (!q.isEmpty()) { Node u = q.poll();
     * for (Edge e : getActiveEdges(u)) { Node v = e.getOppositeNode(u); if
     * (parent[v.getIndex()] == null) { q.add(v); parent[v.getIndex()] = u; }
     * else if (parent[u.getIndex()] != v) return false; } }
     * 
     * return true; }
     */

    /**
     * Computes a canonical labeling for the current subtree, i.e., a string
     * that uniquely identifies the structure and labels of the tree. Two trees
     * have the same canonical labeling iff they are isomorphic.
     * 
     * @return a canonical string encoding the current tree
     */
    public String getCanonicalLabeling() {
        // find center
        for (Node<NL, EL> v : activeNodes) {
            // add leafs/the root of single node trees
            if (activeDegree[v.getIndex()] <= 1) {
                nextLevel.add(v);
            }
        }

        int[] activeDegreeClone = activeDegree.clone();
        while (!nextLevel.isEmpty()) {
            // swap
            ArrayList<Node<NL, EL>> tmp = level;
            level = nextLevel;
            nextLevel = tmp;
            nextLevel.clear();
            for (Node<NL, EL> u : level) {
                for (Edge<NL, EL> e : getActiveEdges(u)) {
                    Node<NL, EL> v = e.getOppositeNode(u);
                    // nodes with degree 1 have been processed before
                    // or there is a single node that is the root of this tree
                    if (activeDegreeClone[v.getIndex()] != 1 || (!nextLevel.isEmpty() && v == nextLevel.get(0))) {
                        int degree = --activeDegreeClone[v.getIndex()];
                        children.get(v.getIndex()).add(u);
                        if (degree == 1) {
                            nextLevel.add(v);
                        }
                    }
                }
            }
        }

        String label;
        ArrayList<Node<NL, EL>> roots = level;
        if (roots.size() == 1) {
            label = getCanonicalLabeling(roots.get(0), children);
        } else { // bicentered
            String label1 = getCanonicalLabeling(roots.get(0), children);
            String label2 = getCanonicalLabeling(roots.get(1), children);

            String edgeLabel = FeatureExtractor.getLabel(getEdge(roots.get(0), roots.get(1)));
            if (label1.compareTo(label2) < 0)
                label = label1 + edgeLabel + label2;
            else
                label = label2 + edgeLabel + label1;
        }

        clearLists();

        return label;
    }

    // T.root; T.T1, ..., T.Tn sorted by l(T.Ti); T1.edge, ..., Tn.edgd
    // build label: l(T)=l(T.root)l(T1.edge)l(T.1),...,l(Tn.edge)l(T.n)$
    // bottom-up
    private String getCanonicalLabeling(Node<NL, EL> u, ArrayList<? extends List<Node<NL, EL>>> children) {
        int childCount = children.get(u.getIndex()).size();

        if (childCount == 0) {
            return FeatureExtractor.getLabel(u) + "$";
        } else if (childCount == 1) {
            Node<NL, EL> child = children.get(u.getIndex()).get(0);
            Edge<NL, EL> edge = getEdge(u, child);
            String edgeLabel = FeatureExtractor.getLabel(edge);
            canonicalLabelings[child.getIndex()] = edgeLabel + getCanonicalLabeling(child, children);
            return FeatureExtractor.getLabel(u) + canonicalLabelings[child.getIndex()] + "$";
        } else {
            List<Node<NL, EL>> uChildren = children.get(u.getIndex());
            for (Node<NL, EL> v : uChildren) {
                Edge<NL, EL> edge = getEdge(u, v);
                String edgeLabel = FeatureExtractor.getLabel(edge);
                canonicalLabelings[v.getIndex()] = edgeLabel + getCanonicalLabeling(v, children);
            }
            Collections.sort(uChildren, nodeLabelingComparator);
            StringBuilder bc = new StringBuilder(FeatureExtractor.getLabel(u));
            for (Node<NL, EL> c : uChildren)
                bc.append(canonicalLabelings[c.getIndex()]);
            bc.append("$");
            return bc.toString();
        }
    }

    private void clearLists() {
        for (int i = 0; i < n; i++) {
            children.get(i).clear();
        }
        level.clear();
        nextLevel.clear();
    }

    @Override
    public String toString() {
        StringBuilder b = new StringBuilder();
        if (activeEdges.isEmpty()) {
            b.append(activeNodes.getFirst().getIndex());
        } else {
            for (IndexEdge<NL, EL> e : activeEdges) {
                b.append(e.getFirstNode().getIndex() + " -(" + e.getIndex() + ")- " + e.getSecondNode().getIndex()
                        + "\n");
            }
        }
        return b.toString();
    }

}
