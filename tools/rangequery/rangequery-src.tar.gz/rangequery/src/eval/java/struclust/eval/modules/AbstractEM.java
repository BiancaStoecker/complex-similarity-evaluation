package struclust.eval.modules;



/**
 * Abstract EvalModule. Adds some common used variables, that makes the code
 * less redundant
 * 
 * @author Till Schäfer
 * 
 * @param <T>
 */
public abstract class AbstractEM<T> implements EvalModule<T> {
    
    protected T testData = null;

    @Override
    public T getTestData() {
        return testData;
    }

}
