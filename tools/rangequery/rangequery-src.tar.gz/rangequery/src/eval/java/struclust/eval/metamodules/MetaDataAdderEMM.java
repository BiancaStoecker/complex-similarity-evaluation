package struclust.eval.metamodules;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import struclust.eval.EvalResult;
import struclust.eval.MetaDataAddable;

/**
 * Adds arbitrary user specified meta data to all results
 * 
 * @author Till Schäfer
 * 
 */
public class MetaDataAdderEMM extends AbstractEMM {

    private LinkedHashMap<String, String> metadata = null;
    private MetaDataAddable addable = null;

    /**
     * Constructor to add a single meta data key-value pair
     * 
     * @param key
     *            the key
     * @param value
     *            the value
     */
    public MetaDataAdderEMM(String key, String value) {
        metadata = new LinkedHashMap<>();
        metadata.put(key, value);
    }

    /**
     * Constructor to add a set of meta data key-value pairs.
     * 
     * @param metaData
     *            a map containing all key-value pairs
     */
    public MetaDataAdderEMM(Map<String, String> metaData) {
        metadata = new LinkedHashMap<>();
        metadata.putAll(metaData);
    }

    /**
     * Constructor to add a set of meta data key-value pairs.
     * 
     * @param addable
     *            a {@link MetaDataAddable}
     */
    public MetaDataAdderEMM(MetaDataAddable addable) {
        this.addable = addable;
    }

    @Override
    public Collection<EvalResult> process(Collection<EvalResult> results) {
        for (EvalResult evalResult : results) {
            if (useAddable()) {
                evalResult.addMetadata(addable);
            } else {
                for (Entry<String, String> entry : metadata.entrySet()) {
                    evalResult.addMetadata(entry.getKey(), entry.getValue());
                }
            }
        }
        return results;
    }

    private boolean useAddable() {
        return metadata == null;
    }

}
