package struclust.eval.testsetups.rahmannrangequerycli;

import com.beust.jcommander.Parameter;
import com.beust.jcommander.validators.PositiveInteger;

/**
 * The Parameters for WL-Jaccard CLIs
 * 
 * @author Till Schäfer
 *
 */
public class Parameters {
    @Parameter(names = { "--dataset" }, description = "dataset folder with files in GML format. "
            + "Also supports gziped gml formats (extension .gml.gz).", required = true)
    String dataset;

    @Parameter(names = { "--queries" }, description = "query graphs in GML format", required = true)
    String queries;

    @Parameter(names = { "--resultfolder" }, description = "The results folder", required = true)
    String resultFolder;

    @Parameter(names = { "--thresh" }, description = "The jaccard threshold", required = true)
    Double simThresh;

    @Parameter(names = {
            "--falsenegativerate" }, description = "Maximum expected false negative rate for min hash range query. "
                    + "The real error is usually much smaller.", required = false)
    Double falseNegativeRate = 0.01;

    @Parameter(names = {
            "--wl0weight" }, description = "Weight of the zeroth weisfeiler lehmann iteration", required = false, validateWith = {
                    PositiveInteger.class })
    Integer wl0weight = 1;

    @Parameter(names = {
            "--wl1weight" }, description = "Weight of the first weisfeiler lehmann iteration", required = false, validateWith = {
                    PositiveInteger.class })
    Integer wl1weight = 1;

    @Parameter(names = "--useminhashing")
    Boolean useMinHashing = false;

    @Parameter(names = "--warmupjvm")
    Boolean warmupJvm = true;

    @Parameter(names = "--help", help = true)
    Boolean help = false;
}