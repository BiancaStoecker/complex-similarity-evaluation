package struclust.eval.modules.clustering;

import graph.Graph;

import java.util.Collection;
import java.util.List;

import struclust.Cluster;
import struclust.StructuralClustering;
import struclust.eval.EvalException;
import struclust.eval.EvalResult;
import struclust.eval.modules.AbstractEM;
import struclust.eval.modules.EvalModule;

import com.google.common.base.Preconditions;

/**
 * Abstract class for clustering {@link EvalModule}s, that should be inherited
 * by {@link EvalModule}s, that do support precomputed test data. If inherited
 * from this class, only the Method {@link PrecompClustEM#runInternal(List)} and
 * a constructor must be implemented.
 * 
 * @author Till Schäfer
 *
 * @param <NL>
 *            the node label type
 * @param <EL>
 *            the edge label type
 * @param <G>
 *            the graph type
 */
@SuppressWarnings("javadoc")
public abstract class PrecompClustEM<NL, EL, G extends Graph<NL, EL>> extends AbstractEM<List<Cluster<NL, EL, G>>> {

    protected StructuralClustering<NL, EL, G> clust;

    /**
     * Constructor.
     * 
     * @param clust
     *            The configured clustering algorithm
     */
    public PrecompClustEM(StructuralClustering<NL, EL, G> clust) {
        Preconditions.checkNotNull(clust);

        this.clust = clust;
    }

    @Override
    public Collection<EvalResult> run() throws EvalException {
        List<Cluster<NL, EL, G>> clustering = clust.calc();

        return run(clustering);
    }

    @Override
    public Collection<EvalResult> run(List<Cluster<NL, EL, G>> clustering) throws EvalException {
        testData = clustering;

        return runInternal(clustering);
    }

    protected abstract Collection<EvalResult> runInternal(List<Cluster<NL, EL, G>> clustering) throws EvalException;

    @Override
    public boolean canUsePrecomputedTestData() {
        return true;
    }

}
