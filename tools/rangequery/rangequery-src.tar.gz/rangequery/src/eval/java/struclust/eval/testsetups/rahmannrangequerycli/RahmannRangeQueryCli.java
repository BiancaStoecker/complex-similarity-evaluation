package struclust.eval.testsetups.rahmannrangequerycli;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.math3.util.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.beust.jcommander.JCommander;
import com.beust.jcommander.ParameterException;
import com.google.common.collect.Iterables;

import graph.DefaultGraph;
import graph.Graph;
import hsahn.algorithm.graph.isomorphism.labelrefinement.VertexLabelConverter;
import hsahn.comparison.kernel.ExplicitMappingKernel;
import hsahn.comparison.kernel.graph.WeisfeilerLehmanKernel;
import hsahn.comparison.kernel.graph.WeisfeilerLehmanSubtreeKernel;
import hsahn.datastructure.SparseFeatureVector;
import hsahn.graph.GraphTools;
import hsahn.graph.LGraph;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import struclust.comparison.JaccardNFVD;
import struclust.eval.EvalResult;
import struclust.eval.metamodules.FileSaverEMM;
import struclust.eval.metamodules.MetaDataAdderEMM;
import struclust.eval.testsetups.TSHelpers;
import struclust.graph.GraphContainer;
import struclust.hashing.MinHashJaccardRangeQuery;
import struclust.util.FsOperations;
import struclust.util.GraphIO;

/**
 * CLI to benchmark WL-Jaccard range queries in a graph database.
 * 
 * @author Till Schäfer
 */
public class RahmannRangeQueryCli {
    private static final Logger logger = LoggerFactory.getLogger(RahmannRangeQueryCli.class);

    /**
     * Main CLI entry point
     * 
     * @param args
     * @throws FileNotFoundException
     * @throws UnknownHostException
     * @throws IOException
     * @throws InterruptedException
     */
    public static void main(String[] args)
            throws FileNotFoundException, UnknownHostException, IOException, InterruptedException {
        Parameters param = new Parameters();
        JCommander jCom = new JCommander(param);
        try {
            jCom.parse(args);
        } catch (ParameterException e) {
            System.out.println(e.getMessage());
            System.out.println();
            printGeneralMessage();
            jCom.usage();
            return;
        }

        if (param.help) {
            printGeneralMessage();
            jCom.usage();
            return;
        }

        int wlSequenceLength = 2;
        ExplicitMappingKernel<LGraph<String, String>,
                SparseFeatureVector<Integer>> kernel = new WeisfeilerLehmanSubtreeKernel<>(wlSequenceLength, true);
        double[] simThreshs = new double[] { param.simThresh };
        if (param.useMinHashing) {
            if (param.warmupJvm) {
                logger.info("running jvm warmup");
                defMinHashRangeQuery("MinHashRangeQuery", param.resultFolder, param.dataset,
                        param.queries, null, kernel, simThreshs, param.falseNegativeRate, param.wl0weight,
                        param.wl1weight, false);
            }
            logger.info("running benchmark");
            defMinHashRangeQuery("MinHashRangeQuery", param.resultFolder, param.dataset,
                    param.queries, null, kernel, simThreshs, param.falseNegativeRate, param.wl0weight, param.wl1weight,
                    true);
        } else {
            if (param.warmupJvm) {
                logger.info("running jvm warmup");
                defJaccardRangeQuery("JaccardRangeQuery", param.resultFolder, param.dataset,
                        param.queries, null, kernel, simThreshs, param.wl0weight, param.wl1weight, false);
            }
            logger.info("running benchmark");
            defJaccardRangeQuery("JaccardRangeQuery", param.resultFolder, param.dataset,
                    param.queries, null, kernel, simThreshs, param.wl0weight, param.wl1weight, true);
        }
    }

    private static void printGeneralMessage() {
        System.out.println("This tool will measure the time to caclucalte range queries in a database "
                + "on Weisfeiler-Lehman(WL) Feature Vectors.\n");
    }

    
    /**
     * @param canonicalDescription
     * @param baseFolderPath
     * @param gmlDatasetFolder
     * @param gmlQueriesFile
     * @param filter
     * @param explIntKernel
     * @param simThreshs
     * @param wl0weight
     * @param wl1weight
     * @param createResults
     * @return evalResults
     * @throws FileNotFoundException
     * @throws IOException
     * @throws UnknownHostException
     * @throws InterruptedException
     */
    private static LinkedList<EvalResult> defJaccardRangeQuery(String canonicalDescription, String baseFolderPath,
            String gmlDatasetFolder, String gmlQueriesFile, Predicate<Graph<String, String>> filter,
            ExplicitMappingKernel<LGraph<String, String>, SparseFeatureVector<Integer>> explIntKernel,
            double[] simThreshs, int wl0weight, int wl1weight, boolean createResults)
            throws FileNotFoundException, IOException, UnknownHostException, InterruptedException {
        boolean singleThresh = simThreshs.length == 1;
        LinkedList<EvalResult> results = new LinkedList<>();

        // TODO: check parallelism

        // load
        File[] gmlDatasetFiles = new File(gmlDatasetFolder).listFiles();
        MetaDataAdderEMM[] datasetNames = new MetaDataAdderEMM[gmlDatasetFiles.length];
        MetaDataAdderEMM[] datasetSizes = new MetaDataAdderEMM[gmlDatasetFiles.length];
        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> dataset = new ArrayList<>();
        IntStream.range(0, gmlDatasetFiles.length).parallel()
                .forEach(j -> loadDataset(filter, gmlDatasetFiles, datasetNames, datasetSizes, dataset, j));
        TSHelpers.logDatasetSummary(false, dataset);

        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> queries = GraphIO
                .gmlToPropertyGraphContainer(new File(gmlQueriesFile).getAbsolutePath(), filter);

        ArrayList<LGraph<String, String>> lGraphs = new ArrayList<>(dataset.size());
        for (GraphContainer<String, String, DefaultGraph<String, String>> graph : Iterables.concat(dataset, queries)) {
            lGraphs.add(GraphTools.convert(graph));
        }

        EvalResult perfResult = new EvalResult("perf");
        FileSaverEMM resultSaver = null;
        if (createResults) {
            String folderPath = FsOperations.createUniqueFolder(baseFolderPath, "", 3);
            resultSaver = new FileSaverEMM(folderPath, true, false);
            MetaDataAdderEMM[] extraMetaData = { TSHelpers.hostNameMetaData(),
                    new MetaDataAdderEMM("dataset folder path", gmlDatasetFolder),
                    new MetaDataAdderEMM("queries file", gmlQueriesFile),
                    new MetaDataAdderEMM("kernel", explIntKernel.toString()),
                    new MetaDataAdderEMM("wl0weight", String.valueOf(wl0weight)),
                    new MetaDataAdderEMM("wl1weight", String.valueOf(wl1weight)),
                    new MetaDataAdderEMM("num queries", String.valueOf(queries.size())),
                    new MetaDataAdderEMM("overall dataset size", String.valueOf(dataset.size())) };
            if (singleThresh) {
                MetaDataAdderEMM[] simMetaData = { new MetaDataAdderEMM("simThresh", Double.toString(simThreshs[0])) };
                extraMetaData = ArrayUtils.addAll(extraMetaData, simMetaData);
            }
            extraMetaData = ArrayUtils.addAll(extraMetaData, datasetNames);
            extraMetaData = ArrayUtils.addAll(extraMetaData, datasetSizes);
            results.add(TSHelpers.logAndSaveMetadataInfo(canonicalDescription, null, folderPath, extraMetaData));

            for (MetaDataAdderEMM metaDataAdderEMM : extraMetaData) {
                metaDataAdderEMM.process(Collections.singleton(perfResult));
            }
        }

        // compute feature vectors
        // XXX: Benchmark
        final long startFv = System.nanoTime();
        ArrayList<SparseFeatureVector<Integer>> explicitMapping = explIntKernel.computeExplicitMapping(lGraphs);
        final long finishFv = System.nanoTime();
        long msec = (finishFv - startFv) / 1000000;
        if (createResults) {
            perfResult.addResult("feature vector generation time (msec)", msec);
        }
        int maxLabel = explicitMapping.stream().flatMap(fv -> fv.positiveFeatures().stream()).mapToInt(i -> i).max()
                .orElse(0);

        // apply weighting
        int[] featureWeights = new int[maxLabel + 1];

        if (explIntKernel instanceof WeisfeilerLehmanKernel) {
            logger.info("WL Kernel used. Applying weighting of iteration 0 and 1");
            @SuppressWarnings("unchecked")
            VertexLabelConverter<String> vlc = ((WeisfeilerLehmanKernel<String, String, Integer>) explIntKernel)
                    .getVertexLabelConverter();
            for (Entry<Pair<Integer, Object>, Integer> entry : vlc.getLabelMap().entrySet()) {
                Integer iteration = entry.getKey().getKey();
                Integer feature = entry.getValue();
                switch (iteration) {
                case 0:
                    featureWeights[feature] = wl0weight;
                    break;
                case 1:
                    featureWeights[feature] = wl1weight;
                    break;
                default:
                    logger.warn("Weighting cannot be applied to WL interation >=2");
                }
            }

        } else {
            if (wl0weight != 1 || wl1weight != 1) {
                logger.warn("weighting not supported for this kernel");
            }
        }

        for (SparseFeatureVector<Integer> fv : explicitMapping) {
            for (int f : fv.positiveFeatures()) {
                fv.increaseCount(f, fv.getCount(f) * (featureWeights[f] - 1));
            }
        }

        HashMap<GraphContainer<String, String, DefaultGraph<String, String>>,
                SparseFeatureVector<Integer>> graphVectorMapping = new HashMap<>();
        for (int j = 0; j < dataset.size(); j++) {
            graphVectorMapping.put(dataset.get(j), explicitMapping.get(j));
        }
        for (int j = 0; j < queries.size(); j++) {
            graphVectorMapping.put(queries.get(j), explicitMapping.get(dataset.size() + j));
        }

        // range queries
        JaccardNFVD<Integer> dist = new JaccardNFVD<>();

        for (double simThresh : simThreshs) {
            // XXX: benchmark
            final long startQueries = System.nanoTime();
            ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> result = new ArrayList<>();
            for (GraphContainer<String, String, DefaultGraph<String, String>> queryGC : queries) {
                for (GraphContainer<String, String, DefaultGraph<String, String>> graph : dataset) {
                    if (dist.calc(graphVectorMapping.get(queryGC), graphVectorMapping.get(graph)) <= 1 - simThresh) {
                        result.add(graph);
                    }
                }
            }
            final long finishQueries = System.nanoTime();
            logger.debug("{} objects in range", result.size());
            msec = (finishQueries - startQueries) / 1000000;
            perfResult.addResult("queries time (msec)" + (singleThresh ? "" : (" sim=" + simThresh)), msec);
        }
        if (createResults) {
            resultSaver.process(Collections.singleton(perfResult));
            results.add(perfResult);
        }

        return results;
    }
    
    /**
     * @param canonicalDescription
     * @param baseFolderPath
     * @param gmlDatasetFolder
     * @param gmlQueriesFile
     * @param filter
     * @param explIntKernel
     * @param simThreshs
     * @param falseNegativeRate
     * @param wl0weight
     * @param wl1weight
     * @param createResults
     * @return EvalResult
     * @throws FileNotFoundException
     * @throws IOException
     * @throws UnknownHostException
     * @throws InterruptedException
     */
    private static LinkedList<EvalResult> defMinHashRangeQuery(String canonicalDescription, String baseFolderPath,
            String gmlDatasetFolder, String gmlQueriesFile, Predicate<Graph<String, String>> filter,
            ExplicitMappingKernel<LGraph<String, String>, SparseFeatureVector<Integer>> explIntKernel,
            double[] simThreshs, Double falseNegativeRate, int wl0weight, int wl1weight, boolean createResults)
            throws FileNotFoundException, IOException, UnknownHostException, InterruptedException {
        boolean singleThresh = simThreshs.length == 1;
        LinkedList<EvalResult> results = new LinkedList<>();

        // TODO: check parallelism

        // load
        File[] gmlDatasetFiles = new File(gmlDatasetFolder).listFiles();
        MetaDataAdderEMM[] datasetNames = new MetaDataAdderEMM[gmlDatasetFiles.length];
        MetaDataAdderEMM[] datasetSizes = new MetaDataAdderEMM[gmlDatasetFiles.length];
        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> dataset = new ArrayList<>();
        IntStream.range(0, gmlDatasetFiles.length).parallel()
                .forEach(j -> loadDataset(filter, gmlDatasetFiles, datasetNames, datasetSizes, dataset, j));
        TSHelpers.logDatasetSummary(false, dataset);

        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> queries = GraphIO
                .gmlToPropertyGraphContainer(new File(gmlQueriesFile).getAbsolutePath(), filter);

        ArrayList<LGraph<String, String>> lGraphs = new ArrayList<>(dataset.size());
        for (GraphContainer<String, String, DefaultGraph<String, String>> graph : Iterables.concat(dataset, queries)) {
            lGraphs.add(GraphTools.convert(graph));
        }

        EvalResult perfResult = new EvalResult("perf");
        FileSaverEMM resultSaver = null;
        if (createResults) {
            String folderPath = FsOperations.createUniqueFolder(baseFolderPath, "", 3);
            resultSaver = new FileSaverEMM(folderPath, true, false);
            MetaDataAdderEMM[] extraMetaData = { TSHelpers.hostNameMetaData(),
                    new MetaDataAdderEMM("dataset folder path", gmlDatasetFolder),
                    new MetaDataAdderEMM("queries file", gmlQueriesFile),
                    new MetaDataAdderEMM("kernel", explIntKernel.toString()),
                    new MetaDataAdderEMM("wl0weight", String.valueOf(wl0weight)),
                    new MetaDataAdderEMM("wl1weight", String.valueOf(wl1weight)),
                    new MetaDataAdderEMM("min hash range query falseNegativeRate", String.valueOf(falseNegativeRate)),
                    new MetaDataAdderEMM("num queries", String.valueOf(queries.size())),
                    new MetaDataAdderEMM("overall dataset size", String.valueOf(dataset.size())) };
            if (singleThresh) {
                MetaDataAdderEMM[] simMetaData = { new MetaDataAdderEMM("simThresh", Double.toString(simThreshs[0])) };
                extraMetaData = ArrayUtils.addAll(extraMetaData, simMetaData);
            }
            extraMetaData = ArrayUtils.addAll(extraMetaData, datasetNames);
            extraMetaData = ArrayUtils.addAll(extraMetaData, datasetSizes);
            results.add(TSHelpers.logAndSaveMetadataInfo(canonicalDescription, null, folderPath, extraMetaData));
            for (MetaDataAdderEMM metaDataAdderEMM : extraMetaData) {
                metaDataAdderEMM.process(Collections.singleton(perfResult));
            }
        }

        // compute feature vectors
        // XXX: Benchmark
        final long startFv = System.nanoTime();
        ArrayList<SparseFeatureVector<Integer>> explicitMapping = explIntKernel.computeExplicitMapping(lGraphs);
        final long finishFv = System.nanoTime();
        long msec = (finishFv - startFv) / 1000000;
        if (createResults) {
            perfResult.addResult("feature vector generation time (msec)", msec);
        }
        int maxLabel = explicitMapping.stream().flatMap(fv -> fv.positiveFeatures().stream()).mapToInt(i -> i).max()
                .orElse(0);

        // apply weighting
        int[] featureWeights = new int[maxLabel + 1];

        if (explIntKernel instanceof WeisfeilerLehmanKernel) {
            logger.info("WL Kernel used. Applying weighting of iteration 0 and 1");
            @SuppressWarnings("unchecked")
            VertexLabelConverter<String> vlc = ((WeisfeilerLehmanKernel<String, String, Integer>) explIntKernel)
                    .getVertexLabelConverter();
            for (Entry<Pair<Integer, Object>, Integer> entry : vlc.getLabelMap().entrySet()) {
                Integer iteration = entry.getKey().getKey();
                Integer feature = entry.getValue();
                switch (iteration) {
                case 0:
                    featureWeights[feature] = wl0weight;
                    break;
                case 1:
                    featureWeights[feature] = wl1weight;
                    break;
                default:
                    logger.warn("Weighting cannot be applied to WL interation >=2");
                }
            }
        } else {
            if (wl0weight != 1 || wl1weight != 1) {
                logger.warn("weighting not supported for this kernel");
            }
        }

        for (SparseFeatureVector<Integer> fv : explicitMapping) {
            for (int f : fv.positiveFeatures()) {
                fv.increaseCount(f, fv.getCount(f) * (featureWeights[f] - 1));
            }
        }

        // convert numerical to binary feature vectors
        long[] maxLabelCounts = new long[maxLabel + 1];

        for (SparseFeatureVector<Integer> fv : explicitMapping) {
            for (Entry<Integer, Long> e : fv.positiveEntries()) {
                maxLabelCounts[e.getKey()] = Math.max(maxLabelCounts[e.getKey()], e.getValue());
            }
        }

        int[] offsetLabels = new int[maxLabel + 1];
        int offset = 0;
        for (int j = 0; j < offsetLabels.length; j++) {
            offsetLabels[j] = offset;
            offset += maxLabelCounts[j];
        }

        logger.debug("orig num labels: {}", maxLabelCounts.length);
        logger.debug("summed labels: {}", Arrays.stream(maxLabelCounts).sum());
        logger.debug("max single label count: {}", Arrays.stream(maxLabelCounts).max());

        ArrayList<Set<Integer>> binaryFeatureVectors = new ArrayList<>(explicitMapping.size());
        for (SparseFeatureVector<Integer> fv : explicitMapping) {
            Set<Integer> binaryFeatureVector = new IntOpenHashSet();
            for (Entry<Integer, Long> e : fv.positiveEntries()) {
                int offsetLabel = offsetLabels[e.getKey()];
                for (int j = 0; j < e.getValue(); j++) {
                    binaryFeatureVector.add(offsetLabel + j);
                }
            }
            binaryFeatureVectors.add(binaryFeatureVector);
        }

        logger.debug("average postive fingerprint entries: {}",
                binaryFeatureVectors.stream().mapToInt(s -> s.size()).average().getAsDouble());

        HashMap<GraphContainer<String, String, DefaultGraph<String, String>>,
                Set<Integer>> graphVectorMapping = new HashMap<>();
        for (int j = 0; j < dataset.size(); j++) {
            graphVectorMapping.put(dataset.get(j), binaryFeatureVectors.get(j));
        }
        for (int j = 0; j < queries.size(); j++) {
            graphVectorMapping.put(queries.get(j), binaryFeatureVectors.get(dataset.size() + j));
        }

        // range queries
        int maxBinaryLabel = Math
                .toIntExact((offsetLabels[offsetLabels.length - 1] + maxLabelCounts[offsetLabels.length - 1] - 1));
        logger.debug("max binary label: {}", maxBinaryLabel);

        for (double simThresh : simThreshs) {
            // XXX: benchmark
            final long startIndex = System.nanoTime();
            MinHashJaccardRangeQuery<GraphContainer<String, String,
                    DefaultGraph<String, String>>> rangeQuery = new MinHashJaccardRangeQuery<>(dataset,
                            gc -> graphVectorMapping.get(gc), maxBinaryLabel, simThresh, falseNegativeRate, true);
            final long finishIndex = System.nanoTime();
            msec = (finishIndex - startIndex) / 1000000;
            if (createResults) {
                perfResult.addResult("index creation time (msec)" + (singleThresh ? "" : (" sim=" + simThresh)), msec);
            }

            // XXX: benchmark
            final long startQueries = System.nanoTime();
            for (GraphContainer<String, String, DefaultGraph<String, String>> queryGC : queries) {
                rangeQuery.getObjectsWithDistInRange(queryGC);
            }
            final long finishQueries = System.nanoTime();
            msec = (finishQueries - startQueries) / 1000000;
            if (createResults) {
                perfResult.addResult("queries time (msec)" + (singleThresh ? "" : (" sim=" + simThresh)), msec);
            }
        }
        if (createResults) {
            resultSaver.process(Collections.singleton(perfResult));
            results.add(perfResult);
        }

        return results;
    }
    
    /**
     * @param filter
     * @param gmlFiles
     * @param datasetNames
     * @param datasetSizes
     * @param graphContainers
     * @param j
     * @throws FileNotFoundException
     * @throws IOException
     */
    private static void loadDataset(Predicate<Graph<String, String>> filter, File[] gmlFiles,
            MetaDataAdderEMM[] datasetNames, MetaDataAdderEMM[] datasetSizes,
            ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> graphContainers, int j) {
        String gmlPath = gmlFiles[j].getAbsolutePath();
        ArrayList<GraphContainer<String, String, DefaultGraph<String, String>>> graphContainersSingle;
        try {
            graphContainersSingle = GraphIO.gmlToPropertyGraphContainer(gmlPath, filter);
            for (int i = 0; i < graphContainersSingle.size(); i++) {
                GraphContainer<String, String, DefaultGraph<String, String>> gc = graphContainersSingle.get(i);
                gc.putProperty("source", gmlPath);
                gc.putProperty("sourceIndex", String.valueOf(i));
            }
            synchronized (graphContainers) {
                graphContainers.addAll(graphContainersSingle);
            }
            TSHelpers.logDatasetSummary(false, graphContainersSingle);
            datasetNames[j] = new MetaDataAdderEMM("dataset " + j, gmlPath);
            datasetSizes[j] = new MetaDataAdderEMM("dataset " + j + " size",
                    String.valueOf(graphContainersSingle.size()));
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
