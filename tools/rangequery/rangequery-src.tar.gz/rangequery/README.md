StruClus
==============
This is a research project about structural large-scale molecular graph clustering. 


## Kontact Information
* the main author is: Till Schäfer (till2.schaefer@tu-dortmund.de)
  * Web: https://ls11-www.cs.tu-dortmund.de/staff/schaefer
* subgraph-isomorphism and graph class implementations are provided by Nils Kriege (nils.kriege@tu-dortmund.de)

## License 
The StruClus code is licensed under GPLv3 (see GPLv3.txt) with the following addition: If you use the code of StruClus for any scientific or commercial publication you must cite the StruClus publication of Till Schäfer.